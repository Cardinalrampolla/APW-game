/* Canonical portrait gallery */
(function () {
  const artwork = {
    "BIRDMAN PHIL PICASSO": APW_MEDIA[217],
    "GIDEON HARK": APW_MEDIA[218],
    "EVANGELINE STRANGE": APW_MEDIA[219],
    "BRUZA THE SERB": APW_MEDIA[220],
    "SIMON TEMPLE": APW_MEDIA[221],
  };
  const btn = document.createElement("button");
  btn.id = "apw53launch";
  btn.textContent = "★ v5.3 HERO PORTRAITS";
  document.body.appendChild(btn);
  const gallery = document.createElement("div");
  gallery.id = "apw53gallery";
  gallery.innerHTML =
    '<div style="max-width:760px;margin:auto"><h2>APW v5.3 — Photo-Referenced Hero Portraits</h2><p>Five principal characters with individually designed arcade cutscene art.</p><button id="apw53close">CLOSE</button><div class="cards"></div><p>Open 🎬 ANIMATED CINEMATICS to see these portraits in the story scenes.</p></div>';
  document.body.appendChild(gallery);
  const cards = gallery.querySelector(".cards");
  Object.entries(artwork).forEach(([name, url]) => {
    const fig = document.createElement("figure");
    const pic = document.createElement("img");
    pic.src = url;
    pic.alt = name;
    const cap = document.createElement("figcaption");
    cap.textContent = name;
    fig.append(pic, cap);
    cards.appendChild(fig);
  });
  btn.onclick = () => {
    gallery.classList.add("open");
  };
  gallery.querySelector("#apw53close").onclick = () =>
    gallery.classList.remove("open");
})();
