/* Finisher preview */
(() => {
  "use strict";
  const moves = {
    "Gideon Hark": ["RIPCORD CLOTHESLINE", "spin"],
    "Simon Temple": ["CHOKE SLAM", "lift"],
    "Birdman Phil Picasso": ["DOUBLE UNDERHOOK DDT", "spin"],
    "Whiskey Sixx": ["450 SPLASH", "flight"],
    "Bruza The Serb": ["RUSSIAN LEG SWEEP", "spin"],
    "Mauler Y": ["RUNNING SPLASH", "flight"],
    "Nikki Poteet": ["RUNNING CANNONBALL", "flight"],
    "Evangeline Strange": ["RUNNING NECKBREAKER", "spin"],
    "Johnny Putrid": ["THE STROKE", "spin"],
    "Nightmare Cat": ["THE CAT SPLASH", "flight"],
    TNT: ["THE UNPRETTIER", "spin"],
    "Al Straya": ["44 GALLON DRUM", "lift"],
    "Trucker Mark Taylor": ["THE FINAL CUT", "spin"],
    "Taras Jones": ["REAR NAKED CHOKE", "lift"],
    "Harvey Falco": ["FALCON PUNCH", "approach"],
    Doomslayer: ["MAP OF TASSIE", "flight"],
    "Drako Savage": ["FINGER POKE OF DOOM", "approach"],
    "Trashbag Dan": ["THE OIL CHECK", "approach"],
    "Eli Driftwood": ["FIVE STAR FROG SPLASH", "flight"],
    "The Gatekeeper": ["GHOSTLY HANDS SLAM", "lift"],
    "Jay Payne": ["GUITAR SMASH", "approach"],
    "Black Diamond": ["BLACK DIAMOND STRIKE", "approach"],
    "The Outlaw": ["OUTLAW FINISHER", "spin"],
    "Hotshot Hansel": ["HOTSHOT FINISHER", "flight"],
  };
  const $ = (id) => document.getElementById(id),
    stage = $("apw49stage"),
    sel = $("apw49select");
  if (!stage) return;
  const embeddedFinisherSprites = {
    "Gideon Hark": {
      idle: APW_MEDIA[14],
      walk: APW_MEDIA[15],
      strike: APW_MEDIA[16],
      grapple: APW_MEDIA[17],
      hit: APW_MEDIA[18],
      finisher: APW_MEDIA[19],
      down: APW_MEDIA[20],
      victory: APW_MEDIA[21],
    },
    "Simon Temple": {
      idle: APW_MEDIA[22],
      walk: APW_MEDIA[23],
      strike: APW_MEDIA[24],
      grapple: APW_MEDIA[25],
      hit: APW_MEDIA[26],
      finisher: APW_MEDIA[27],
      down: APW_MEDIA[28],
      victory: APW_MEDIA[29],
    },
    "Birdman Phil Picasso": {
      idle: APW_MEDIA[30],
      walk: APW_MEDIA[31],
      strike: APW_MEDIA[32],
      grapple: APW_MEDIA[33],
      hit: APW_MEDIA[34],
      finisher: APW_MEDIA[35],
      down: APW_MEDIA[36],
      victory: APW_MEDIA[37],
    },
    "Bruza The Serb": {
      idle: APW_MEDIA[38],
      walk: APW_MEDIA[39],
      strike: APW_MEDIA[40],
      grapple: APW_MEDIA[41],
      hit: APW_MEDIA[42],
      finisher: APW_MEDIA[43],
      down: APW_MEDIA[44],
      victory: APW_MEDIA[45],
    },
    "Nikki Poteet": {
      idle: APW_MEDIA[46],
      walk: APW_MEDIA[47],
      strike: APW_MEDIA[48],
      grapple: APW_MEDIA[49],
      hit: APW_MEDIA[50],
      finisher: APW_MEDIA[51],
      down: APW_MEDIA[52],
      victory: APW_MEDIA[53],
    },
    "Johnny Putrid": {
      idle: APW_MEDIA[54],
      walk: APW_MEDIA[55],
      strike: APW_MEDIA[56],
      grapple: APW_MEDIA[57],
      hit: APW_MEDIA[58],
      finisher: APW_MEDIA[59],
      down: APW_MEDIA[60],
      victory: APW_MEDIA[61],
    },
    "Nightmare Cat": {
      idle: APW_MEDIA[62],
      walk: APW_MEDIA[63],
      strike: APW_MEDIA[64],
      grapple: APW_MEDIA[65],
      hit: APW_MEDIA[66],
      finisher: APW_MEDIA[67],
      down: APW_MEDIA[68],
      victory: APW_MEDIA[69],
    },
    TNT: {
      idle: APW_MEDIA[70],
      walk: APW_MEDIA[71],
      strike: APW_MEDIA[72],
      grapple: APW_MEDIA[73],
      hit: APW_MEDIA[74],
      finisher: APW_MEDIA[75],
      down: APW_MEDIA[76],
      victory: APW_MEDIA[77],
    },
    "Whiskey Sixx": {
      idle: APW_MEDIA[78],
      walk: APW_MEDIA[79],
      strike: APW_MEDIA[80],
      grapple: APW_MEDIA[81],
      hit: APW_MEDIA[82],
      finisher: APW_MEDIA[83],
      down: APW_MEDIA[84],
      victory: APW_MEDIA[85],
    },
    "Mauler Y": {
      idle: APW_MEDIA[86],
      walk: APW_MEDIA[87],
      strike: APW_MEDIA[88],
      grapple: APW_MEDIA[89],
      hit: APW_MEDIA[90],
      finisher: APW_MEDIA[91],
      down: APW_MEDIA[92],
      victory: APW_MEDIA[93],
    },
    "Al Straya": {
      idle: APW_MEDIA[94],
      walk: APW_MEDIA[95],
      strike: APW_MEDIA[96],
      grapple: APW_MEDIA[97],
      hit: APW_MEDIA[98],
      finisher: APW_MEDIA[99],
      down: APW_MEDIA[100],
      victory: APW_MEDIA[101],
    },
    "Trucker Mark Taylor": {
      idle: APW_MEDIA[102],
      walk: APW_MEDIA[103],
      strike: APW_MEDIA[104],
      grapple: APW_MEDIA[105],
      hit: APW_MEDIA[106],
      finisher: APW_MEDIA[107],
      down: APW_MEDIA[108],
      victory: APW_MEDIA[109],
    },
    "Taras Jones": {
      idle: APW_MEDIA[110],
      walk: APW_MEDIA[111],
      strike: APW_MEDIA[112],
      grapple: APW_MEDIA[113],
      hit: APW_MEDIA[114],
      finisher: APW_MEDIA[115],
      down: APW_MEDIA[116],
      victory: APW_MEDIA[117],
    },
    "Harvey Falco": {
      idle: APW_MEDIA[118],
      walk: APW_MEDIA[119],
      strike: APW_MEDIA[120],
      grapple: APW_MEDIA[121],
      hit: APW_MEDIA[122],
      finisher: APW_MEDIA[123],
      down: APW_MEDIA[124],
      victory: APW_MEDIA[125],
    },
    Doomslayer: {
      idle: APW_MEDIA[126],
      walk: APW_MEDIA[127],
      strike: APW_MEDIA[128],
      grapple: APW_MEDIA[129],
      hit: APW_MEDIA[130],
      finisher: APW_MEDIA[131],
      down: APW_MEDIA[132],
      victory: APW_MEDIA[133],
    },
    "Drako Savage": {
      idle: APW_MEDIA[134],
      walk: APW_MEDIA[135],
      strike: APW_MEDIA[136],
      grapple: APW_MEDIA[137],
      hit: APW_MEDIA[138],
      finisher: APW_MEDIA[139],
      down: APW_MEDIA[140],
      victory: APW_MEDIA[141],
    },
    "Trashbag Dan": {
      idle: APW_MEDIA[142],
      walk: APW_MEDIA[143],
      strike: APW_MEDIA[144],
      grapple: APW_MEDIA[145],
      hit: APW_MEDIA[146],
      finisher: APW_MEDIA[147],
      down: APW_MEDIA[148],
      victory: APW_MEDIA[149],
    },
    "Eli Driftwood": {
      idle: APW_MEDIA[150],
      walk: APW_MEDIA[151],
      strike: APW_MEDIA[152],
      grapple: APW_MEDIA[153],
      hit: APW_MEDIA[154],
      finisher: APW_MEDIA[155],
      down: APW_MEDIA[156],
      victory: APW_MEDIA[157],
    },
    "Jay Payne": {
      idle: APW_MEDIA[158],
      walk: APW_MEDIA[159],
      strike: APW_MEDIA[160],
      grapple: APW_MEDIA[161],
      hit: APW_MEDIA[162],
      finisher: APW_MEDIA[163],
      down: APW_MEDIA[164],
      victory: APW_MEDIA[165],
    },
    "The Outlaw": {
      idle: APW_MEDIA[166],
      walk: APW_MEDIA[167],
      strike: APW_MEDIA[168],
      grapple: APW_MEDIA[169],
      hit: APW_MEDIA[170],
      finisher: APW_MEDIA[171],
      down: APW_MEDIA[172],
      victory: APW_MEDIA[173],
    },
    "Black Diamond": {
      idle: APW_MEDIA[174],
      walk: APW_MEDIA[175],
      strike: APW_MEDIA[176],
      grapple: APW_MEDIA[177],
      hit: APW_MEDIA[178],
      finisher: APW_MEDIA[179],
      down: APW_MEDIA[180],
      victory: APW_MEDIA[181],
    },
    "Hotshot Hansel": {
      idle: APW_MEDIA[182],
      walk: APW_MEDIA[183],
      strike: APW_MEDIA[184],
      grapple: APW_MEDIA[185],
      hit: APW_MEDIA[186],
      finisher: APW_MEDIA[187],
      down: APW_MEDIA[188],
      victory: APW_MEDIA[189],
    },
    "Evangeline Strange": {
      idle: APW_MEDIA[190],
      walk: APW_MEDIA[191],
      strike: APW_MEDIA[192],
      grapple: APW_MEDIA[193],
      hit: APW_MEDIA[194],
      finisher: APW_MEDIA[195],
      down: APW_MEDIA[196],
      victory: APW_MEDIA[197],
    },
    "The Gatekeeper": {
      idle: APW_MEDIA[198],
      walk: APW_MEDIA[199],
      strike: APW_MEDIA[200],
      grapple: APW_MEDIA[201],
      hit: APW_MEDIA[202],
      finisher: APW_MEDIA[203],
      down: APW_MEDIA[204],
      victory: APW_MEDIA[205],
    },
  };
  const roster = window.APW_ROSTER_SPRITES || embeddedFinisherSprites;
  const names = Object.keys(roster);
  const available = names.length ? names : Object.keys(moves);
  for (const n of available) {
    const opt = document.createElement("option");
    opt.value = n;
    opt.textContent = n;
    sel.appendChild(opt);
  }
  let timers = [],
    lastTrigger = 0;
  function clear() {
    timers.forEach(clearTimeout);
    timers = [];
  }
  function later(fn, ms) {
    timers.push(setTimeout(fn, ms));
  }
  function frame(name, pose) {
    const f =
      roster[name] ||
      embeddedFinisherSprites[name] ||
      embeddedFinisherSprites["Gideon Hark"];
    return f ? f[pose] || f.idle : "";
  }
  function showFighter(id, name, pose) {
    const el = $(id),
      art = frame(name, pose);
    el.src = art;
    el.style.setProperty("background-image", 'url("' + art + '")', "important");
    el.style.setProperty("background-size", "contain", "important");
    el.style.setProperty("background-position", "center bottom", "important");
    el.style.setProperty("background-repeat", "no-repeat", "important");
    el.style.setProperty("display", "block", "important");
    el.style.setProperty("visibility", "visible", "important");
    el.style.setProperty("opacity", "1", "important");
  }

  function start(name) {
    clear();
    if (!available.includes(name)) name = available[0];
    if (!name) return;
    sel.value = name;
    const [move, style] = moves[name] || ["SIGNATURE FINISHER", "spin"];
    const opponent =
      name === "Bruza The Serb" ? "Gideon Hark" : "Bruza The Serb";
    $("apw49name").textContent = name.toUpperCase();
    $("apw49move").textContent = move;
    $("apw49a").src = frame(name, "idle");
    $("apw49b").src = frame(opponent, "idle");
    $("apw49a").alt = name;
    $("apw49b").alt = opponent;
    document.body.appendChild(stage);
    stage.style.setProperty("z-index", "2147483647", "important");
    stage.classList.add("open");
    stage.dataset.beat = "idle";
    later(() => {
      stage.dataset.beat = "approach";
      $("apw49a").src = frame(name, "walk");
    }, 250);
    later(() => {
      stage.dataset.beat = style;
      showFighter("apw49a", name, style === "flight" ? "finisher" : "grapple");
      $("apw49b").src = frame(opponent, "hit");
    }, 850);
    later(() => {
      stage.dataset.beat = "impact";
      $("apw49a").src = frame(name, "finisher");
      $("apw49b").src = frame(opponent, "down");
    }, 1530);
    later(() => {
      stage.dataset.beat = "victory";
      $("apw49a").src = frame(name, "victory");
      $("apw49b").src = frame(opponent, "down");
    }, 2250);
  }
  function close() {
    clear();
    stage.classList.remove("open");
    stage.dataset.beat = "idle";
  }
  $("apw49launch").addEventListener("click", () =>
    start(document.getElementById("careerWrestler")?.value || "Gideon Hark"),
  );
  $("apw49play").addEventListener("click", () => start(sel.value));
  $("apw49close").addEventListener("click", close);
  sel.addEventListener("change", () => start(sel.value));
  stage.addEventListener("click", (e) => {
    if (e.target === stage) close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && stage.classList.contains("open")) close();
  });
  // Hook existing single-player finisher animation without changing combat damage or rules.
  const fighter = $("gideon");
  if (fighter) {
    new MutationObserver(() => {
      if (
        fighter.classList.contains("finishing") &&
        Date.now() - lastTrigger > 1900 &&
        !stage.classList.contains("open")
      ) {
        lastTrigger = Date.now();
        start(
          document.getElementById("careerWrestler")?.value || "Gideon Hark",
        );
      }
    }).observe(fighter, { attributes: true, attributeFilter: ["class"] });
  }
  window.APW_FINISHER_PREVIEW = start;
})();
