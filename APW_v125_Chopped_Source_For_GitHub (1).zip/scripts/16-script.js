/* Heavyweight title match */
(() => {
  "use strict";
  const el = (id) => document.getElementById(id),
    KEY = "apwMainEvent33";
  const initial = () => ({
    phase: 0,
    hp: 125,
    bruza: 175,
    stamina: 85,
    momentum: 0,
    turn: 0,
    proof: 0,
    ally: false,
    nikki: 0,
    result: "",
    log: "",
  });
  let st;
  try {
    st = window.APW_TEAM_B.restore(
      initial(),
      JSON.parse(localStorage.getItem(KEY) || "{}"),
    );
  } catch (e) {
    st = initial();
  }
  const save = () => {
    try {
      window.APW_TEAM_B.store(KEY, JSON.stringify(st));
    } catch (e) {}
  };
  const cage = () => {
    try {
      return JSON.parse(localStorage.getItem("apwCage32") || "null");
    } catch (e) {
      return null;
    }
  };
  const name = () => window.APW_CAREER?.name || "Your wrestler";
  const add = (label, fn, disabled = false) => {
    let b = document.createElement("button");
    b.textContent = label;
    b.disabled = disabled;
    b.onclick = () => {
      fn();
      save();
      render();
    };
    el("apw33Buttons").append(b);
  };
  function render() {
    el("apw33Buttons").replaceChildren();
    const unlocked =
      (cage()?.phase === 4 && cage()?.finish === "win") || st.phase > 0;
    el("apw33Canvas").hidden = st.phase !== 3 || !unlocked;
    el("apw33Stats").textContent =
      st.phase === 3
        ? `YOU ${st.hp} HP | BRUZA ${st.bruza} HP\nSTAMINA ${st.stamina} | MOMENTUM ${st.momentum} | TURN ${st.turn + 1}`
        : "";
    let show = (t) => (el("apw33Story").textContent = t);
    if (!unlocked) {
      show(
        "LOCKED — Win the v3.2 Steel Cage Showdown against Birdman Phil Picasso to earn your championship opportunity. Your previous progress is preserved.",
      );
      add("↻ Check cage result", () => {});
      return;
    }
    if (st.phase === 0) {
      show(
        "CHAPTER 16 — THE CONTRACT\n\nEvangeline Strange reluctantly signs the championship contract. Bruza The Serb waits in the ring, APW Heavyweight Championship over his shoulder. Nikki Poteet warns that nobody takes the belt without a fight.\n\nDavid Hilder has been appointed referee.",
      );
      add("🔎 Review the suspicious contract", () => {
        st.proof++;
        st.phase = 1;
      });
      add("🎤 Demand a fair match", () => {
        st.momentum += 12;
        st.phase = 1;
      });
      return;
    }
    if (st.phase === 1) {
      show(
        "CHAPTER 17 — CHOOSE YOUR CORNER\n\nDoomslayer and Taras Jones offer to keep an eye on Nikki. Evangeline warns that anyone who interferes will be banned.\n\nYour choice changes the match.",
      );
      add("🤝 Put allies at ringside", () => {
        st.ally = true;
        st.phase = 2;
      });
      add("🔥 Walk out alone (+momentum)", () => {
        st.ally = false;
        st.momentum += 20;
        st.phase = 2;
      });
      return;
    }
    if (st.phase === 2) {
      show(
        "CHAPTER 18 — THE APW HEAVYWEIGHT MAIN EVENT\n\nThe arena lights fall. Bruza The Serb enters wearing the heavyweight title. Nikki Poteet follows him to ringside.\n\n" +
          name().toUpperCase() +
          " VS BRUZA THE SERB\n\nWin by pinfall after reducing Bruza to 0 HP. Strike builds stamina; grapple builds momentum; guard restores health and stamina. A finisher uses 50 momentum and a base 50 stamina; Speed training reduces its stamina cost.",
      );
      add("🔔 START TITLE MATCH", () => {
        if (!Number.isFinite(st.entranceMomentum))
          st.entranceMomentum =
            st.turn > 0 ? 0 : Math.max(0, Math.min(100, st.momentum));
        if (!Number.isFinite(st.entranceProof))
          st.entranceProof = Math.max(0, Math.min(100, st.proof));
        st.entranceMomentum = Math.max(
          0,
          Math.min(100, Math.floor(st.entranceMomentum)),
        );
        st.entranceProof = Math.max(
          0,
          Math.min(100, Math.floor(st.entranceProof)),
        );
        st.momentum = st.entranceMomentum;
        st.proof = st.entranceProof;
        st.phase = 3;
        st.hp = 125;
        st.trainingStats = APW_GROWTH.stats();
        st.bruza = 175;
        st.stamina = 85;
        st.turn = 0;
        st.nikki = 0;
        st.log = "The bell rings! Bruza charges across the canvas!";
        APW_STAKES.init(st);
      });
      return;
    }
    if (st.phase === 3) {
      show(
        "APW HEAVYWEIGHT CHAMPIONSHIP\n" +
          name() +
          " vs BRUZA THE SERB\n\n" +
          st.log,
      );
      add("👊 Strike", () => fight("strike"));
      add(
        "🤼 Grapple",
        () => fight("grapple"),
        st.stamina < APW_GROWTH.cost(9, st.trainingStats),
      );
      add("🛡️ Guard / Recover", () => fight("guard"));
      add(
        "💥 Signature Finisher",
        () => fight("finish"),
        st.stamina < APW_GROWTH.cost(50, st.trainingStats) || st.momentum < 50,
      );
      add("📣 Expose Nikki", () => fight("expose"), st.proof === 0);
      add("↩ Restart entrance", () => {
        st.phase = 2;
      });
      return;
    }
    if (st.phase === 4) {
      show(
        "CHAPTER 19 — THE CHAMPIONSHIP VERDICT\n\n" +
          st.log +
          "\n\n" +
          (st.result === "win"
            ? "NEW APW HEAVYWEIGHT CHAMPION: " +
              name().toUpperCase() +
              "! David Hilder raises your hand as confetti rains down. Birdman watches from the aisle while Evangeline Strange forces a smile."
            : "Bruza retains the APW Heavyweight Championship. Nikki celebrates, but the footage of Evangeline’s conspiracy may yet change the future of the Tower.") +
          "\n\nAPW IS NO TEA PARTY!",
      );
      add("🔁 Championship rematch", () => {
        st.phase = 2;
        st.result = "";
      });
      add("↩ Replay main-event story", () => {
        st = initial();
      });
      return;
    }
  }
  function finish(win, msg) {
    if (st.phase !== 3) return;
    APW_GROWTH.reward(win, st.trainingStats);
    if (win) window.APW_TOWER?.title();
    st.phase = 4;
    st.result = win ? "win" : "loss";
    st.log = msg;
  }
  function fight(type) {
    if (
      st.phase !== 3 ||
      (type === "grapple" &&
        st.stamina < APW_GROWTH.cost(9, st.trainingStats)) ||
      (type === "finish" &&
        (st.stamina < APW_GROWTH.cost(50, st.trainingStats) ||
          st.momentum < 50)) ||
      (type === "expose" && st.proof === 0)
    )
      return;
    APW_STAKES.clearNotices(st);
    let msg = "",
      damage = 0,
      guard = false;
    const turn = st.turn;
    if (type === "strike") {
      damage = 14 + (turn % 5);
      st.stamina = Math.min(
        100,
        st.stamina + 9 + APW_GROWTH.recovery(st.trainingStats),
      );
      st.momentum = Math.min(
        100,
        st.momentum + 12 + APW_GROWTH.momentum(st.trainingStats),
      );
      msg = "A stiff strike lands!";
    }
    if (type === "grapple") {
      damage = 22 + (turn % 6);
      st.stamina = Math.max(
        0,
        st.stamina - APW_GROWTH.cost(9, st.trainingStats),
      );
      st.momentum = Math.min(
        100,
        st.momentum + 18 + APW_GROWTH.momentum(st.trainingStats),
      );
      msg = "You slam Bruza into the canvas!";
    }
    if (type === "guard") {
      guard = true;
      st.hp = Math.min(125, st.hp + 12);
      st.stamina = Math.min(
        100,
        st.stamina + 24 + APW_GROWTH.recovery(st.trainingStats),
      );
      msg = "You block the attack and recover.";
    }
    if (type === "finish") {
      damage = 64;
      st.stamina -= APW_GROWTH.cost(50, st.trainingStats);
      st.momentum -= 50;
      msg = "SIGNATURE FINISHER! THE ENTIRE ARENA ERUPTS!";
    }
    if (type === "expose") {
      st.proof = 0;
      st.nikki = 2;
      st.momentum = Math.min(
        100,
        st.momentum + 18 + APW_GROWTH.momentum(st.trainingStats),
      );
      msg =
        "You show David Hilder the suspicious orders. Nikki is warned and kept away from the apron!";
    }
    damage = APW_GROWTH.hit(damage, st.trainingStats);
    if (damage) st.bruza = Math.max(0, st.bruza - damage);
    if (st.bruza === 0) {
      finish(true, msg + "\nONE! TWO! THREE! THE TITLE CHANGES HANDS!");
      return;
    }
    let interferenceDamage = 0;
    let counter = 12 + ((turn * 5) % 11);
    if (guard) counter = Math.floor(counter / 3);
    if (turn % 4 === 2 && st.nikki === 0) {
      if (st.ally) {
        msg += "\nYour allies catch Nikki reaching for a chair!";
        st.nikki = 2;
        counter = 0;
      } else {
        msg += "\nNikki distracts David Hilder! Bruza lands a cheap shot!";
        counter += 12;
        interferenceDamage = 12;
      }
    }
    if (st.nikki > 0) st.nikki--;
    if (turn % 5 === 4) {
      counter += 7;
      msg += "\nBRUZA HITS THE RUSSIAN LEG SWEEP!";
    }
    counter = APW_STAKES.counter(st, counter, interferenceDamage, "main");
    counter = APW_GROWTH.hurt(counter, st.trainingStats);
    st.hp = Math.max(0, st.hp - counter);
    st.turn++;
    st.log =
      msg + APW_STAKES.note(st) + "\nBruza answers for " + counter + " damage.";
    if (st.hp === 0)
      finish(false, st.log + "\nONE! TWO! THREE! BRUZA RETAINS!");
  }
  const canvas = el("apw33Canvas"),
    g = canvas.getContext("2d");
  g.imageSmoothingEnabled = false;
  let ticks = 0;
  function draw() {
    ticks++;
    if (!canvas.hidden) {
      g.fillStyle = "#10132b";
      g.fillRect(0, 0, 480, 260);
      for (let x = 0; x < 480; x += 16) {
        g.fillStyle = (x / 16) % 3 === 0 ? "#623755" : "#302d50";
        g.fillRect(x, 32, 12, 74);
      }
      g.fillStyle = "#6e5074";
      g.fillRect(18, 157, 444, 80);
      g.fillStyle = "#b2a1c6";
      g.fillRect(18, 157, 444, 8);
      for (let y = 105; y < 155; y += 18) {
        g.fillStyle = "#f3e7dc";
        g.fillRect(8, y, 464, 3);
      }
      g.fillStyle = "#f5cb64";
      g.font = "bold 17px monospace";
      g.fillText("APW • HEAVYWEIGHT TITLE", 106, 25);
      function wrestler(x, bruza) {
        let y = Math.round(Math.sin(ticks / 13 + (bruza ? 2 : 0)) * 3);
        g.save();
        g.translate(x, 210 + y);
        const r = (a, b, w, h, c) => {
          g.fillStyle = c;
          g.fillRect(a, b, w, h);
        };
        r(-23, -46, 18, 46, "#171b2a");
        r(6, -46, 18, 46, "#171b2a");
        r(-26, -83, 52, 41, bruza ? "#151b29" : "#a63b69");
        r(-29, -121, 58, 42, bruza ? "#c78b73" : "#bb816c");
        r(-37, -114, 11, 41, "#c68e73");
        r(26, -114, 11, 41, "#c68e73");
        r(-17, -151, 34, 34, "#cf9477");
        r(-12, -137, 6, 4, "#16121a");
        r(6, -137, 6, 4, "#16121a");
        if (bruza) {
          r(-23, -80, 46, 12, "#bc263f");
          r(-5, -80, 11, 12, "#f0e5df");
          r(-13, -120, 26, 5, "#3b2526");
        } else {
          r(-18, -155, 36, 10, "#35232d");
        }
        g.restore();
      }
      wrestler(147, false);
      wrestler(331, true);
      g.fillStyle = "#fff";
      g.font = "bold 11px monospace";
      g.fillText(name().slice(0, 19).toUpperCase(), 12, 250);
      g.fillText("BRUZA THE SERB", 363, 250);
      g.fillStyle = "#f6ca58";
      g.fillRect(388, 44, 44, 10);
      g.fillStyle = "#f2dca6";
      g.fillRect(405, 40, 10, 18);
    }
    requestAnimationFrame(draw);
  }
  draw();
  el("careerWrestler")?.addEventListener("change", render);
  render();

  window.APW_TEAM_B.register(() => {
    st = initial();
    save();
    render();
  });
  window.addEventListener("apw:path-refresh", render);
})();
