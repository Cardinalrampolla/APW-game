/* Presentation follows the committed career and existing progression controller. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const style = document.createElement("style");
  style.textContent = `
  #fighters .fighter.apw114-cel-ready > canvas.apw114-cel{inset:auto!important;left:-20%!important;bottom:0!important;width:140%!important;height:100%!important;object-position:center bottom!important}
  .apw117-chapter{border:1px solid #be76db;border-top:3px solid #ff61c5;border-radius:12px;padding:16px;margin-bottom:16px;background:radial-gradient(ellipse at top,#332048,#12172c);box-shadow:0 0 20px #ea47d51a}
  .apw117-chapter h2{font:900 17px monospace;color:#ffe2a4;margin:0 0 10px}.apw117-cast{display:grid;grid-template-columns:76px minmax(0,1fr) 76px;gap:10px;align-items:center}.apw117-cast img{width:76px;height:106px;object-fit:contain;image-rendering:pixelated;filter:drop-shadow(0 3px 5px #050516)}.apw117-cast img:last-child{scale:-1 1}.apw117-cast p{margin:3px 0;font:12px/1.5 monospace}.apw117-go{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.apw117-go button,#apw117Next{min-height:44px;padding:10px;border:1px solid #78eaff;background:#271d3a;color:#fff;border-radius:6px;font-weight:bold}
  #apw117Next{margin:16px 0;width:100%;border-color:#ffb4df}.apw117-choices{color:#9fe4ee;font:12px/1.5 monospace;margin-top:10px}
  #apw117Dirty{position:absolute;inset:0;z-index:1500;pointer-events:none;overflow:hidden;border:3px solid #ffd66c;box-shadow:inset 0 0 44px #ffc14b66;animation:apw117-cheat 1.3s ease-out both}#apw117Dirty[data-outcome=caught]{border-color:#ff416c;box-shadow:inset 0 0 60px #ef224866}
  #apw117Dirty .call{position:absolute;top:7%;left:4%;right:4%;padding:9px;background:#101329ed;border:1px solid #ffe497;color:#fff0ac;text-align:center;font:900 clamp(12px,3vw,20px) monospace;text-shadow:2px 2px #000}#apw117Dirty .call small{display:block;font-size:10px;color:#fff;margin-top:5px}
  #apw117Dirty .contact{position:absolute;left:58%;top:58%;font:bold 50px monospace;color:#fff8ae;text-shadow:0 0 12px #ff703e;animation:apw117-contact .65s .12s both}#apw117Dirty[data-outcome=caught] .contact{left:43%;color:#ff6686}
  @keyframes apw117-cheat{0%{opacity:0}12%,75%{opacity:1}100%{opacity:0}}@keyframes apw117-contact{0%{scale:.2;opacity:0;rotate:-20deg}40%{scale:1.5;opacity:1}100%{scale:1.8;opacity:0}}
  @media(prefers-reduced-motion:reduce){#apw117Dirty,#apw117Dirty .contact{animation:none!important}#apw117Dirty .contact{font-size:32px}}
  `;
  document.head.append(style);
  const card = document.createElement("section");
  card.className = "apw117-chapter";
  card.id = "apw117Chapter";
  card.innerHTML =
    '<h2>YOUR APW STORY</h2><div class="apw117-cast"><img alt=""><div><p id="apw117Identity"></p><p id="apw117Objective"></p></div><img alt=""></div><p class="apw117-choices" id="apw117Choices"></p><div class="apw117-go"><button type="button" id="apw117Resume">CONTINUE YOUR STORY ▶</button><button type="button" id="apw117Train">TRAINING</button></div>';
  $("apw105-career").insertBefore(card, $("apwCareerPath"));
  $("apw117Resume").onclick = () => window.APW_PATH.continue();
  $("apw117Train").onclick = () => window.APW_JOURNEY.view("training");
  const next = document.createElement("button");
  next.type = "button";
  next.id = "apw117Next";
  next.textContent = "CONTINUE CAREER ▶";
  next.hidden = true;
  next.onclick = () => window.APW_PATH.continue();
  $("apw105-match").append(next);
  const read = (key) => {
    try {
      const v = JSON.parse(localStorage.getItem(key) || "null");
      return v && (!v._career || v._career === window.APW_CAREER.name)
        ? v
        : null;
    } catch {
      return null;
    }
  };
  function update() {
    const name = window.APW_CAREER.name,
      task = window.APW_PATH.objective(),
      story = read("apwStory27");
    const rival =
      task[1] === ".arena"
        ? [
            "The Gatekeeper",
            "Trucker Mark Taylor",
            "Harvey Falco",
            "Al Straya",
            "Simon Temple",
          ][task[2]]
        : task[1].includes("34")
          ? read("apwChampion34")?.challenger || "Bruza The Serb"
          : task[1].includes("33") || task[1].includes("30")
            ? "Bruza The Serb"
            : "Birdman Phil Picasso";
    $("apw117Identity").textContent =
      name + " · " + window.APW_CAREER.wins + " career wins";
    $("apw117Objective").textContent = task[0];
    const allies = Array.isArray(story?.allies) ? story.allies : [];
    $("apw117Choices").textContent = story
      ? "ALLIES: " +
        (allies.join(", ") || "Working alone") +
        " · RESPECT " +
        story.respect +
        " · HEAT " +
        story.heat
      : "Defeat The Gatekeeper to begin your APW story.";
    [name, rival].forEach((who, i) => {
      const im = card.querySelectorAll("img")[i],
        src = window.APW_ROSTER_SPRITES?.[who]?.idle;
      if (src && im.dataset.wrestler !== who) {
        im.src = src;
        im.alt = who;
        im.dataset.wrestler = who;
      }
    });
    const battleDone = $("status").textContent === "MATCH OVER";
    const target = $("apw105-match").querySelector(
      "#apwPolitics:not([hidden]),#apw28:not([hidden]),#apw30:not([hidden]),#apw32:not([hidden]),#apw33:not([hidden]),#apw34:not([hidden])",
    );
    // Never offer a progress shortcut while an active story fight is running.
    next.hidden = !!target || !battleDone;
  }
  let scheduled = false;
  function queue() {
    if (scheduled) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      update();
    });
  }
  window.addEventListener("apw:path-refresh", queue);
  window.addEventListener("apw:career-changed", queue);
  new MutationObserver(queue).observe($("status"), {
    childList: true,
    subtree: true,
  });
  let timer = 0;
  function clear() {
    clearTimeout(timer);
    $("apw117Dirty")?.remove();
  }
  window.addEventListener("apw:dirty-trick", (event) => {
    clear();
    const detail = event.detail;
    if (!detail || detail.wrestler !== window.APW_CAREER.name) return;
    const overlay = document.createElement("div");
    overlay.id = "apw117Dirty";
    overlay.dataset.outcome = detail.outcome;
    overlay.setAttribute("role", "status");
    const label = document.createElement("div");
    label.className = "call";
    label.textContent =
      detail.outcome === "caught"
        ? "HILDER CAUGHT IT — DQ!"
        : "UNDERHANDED SHOT!";
    const line = document.createElement("small");
    line.textContent =
      detail.wrestler +
      (detail.outcome === "caught"
        ? " gets caught by David Hilder."
        : " strikes while Hilder is distracted.");
    label.append(line);
    const contact = document.createElement("span");
    contact.className = "contact";
    contact.textContent = detail.outcome === "caught" ? "DQ" : "✹";
    contact.setAttribute("aria-hidden", "true");
    overlay.append(label, contact);
    document.querySelector(".arena").append(overlay);
    timer = setTimeout(clear, 1600);
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) clear();
  });
  $("restart").addEventListener("click", clear);
  window.addEventListener("apw:career-changed", clear);
  const played = new Set();
  window.addEventListener("apw:career-changed", () => played.clear());
  document.addEventListener(
    "click",
    (event) => {
      const b = event.target.closest?.("button");
      if (!b || b.disabled) return;
      const parent = b.parentElement?.id,
        label = b.textContent.toLowerCase();
      let scene, key, field, value;
      if (parent === "apw30Actions" && label.includes("start eliminator")) {
        scene = "nikki";
        key = "apwConspiracy30";
        field = "stage";
        value = 3;
      } else if (parent === "apw32Buttons" && label.includes("ring the bell")) {
        scene = "cageNight";
        key = "apwCage32";
        field = "phase";
        value = 3;
      } else if (parent === "apw28Actions" && label.includes("reveal")) {
        scene = "authority";
        key = "apwShowdown28";
        field = "phase";
        value = 4;
      }
      if (!scene) return;
      const name = window.APW_CAREER.name;
      setTimeout(() => {
        if (
          name !== window.APW_CAREER.name ||
          read(key)?.[field] !== value ||
          played.has(scene) ||
          $("apw106overlay")?.classList.contains("open")
        )
          return;
        played.add(scene);
        window.APW_STORY_106.play(scene);
      }, 0);
    },
    true,
  );
  update();
})();
