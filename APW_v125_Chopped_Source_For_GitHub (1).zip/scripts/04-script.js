/* Career identity */
window.APW_CAREER = window.APW_CAREER || {
  name: "Gideon Hark",
  wins: 0,
  qualified: false,
};
function apwLoad() {
  try {
    let d = JSON.parse(localStorage.getItem("apwCareer08") || "{}");
    if (
      d.name &&
      document.querySelector(
        '#careerWrestler option[value="' + CSS.escape(d.name) + '"]',
      )
    ) {
      APW_CAREER.name = d.name;
      APW_CAREER.wins = Number.isFinite(d.wins)
        ? Math.max(0, Math.floor(d.wins))
        : 0;
      APW_CAREER.qualified = d.qualified === true;
    }
  } catch (e) {}
  document.getElementById("careerWrestler").value = APW_CAREER.name;
  apwPaint();
  document.getElementById("restart").click();
}
function apwPaint() {
  document.getElementById("careerRecord").textContent =
    "WINS " +
    APW_CAREER.wins +
    " · " +
    (APW_CAREER.qualified
      ? "APW TOWER ENTRY EARNED"
      : "QUALIFIER: THE GATEKEEPER");
  document.getElementById("careerNote").textContent = APW_CAREER.qualified
    ? "The Gatekeeper has been defeated. Choose an unlocked APW Tower floor to continue."
    : "Defeat The Gatekeeper to qualify for the APW Tower.";
  const label = document.getElementById("careerName");
  if (label) label.textContent = APW_CAREER.name;
}
function apwSave() {
  try {
    window.APW_TEAM_B.store("apwCareer08", JSON.stringify(APW_CAREER));
  } catch (e) {}
}
function apwChoose(v) {
  window.APW_OPPONENT = "The Gatekeeper";
  APW_CAREER = { name: v, wins: 0, qualified: false };
  apwSave();
  apwPaint();
  document.getElementById("restart").click();
}
function apwVictory() {
  APW_CAREER.wins++;
  APW_CAREER.qualified = true;
  apwSave();
  apwPaint();
}
window.addEventListener("DOMContentLoaded", apwLoad);
