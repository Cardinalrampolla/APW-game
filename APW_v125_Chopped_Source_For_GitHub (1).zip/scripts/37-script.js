/* APW v11.4 — frame-by-frame pixel atlas player.
 * Eight independently-rasterized cels per action; ten animation cycles per wrestler.
 * The original artwork remains as a fallback until an atlas has decoded.
 * Combat math, timers, menus, career state, and save keys are untouched.
 */
(() => {
  "use strict";
  const names = ["Gideon Hark", "Simon Temple", "Whiskey Sixx", "Mauler Y"];
  const actions = [
    "idle",
    "guard",
    "walk",
    "strike",
    "grapple",
    "finisher",
    "hurt",
    "down",
    "victory",
    "tag",
  ];
  const actionRow = Object.fromEntries(actions.map((a, i) => [a, i]));
  const W = 164,
    H = 182,
    FRAMES = 8;
  const looping = new Set(["idle", "guard", "walk", "victory", "tag"]);
  const rate = {
    idle: 105,
    guard: 110,
    walk: 84,
    strike: 82,
    grapple: 96,
    finisher: 92,
    hurt: 91,
    down: 115,
    victory: 116,
    tag: 85,
  };
  const atlas = [];
  const states = new Map();
  let run = false,
    lastTick = 0;
  const reduced = () =>
    window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
  function createCanvas(node, channel) {
    let canvas = node.querySelector("canvas.apw114-cel");
    if (!canvas) {
      canvas = document.createElement("canvas");
      canvas.className = "apw114-cel";
      canvas.width = W;
      canvas.height = H;
      canvas.setAttribute("aria-hidden", "true");
      canvas.dataset.channel = channel;
      node.append(canvas);
    }
    return canvas;
  }
  function mount(id, node, index, channel) {
    const canvas = createCanvas(node, channel);
    let s = states.get(id);
    if (s && s.node === node && s.index === index) return s;
    if (s && s.node !== node) s.node.classList.remove("apw114-cel-ready");
    s = {
      node,
      canvas,
      ctx: canvas.getContext("2d", { alpha: true }),
      index,
      action: "idle",
      frame: 0,
      elapsed: 0,
      channel,
      drawn: -1,
    };
    if (s.ctx) s.ctx.imageSmoothingEnabled = false;
    states.set(id, s);

    return s;
  }
  function pose(s, action) {
    if (!(action in actionRow)) action = "idle";
    if (s.action === action) return;
    s.action = action;
    s.frame = 0;
    s.elapsed = 0;
    s.drawn = -1;
  }
  function tagPose(i, action) {
    const n = document.getElementById("tagfighter" + i);
    if (!n || i < 0 || i > 3) return;
    const s = mount("tag" + i, n, i, "tag");
    pose(s, action === "walk2" ? "walk" : action);
  }
  function syncTag() {
    for (let i = 0; i < 4; i++) {
      const node = document.getElementById("tagfighter" + i);
      if (!node) continue;
      const image = node.querySelector(".apw99-art");
      const s = mount("tag" + i, node, i, "tag");
      const wanted = image?.dataset.pose || "idle";
      pose(s, wanted === "walk2" ? "walk" : wanted);
    }
  }
  function singleAction(el) {
    for (const [klass, p] of [
      ["finishing", "finisher"],
      ["slowhit", "finisher"],
      ["spinning", "grapple"],
      ["grabbing", "grapple"],
      ["flyback", "hurt"],
      ["down", "down"],
      ["fall", "down"],
      ["hit", "hurt"],
      ["hurt", "hurt"],
      ["attack", "strike"],
      ["lunge", "strike"],
      ["strike", "strike"],
      ["grapple", "grapple"],
      ["walk", "walk"],
      ["walkA", "walk"],
      ["walkB", "walk"],
      ["victory", "victory"],
    ])
      if (el.classList.contains(klass)) return p;
    const pose = el.dataset.apwPose || el.dataset.apw82Pose || "idle";
    return (
      {
        hit: "hurt",
        fall: "down",
        walkA: "walk",
        walkB: "walk",
        grab: "grapple",
        rise: "guard",
      }[pose] || pose
    );
  }
  function syncSingles() {
    const who = [
      window.APW_CAREER?.name ||
        document.getElementById("careerWrestler")?.value ||
        "Gideon Hark",
      window.APW_OPPONENT || "The Gatekeeper",
    ];
    ["gideon", "gatekeeper"].forEach((id, i) => {
      const n = document.getElementById(id);
      if (!n) return;
      const index = names.indexOf(who[i]);
      if (index < 0) {
        if (n.classList.contains("apw114-cel-ready"))
          n.classList.remove("apw114-cel-ready");
        if (states.has("single" + i)) states.delete("single" + i);
        n.querySelector("canvas.apw114-cel")?.remove();
        return;
      }
      const s = mount("single" + i, n, index, "single");
      pose(s, singleAction(n));
    });
  }
  function draw(s) {
    const image = atlas[s.index];
    if (!image?.complete || !image.naturalWidth || !s.ctx) return;
    if (s.drawn === actionRow[s.action] * FRAMES + s.frame) return;
    s.ctx.clearRect(0, 0, W, H);
    s.ctx.drawImage(
      image,
      s.frame * W,
      actionRow[s.action] * H,
      W,
      H,
      0,
      0,
      W,
      H,
    );
    s.drawn = actionRow[s.action] * FRAMES + s.frame;
    if (!s.node.classList.contains("apw114-cel-ready"))
      s.node.classList.add("apw114-cel-ready");
    s.canvas.dataset.pose = s.action;
    s.canvas.dataset.frame = String(s.frame);
    s.canvas.dataset.wrestler = names[s.index];
  }
  function step(s, dt) {
    if (!looping.has(s.action) && s.frame >= FRAMES - 1) return;
    s.elapsed += dt;
    const interval = rate[s.action] || 100;
    if (s.elapsed >= interval) {
      const moves = Math.min(4, Math.floor(s.elapsed / interval));
      s.elapsed %= interval;
      s.frame = looping.has(s.action)
        ? (s.frame + moves) % FRAMES
        : Math.min(FRAMES - 1, s.frame + moves);
    }
  }
  function loop(now) {
    window.requestAnimationFrame(loop);
    if (document.hidden) return;
    const dt = Math.min(200, Math.max(0, now - (lastTick || now)));
    lastTick = now;
    // Identity and poses may change due to career selection, tag swaps, or a new round.
    if (!run || !document.getElementById("tagarena")) return;
    syncTag();
    syncSingles();
    for (const [id, s] of states) {
      if (!s.node.isConnected) {
        states.delete(id);
        continue;
      }
      if (!s.node.getClientRects().length) continue;
      if (reduced()) s.frame = 0;
      else step(s, dt);
      draw(s);
    }
  }
  function init() {
    if (run) return;
    run = true;
    APW114_SHEETS.forEach((url, i) => {
      const img = new Image();
      atlas[i] = img;
      img.onload = () => {
        for (const s of states.values())
          if (s.index === i) {
            s.drawn = -1;
            draw(s);
          }
      };
      img.src = url;
    });
    window.requestAnimationFrame(loop);
  }
  window.APW114 = {
    init,
    setTagPose: tagPose,
    getStatus: () => ({
      loaded: atlas.map((i) => !!i?.naturalWidth),
      active: [...states.entries()].map(([id, s]) => ({
        id,
        name: names[s.index],
        pose: s.action,
        frame: s.frame,
      })),
    }),
    version: "11.4",
  };
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init, { once: true });
  else init();
})();
