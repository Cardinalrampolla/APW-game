/* Birdman grudge */
(() => {
  "use strict";
  const el = (id) => document.getElementById(id),
    key = "apwShowdown28";
  const fresh = () => ({
    phase: 0,
    hp: 100,
    enemy: 100,
    momentum: 0,
    guard: false,
    turn: 0,
    wins: 0,
    log: "",
    finished: false,
  });
  let s;
  try {
    s = window.APW_TEAM_B.restore(
      fresh(),
      JSON.parse(localStorage.getItem(key) || "{}"),
    );
  } catch (e) {
    s = fresh();
  }
  const story = () => {
    try {
      return window.APW_TEAM_B.story();
    } catch (e) {
      return null;
    }
  };
  const save = () => {
    try {
      window.APW_TEAM_B.store(key, JSON.stringify(s));
    } catch (e) {}
  };
  const name = () =>
    window.APW_CAREER?.name || el("careerWrestler")?.value || "Your wrestler";
  const button = (label, fn, disabled = false) => {
    let b = document.createElement("button");
    b.textContent = label;
    b.disabled = disabled;
    b.addEventListener("click", fn);
    el("apw28Actions").append(b);
  };
  const scene = (t) => (el("apw28Scene").textContent = t);
  function render() {
    const a = el("apw28Actions");
    a.replaceChildren();
    let st = story();
    let unlocked = (st && st.chapter >= 4) || s.phase > 0;
    el("apw28Ring").classList.toggle("hidden", s.phase !== 2 || !unlocked);
    el("apw28Meters").classList.toggle("hidden", s.phase !== 2 || !unlocked);
    if (!unlocked) {
      scene(
        "LOCKED — Finish the four backstage politics chapters above first. Your choices will influence the confrontation.",
      );
      el("apw28Info").textContent =
        "Your original career, tag-team matches and backstage story remain intact.";
      button("↻ Check story progress", render);
      return;
    }
    const ally = (st.allies || []).includes("Doomslayer")
      ? "Doomslayer"
      : (st.allies || []).includes("Taras Jones")
        ? "Taras Jones"
        : null;
    const suspicious = st.decisions?.some(
      (d) => d.chapter === 2 && d.choice === 0,
    );
    const deal = st.decisions?.some((d) => d.chapter === 2 && d.choice === 1);
    el("apw28Info").textContent =
      "Respect " +
      st.respect +
      " · Heat " +
      st.heat +
      " · Ally " +
      (ally || "None") +
      " · Results saved automatically";
    if (s.phase === 0) {
      scene(
        "CHAPTER 5 — THE TRASHBAG AMBUSH\n\nBirdman blocks " +
          name() +
          ' in the backstage corridor. "YOU THINK YOU CAN CLIMB MY TOWER, YOU TEA PARTY NINTENDO WRESTLER?"\n\n' +
          (ally
            ? ally + " stands nearby, ready to help."
            : "The corridor is empty. You may have to face him alone.") +
          "\n\n" +
          (suspicious
            ? "You still have the photograph linking Birdman to Evangeline."
            : deal
              ? "Evangeline has promised protection, but at what cost?"
              : "Evangeline watches from the office doorway."),
      );
      button("🥊 Confront Birdman", () => {
        s.phase = 1;
        s.log = "You stand your ground.";
        save();
        render();
      });
      button("🎤 Call him out publicly", () => {
        s.phase = 1;
        s.momentum = 20;
        s.log = "Your promo fires up the locker room! +20 momentum.";
        save();
        render();
      });
      return;
    }
    if (s.phase === 1) {
      scene(
        'THE OFFICE MAKES ITS MOVE\n\nEvangeline: "APW is no tea party. If you want to settle this, you can do it in the ring."\n\nBirdman grins. David Hilder is called to referee a sanctioned grudge match.\n\n' +
          s.log,
      );
      button("🔔 Start grudge match", () => {
        s.phase = 2;
        s.hp = 100;
        s.trainingStats = APW_GROWTH.stats();
        s.enemy = 100;
        s.turn = 0;
        s.guard = false;
        s.log = "David Hilder calls for the bell!";
        APW_STAKES.init(s);
        save();
        render();
      });
      return;
    }
    if (s.phase === 2) {
      const meters = el("apw28Meters");
      meters.replaceChildren();
      for (const [label, v] of [
        [name() + " HP", s.hp],
        ["Birdman HP", s.enemy],
      ]) {
        let box = document.createElement("div");
        box.className = "meter";
        box.textContent = label + " · " + Math.max(0, v);
        let track = document.createElement("div");
        track.className = "track28";
        let fill = document.createElement("div");
        fill.className = "fill28";
        fill.style.width = Math.max(0, v) + "%";
        if (label === "Birdman HP") fill.style.background = "#ef5679";
        track.append(fill);
        box.append(track);
        meters.append(box);
      }
      scene(
        "BIRDMAN PHIL PICASSO — GRUDGE MATCH\n\n" +
          s.log +
          "\n\nMomentum: " +
          s.momentum +
          " / 100 · Round " +
          (s.turn + 1),
      );
      button("👊 Strike", () => attack("strike"));
      button("💪 Grapple", () => attack("grapple"));
      button("🛡️ Defend / Recover", () => attack("defend"));
      button("💥 Signature Finisher", () => attack("finish"), s.momentum < 60);
      return;
    }
    if (s.phase === 3) {
      scene(
        "CHAPTER 6 — THE FALLOUT\n\n" +
          s.log +
          "\n\n" +
          (s.wins
            ? "Bruza The Serb acknowledges your victory. Nikki Poteet looks unimpressed."
            : "Birdman celebrates loudly, but your rivalry is far from over.") +
          "\n\n" +
          (suspicious
            ? "Your photograph may expose Evangeline as the mastermind."
            : deal
              ? "Evangeline reminds you that you owe her a favour."
              : "Evangeline refuses to explain her involvement."),
      );
      if (s.wins > 0)
        button("🎬 Reveal next chapter", () => {
          s.phase = 4;
          save();
          render();
        });
      button("🔁 Rematch Birdman", () => {
        s.phase = 1;
        s.hp = 100;
        s.enemy = 100;
        s.momentum = 0;
        save();
        render();
      });
      return;
    }
    if (!s.wins) {
      scene(
        "BIRDMAN WON THE SHOWDOWN\n\nDemand a rematch to earn your route to the championship eliminator. Earlier Tower progress is retained.",
      );
      button("🔁 Rematch Birdman", () => {
        s.phase = 1;
        s.hp = 100;
        s.enemy = 100;
        s.momentum = 0;
        save();
        render();
      });
      return;
    }
    scene(
      "CHAPTER 7 — THE CHAMPIONSHIP CONSPIRACY\n\n" +
        (suspicious
          ? 'You confront Evangeline with the photograph. She admits she gave Birdman access to your training footage, but claims it was to "test your character."'
          : 'A message appears on your phone: "Ask who gave Birdman the training footage."') +
        "\n\n" +
        (ally
          ? ally + " offers to help investigate."
          : "You must decide whom to trust next.") +
        "\n\nBruza awaits at the top of the APW Tower. The championship story continues...",
    );
    button("🔁 Replay showdown only", () => {
      if (confirm("Reset only the v2.8 showdown?")) {
        s = fresh();
        save();
        render();
      }
    });
    button("🏆 Return to APW Tower", () =>
      document
        .querySelector(".career-panel")
        ?.scrollIntoView({ behavior: "smooth" }),
    );
  }
  function attack(kind) {
    if (s.phase !== 2 || (kind === "finish" && s.momentum < 60)) return;
    APW_STAKES.clearNotices(s);
    let st = story() || {},
      ally = s.politics
        ? ["Doomslayer", "Taras Jones"].includes(s.politics.ally)
        : (st.allies || []).some(
            (x) => x === "Doomslayer" || x === "Taras Jones",
          );
    let damage = 0,
      msg = "";
    s.guard = false;
    if (kind === "strike") {
      damage = 11 + ((s.turn * 3) % 6);
      s.momentum = Math.min(
        100,
        s.momentum + 20 + APW_GROWTH.momentum(s.trainingStats),
      );
      msg = name() + " lands a stiff strike!";
    }
    if (kind === "grapple") {
      damage = 15 + ((s.turn * 5) % 7);
      s.momentum = Math.min(
        100,
        s.momentum + 15 + APW_GROWTH.momentum(s.trainingStats),
      );
      msg = name() + " executes a powerful grapple!";
    }
    if (kind === "defend") {
      s.guard = true;
      s.hp = Math.min(100, s.hp + 8);
      s.momentum = Math.min(
        100,
        s.momentum + 12 + APW_GROWTH.momentum(s.trainingStats),
      );
      msg = "You brace yourself and recover 8 HP.";
    }
    if (kind === "finish") {
      damage = 39;
      s.momentum -= 60;
      msg = "SIGNATURE FINISHER! The arena erupts!";
    }
    damage = APW_GROWTH.hit(damage, s.trainingStats);
    s.enemy = Math.max(0, s.enemy - damage);
    if (s.enemy <= 0) {
      s.phase = 3;
      s.wins++;
      APW_GROWTH.reward(true, s.trainingStats);
      if (s.wins === 1 && window.APW_TOWER?.state().floor <= 5)
        window.apwTowerVictory("Birdman Phil Picasso", false);
      s.log =
        msg +
        APW_STAKES.note(s) +
        "\n1... 2... 3! David Hilder declares " +
        name() +
        " the winner!";
      save();
      render();
      return;
    }
    let interferenceDamage = 0;
    let counter = 10 + ((s.turn * 7) % 9) + (st.heat >= 5 ? 3 : 0);
    if (s.guard) counter = Math.max(2, Math.floor(counter * 0.3));
    if (ally && s.turn === 2) {
      counter = 0;
      msg += "\nYour ally distracts Birdman before he can cheat!";
    }
    counter = APW_STAKES.counter(s, counter, interferenceDamage, "grudge");
    counter = APW_GROWTH.hurt(counter, s.trainingStats);
    s.hp = Math.max(0, s.hp - counter);
    s.turn++;
    s.log =
      msg +
      APW_STAKES.note(s) +
      "\nBirdman counters with " +
      (s.turn % 3 === 0 ? "a sneaky low blow!" : "a brutal clothesline!") +
      " You take " +
      counter +
      " damage.";
    if (s.hp <= 0) {
      s.phase = 3;
      s.wins = 0;
      APW_GROWTH.reward(false, s.trainingStats);
      s.log +=
        "\nBirdman pins you after the referee counts three. You can demand a rematch.";
    }
    save();
    render();
  }
  el("politicsChoices")?.addEventListener("click", () => setTimeout(render, 0));
  el("politicsRestart")?.addEventListener("click", () => setTimeout(render, 0));
  render();

  window.APW_TEAM_B.register(() => {
    s = fresh();
    save();
    render();
  });
  window.addEventListener("apw:path-refresh", render);
})();
