/* Singles impact effects */
/* Visual-only observer: adds effects when the original match engine animates fighters. */
(() => {
  const arena = document.querySelector(".arena"),
    layer = document.createElement("div");
  layer.className = "arcade-particles";
  arena.appendChild(layer);
  let last = {};
  function burst(who, heavy = false) {
    const f = document.getElementById(who);
    if (
      !f ||
      (who === "gatekeeper" && arena.hasAttribute("data-apw-dirty-zone"))
    )
      return;
    const ar = arena.getBoundingClientRect(),
      r = f.getBoundingClientRect(),
      x = r.left - ar.left + r.width * 0.52,
      y = r.top - ar.top + r.height * 0.53;
    for (let i = 0; i < (heavy ? 15 : 7); i++) {
      const sp = document.createElement("i");
      sp.className = "arcade-spark";
      sp.style.left = x + "px";
      sp.style.top = y + "px";
      const a = (Math.PI * 2 * i) / (heavy ? 15 : 7),
        dist = (heavy ? 68 : 34) * (0.65 + (i % 3) * 0.2);
      sp.style.setProperty("--dx", Math.cos(a) * dist + "px");
      sp.style.setProperty("--dy", Math.sin(a) * dist + "px");
      layer.appendChild(sp);
      setTimeout(() => sp.remove(), 600);
    }
  }
  for (const who of ["gideon", "gatekeeper"]) {
    const f = document.getElementById(who);
    new MutationObserver(() => {
      let c = f.className,
        prev = last[who] || "";
      if (
        (c.includes(" hit") && !prev.includes(" hit")) ||
        (c.includes(" flyback") && !prev.includes(" flyback"))
      )
        burst(who, c.includes("flyback"));
      if (c.includes(" slowhit") && !prev.includes(" slowhit")) {
        const t = document.createElement("i");
        t.className = "arcade-trail";
        t.style.left = "39%";
        t.style.top = "53%";
        layer.appendChild(t);
        setTimeout(() => t.remove(), 550);
      }
      last[who] = c;
    }).observe(f, { attributes: true, attributeFilter: ["class"] });
  }
})();
