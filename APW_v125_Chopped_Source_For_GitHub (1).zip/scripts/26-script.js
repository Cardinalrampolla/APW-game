/* Portrait gallery */
(function () {
  const art = {
    birdman_normal: APW_MEDIA[211],
    birdman_rage: APW_MEDIA[213],
    birdman_spotlight: APW_MEDIA[214],
    gideon_normal: APW_MEDIA[212],
    gideon_rage: APW_MEDIA[215],
    gideon_spotlight: APW_MEDIA[216],
  };
  const panel = document.getElementById("apw51panel"),
    bird = document.getElementById("apw51bird"),
    gideon = document.getElementById("apw51gideon"),
    dialog = document.getElementById("apw51dialog");
  let mood = "normal",
    timer = null,
    line = 0;
  const scripts = {
    normal: [
      "BIRDMAN: APW IS NO TEA PARTY!",
      "GIDEON: Then you picked the wrong man to intimidate.",
      "BIRDMAN: The Trashbag Police see everything.",
    ],
    rage: [
      "BIRDMAN: TOO MANY FLIPS! TOO MANY TEA PARTY WRESTLERS!",
      "GIDEON: I am coming for you, Birdman.",
      "BIRDMAN: TRY IT!",
    ],
    spotlight: [
      "GIDEON: Somebody is pulling the strings backstage.",
      "BIRDMAN: You have no idea who you are dealing with.",
      "GIDEON: Then I will find out in the ring.",
    ],
  };
  function stop() {
    if (timer !== null) {
      clearTimeout(timer);
      timer = null;
    }
  }
  function setMood(m) {
    stop();
    mood = m;
    line = 0;
    bird.src = art["birdman_" + m];
    gideon.src = art["gideon_" + m];
    dialog.textContent = scripts[m][0];
  }
  function play() {
    stop();
    line = 0;
    function next() {
      dialog.textContent = scripts[mood][line];
      line++;
      if (line < scripts[mood].length) timer = setTimeout(next, 2100);
      else timer = null;
    }
    next();
  }
  document.getElementById("apw51open").onclick = () => {
    panel.classList.add("open");
    setMood("normal");
  };
  document.getElementById("apw51close").onclick = () => {
    stop();
    panel.classList.remove("open");
  };
  document.getElementById("apw51play").onclick = play;
  panel
    .querySelectorAll("[data-mood]")
    .forEach((b) => (b.onclick = () => setMood(b.dataset.mood)));
  setMood("normal");
})();
