/* Visible-only, decoded-frame player. Planted idle poses and deliberate speech gestures. */
(() => {
  "use strict";
  const { frames } = APW_VELVET_ART,
    $ = (id) => document.getElementById(id),
    motion = window.matchMedia?.("(prefers-reduced-motion: reduce)");
  let timer = null;
  const states = new WeakMap();
  const images = frames.map((src) => {
    const im = new Image();
    im.src = src;
    im.onload = refresh;
    return im;
  });
  const sequences = {
    idle: [
      [0, 1500],
      [6, 420],
      [0, 1100],
      [5, 600],
      [0, 900],
    ],
    talk: [
      [3, 600],
      [4, 500],
      [3, 650],
      [6, 320],
      [3, 700],
    ],
    react: [
      [5, 1100],
      [6, 420],
      [5, 800],
    ],
    point: [
      [4, 650],
      [0, 950],
    ],
  };
  const reduced = () => !!motion?.matches || !!$("apw43motion")?.checked;
  function visible(el) {
    return (
      !!el &&
      !document.hidden &&
      !el.closest("[hidden],[inert]") &&
      el.getClientRects().length > 0 &&
      getComputedStyle(el).visibility !== "hidden"
    );
  }
  function pose(mode, elapsed, still = false) {
    const seq = sequences[mode] || sequences.idle;
    if (still) return seq[0][0];
    let t = Math.max(0, elapsed) % seq.reduce((sum, p) => sum + p[1], 0);
    for (const [frame, hold] of seq) {
      if (t < hold) return frame;
      t -= hold;
    }
    return seq[0][0];
  }
  function paint(pic, mode, now, still) {
    let state = states.get(pic);
    if (!state || state.mode !== mode) {
      state = { mode, start: now };
      states.set(pic, state);
    }
    const frame = pose(mode, now - state.start, still);
    if (
      images[frame]?.complete &&
      images[frame].naturalWidth &&
      pic.dataset.velvetFrame !== String(frame)
    ) {
      pic.src = frames[frame];
      pic.dataset.velvetFrame = String(frame);
    }
    pic.dataset.velvetMode = mode;
  }
  function update() {
    timer = null;
    const now = performance.now(),
      still = reduced();
    let active = false;
    document.documentElement.classList.toggle("apw125-velvet-reduced", still);
    const ring = $("apwVelvetRingside")?.querySelector("img");
    if (visible(ring)) {
      paint(
        ring,
        $("apwVelvetBanter")?.classList.contains("visible") ? "talk" : "idle",
        now,
        still,
      );
      active = true;
    }
    for (const img of document.querySelectorAll(".apwVelvetSingles img"))
      if (visible(img)) {
        paint(img, "idle", now, still);
        active = true;
      }
    if (
      $("apwVelvetScene")?.classList.contains("open") &&
      visible($("apwVelvetPortrait"))
    ) {
      const speaker = $("apwVelvetSpeaker")?.textContent;
      paint(
        $("apwVelvetPortrait"),
        speaker === "Velvet Hark"
          ? "talk"
          : speaker === "Birdman Phil Picasso"
            ? "react"
            : speaker === "STAGE DIRECTION"
              ? "point"
              : "idle",
        now,
        still,
      );
      active = true;
    }
    if (active && !still) timer = setTimeout(update, 100);
  }
  function refresh() {
    clearTimeout(timer);
    timer = null;
    update();
  }
  function init() {
    for (const event of [
      "apw:screen-changed",
      "apw:career-changed",
      "apw:velvet-render",
    ])
      window.addEventListener(event, refresh);
    document.addEventListener("visibilitychange", refresh);
    $("apw43motion")?.addEventListener("change", refresh);
    motion?.addEventListener?.("change", refresh);
    for (const id of ["tagstart", "tagrestart"])
      $(id)?.addEventListener("click", refresh);
    refresh();
  }
  window.APW_VELVET_ANIMATION = {
    poseCount: frames.length,
    version: "12.5",
    refresh,
    sample: pose,
    status: () => ({
      running: timer !== null,
      reduced: reduced(),
      ready: images.filter((i) => i.complete && i.naturalWidth).length,
    }),
  };
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init, { once: true });
  else init();
})();
