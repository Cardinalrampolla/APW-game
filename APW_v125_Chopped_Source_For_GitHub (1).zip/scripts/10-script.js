/* Tag artwork */
window.APW105_SPRITES = {
  "Gideon Hark": {
    idle: APW_MEDIA[277],
    guard: APW_MEDIA[278],
    walk: APW_MEDIA[279],
    walk2: APW_MEDIA[280],
    strike: APW_MEDIA[281],
    grapple: APW_MEDIA[282],
    finisher: APW_MEDIA[283],
    hurt: APW_MEDIA[284],
    down: APW_MEDIA[285],
    victory: APW_MEDIA[286],
  },
  "Simon Temple": {
    idle: APW_MEDIA[287],
    guard: APW_MEDIA[288],
    walk: APW_MEDIA[289],
    walk2: APW_MEDIA[290],
    strike: APW_MEDIA[291],
    grapple: APW_MEDIA[292],
    finisher: APW_MEDIA[293],
    hurt: APW_MEDIA[294],
    down: APW_MEDIA[295],
    victory: APW_MEDIA[296],
  },
  "Whiskey Sixx": {
    idle: APW_MEDIA[297],
    guard: APW_MEDIA[298],
    walk: APW_MEDIA[299],
    walk2: APW_MEDIA[300],
    strike: APW_MEDIA[301],
    grapple: APW_MEDIA[302],
    finisher: APW_MEDIA[303],
    hurt: APW_MEDIA[304],
    down: APW_MEDIA[305],
    victory: APW_MEDIA[306],
  },
  "Mauler Y": {
    idle: APW_MEDIA[307],
    guard: APW_MEDIA[308],
    walk: APW_MEDIA[309],
    walk2: APW_MEDIA[310],
    strike: APW_MEDIA[311],
    grapple: APW_MEDIA[312],
    finisher: APW_MEDIA[313],
    hurt: APW_MEDIA[314],
    down: APW_MEDIA[315],
    victory: APW_MEDIA[316],
  },
};

/* ---- Module 12 ---- */

/* Tag combat */
/* Tag combat */
(() => {
  const $ = (id) => document.getElementById(id),
    names = ["Gideon Hark", "Simon Temple", "Whiskey Sixx", "Mauler Y"];
  let cinemaEpoch = 0,
    winnerSide = null;
  let isolation = 0,
    cornerPressure = 0,
    hotTagThreat = 0,
    playerRescueReady = true,
    rivalRescueReady = true,
    comboSetup = 0,
    rescueArmed = false;
  let fighters,
    active,
    turn,
    mom,
    finished,
    locked,
    enemyMom = 0,
    enemyTimer = null,
    aidActive = false,
    refCount = 0,
    refHold = 0,
    refUsed = false,
    distractionShield = false,
    enemyAid = false,
    enemyCount = 0,
    lastHitDamage = 0;
  const spots = [36, 8, 59, 80];
  const matchTimers = new Set();
  function later(fn, ms) {
    const id = setTimeout(() => {
      matchTimers.delete(id);
      fn();
    }, ms);
    matchTimers.add(id);
    return id;
  }
  function clearMatchTimers() {
    matchTimers.forEach((id) => clearTimeout(id));
    matchTimers.clear();
  }
  function sprite(i) {
    return `<img class="tag-sprite apw99-art" src="${window.APW105_SPRITES[names[i]].idle}" alt="" draggable="false" loading="eager">`;
  }
  function tagPose(i, pose) {
    const img = $("tagfighter" + i)?.querySelector(".apw99-art");
    if (
      img &&
      window.APW105_SPRITES[names[i]][pose] &&
      img.dataset.pose !== pose
    ) {
      img.src = window.APW105_SPRITES[names[i]][pose];
      img.dataset.pose = pose;
      window.APW114?.setTagPose(i, pose);
    }
  }

  // v11.2 animation polish: temporary arena effects, no changes to match results.
  function impactVisual(kind, side, epoch) {
    if (epoch !== cinemaEpoch) return;
    const ring = $("tagarena");
    const target = $("tagfighter" + active[1 - side]);
    if (!ring || !target) return;
    const box = ring.getBoundingClientRect();
    const hitbox = target.getBoundingClientRect();
    if (!box.width || !box.height) return;
    const cx =
      ((hitbox.left + hitbox.width * 0.55 - box.left) / box.width) * 100;
    const cy =
      ((hitbox.top + hitbox.height * 0.58 - box.top) / box.height) * 100;
    const heavy = kind === "special" || kind === "double";
    const burst = document.createElement("span");
    burst.className = "apw112-hitburst" + (heavy ? " heavy" : "");
    burst.style.left = cx + "%";
    burst.style.top = cy + "%";
    burst.setAttribute("aria-hidden", "true");
    ring.append(burst);
    later(() => burst.remove(), 670);
    if (heavy) {
      ring.classList.remove("apw112-superhit");
      void ring.offsetWidth;
      ring.classList.add("apw112-superhit");
      later(() => ring.classList.remove("apw112-superhit"), 480);
    }
  }

  function apw113HudUpdate() {
    if (!fighters || !active) return;
    for (const side of [0, 1]) {
      const f = fighters[active[side]];
      const id = side === 0 ? "Player" : "Enemy";
      const nm = $("apw113" + id),
        bar = $("apw113" + id + "Bar"),
        meta = $("apw113" + id + "Meta");
      if (!nm || !bar || !meta) continue;
      nm.textContent = f.name.toUpperCase();
      bar.style.width =
        Math.max(0, Math.min(100, Math.round((f.hp / 260) * 100))) + "%";
      bar.classList.toggle("low", f.hp < 70);
      meta.textContent =
        side === 0 ? "HARK · " + mom + " MOM" : "REALM · " + f.hp + " HP";
    }
    if ($("apw113Round"))
      $("apw113Round").textContent = finished ? "FINAL" : "VS";
  }
  function apw113Trail(node, epoch) {
    if (
      !node ||
      epoch !== cinemaEpoch ||
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const cel = node.querySelector("canvas.apw114-cel");
    const img = node.querySelector(".apw99-art");
    if (!img) return;
    let trail;
    if (cel && node.classList.contains("apw114-cel-ready")) {
      trail = document.createElement("canvas");
      trail.width = cel.width;
      trail.height = cel.height;
      trail.getContext("2d").drawImage(cel, 0, 0);
      trail.className = "apw113-trail apw114-trail";
    } else {
      trail = img.cloneNode(false);
      trail.className = "apw113-trail";
    }
    trail.removeAttribute("id");
    trail.setAttribute("aria-hidden", "true");
    node.append(trail);
    later(() => trail.remove(), 600);
  }
  function apw113ShowMove(kind, side, epoch) {
    const box = $("apw113Move");
    if (!box || epoch !== cinemaEpoch) return;
    // Ordinary strikes and grapples already have clear in-ring callouts; avoid double captions.
    if (kind !== "special") {
      box.classList.remove("show");
      return;
    }
    const name = fighters[active[side]].name;
    box.textContent = "★ " + name.toUpperCase() + " ★";
    box.classList.remove("show");
    void box.offsetWidth;
    box.classList.add("show");
  }
  function apw113Contact(kind, side, epoch) {
    if (epoch !== cinemaEpoch || kind === "tag") return;
    const ring = $("tagarena");
    const target = $("tagfighter" + active[1 - side]);
    if (!ring || !target) return;
    const b = ring.getBoundingClientRect(),
      h = target.getBoundingClientRect();
    if (!b.width || !b.height) return;
    const x =
      (((h.left + h.width * 0.52 - b.left) / b.width) * 100).toFixed(2) + "%";
    const y =
      (((h.top + h.height * 0.69 - b.top) / b.height) * 100).toFixed(2) + "%";
    for (const cls of ["apw113-ripple", "apw113-sparks"]) {
      const el = document.createElement("span");
      el.className = cls;
      el.style.left = x;
      el.style.top = y;
      el.setAttribute("aria-hidden", "true");
      ring.append(el);
      later(() => el.remove(), 690);
    }
    if (kind === "special" || kind === "double") {
      ring.classList.add("apw113-impactfreeze", "apw113-finalshot");
      later(
        () => ring.classList.remove("apw113-impactfreeze", "apw113-finalshot"),
        510,
      );
    }
    target.classList.add("apw113-hitstop");
    later(() => target.classList.remove("apw113-hitstop"), 230);
  }
  function apw113Knockdown(target, kind, side, epoch) {
    if (!target || epoch !== cinemaEpoch) return;
    if (kind !== "special" && kind !== "double" && kind !== "grapple") return;
    target.classList.add("apw113-knockdown");
    tagPose(active[1 - side], "down");
    later(() => {
      if (epoch !== cinemaEpoch) return;
      target.classList.remove("apw113-knockdown");
      target.classList.add("apw113-recovery");
    }, 440);
  }

  function arena() {
    const ring = $("tagarena"),
      flash = $("tagflash");
    fighters.forEach((f, i) => {
      let n = $("tagfighter" + i);
      if (!n) {
        n = document.createElement("div");
        n.id = "tagfighter" + i;
        n.innerHTML = sprite(i) + '<span class="tagname"></span>';
        ring.insertBefore(n, flash);
      }
      n.classList.add("tagwrestler");
      n.classList.toggle("bench", active[Math.floor(i / 2)] !== i);
      n.classList.toggle(
        "victory",
        finished && Math.floor(i / 2) === winnerSide && f.hp > 0,
      );
      n.classList.remove("apw72-helping");
      n.style.left = spots[i] + "%";
      n.style.setProperty("--dir", i < 2 ? "70px" : "-70px");
      n.querySelector(".tagname").textContent = f.name;
      if (f.hp === 0) tagPose(i, "down");
      else if (finished && Math.floor(i / 2) === winnerSide && f.hp > 0)
        tagPose(i, "victory");
      else if (!n.classList.contains("apw99-animating"))
        tagPose(i, active[Math.floor(i / 2)] === i ? "guard" : "idle");
      n.style.opacity = f.hp === 0 ? ".25" : "";
      if (
        (aidActive && i === (active[0] === 0 ? 1 : 0)) ||
        (enemyAid && i === (active[1] === 2 ? 3 : 2))
      )
        n.classList.add("apw72-helping");
    });
    apw113HudUpdate();
  }

  function cinematic(text, side, kind = "strike") {
    const epoch = ++cinemaEpoch;
    $("tagarena").classList.remove(
      "apw113-impactfreeze",
      "apw113-finalshot",
      "apw113-slowmo",
    );
    $("tagarena")
      .querySelectorAll(".apw113-trail,.apw113-ripple,.apw113-sparks")
      .forEach((n) => n.remove());
    $("tagarena")
      .querySelectorAll(".tagwrestler")
      .forEach((n) =>
        n.classList.remove(
          "apw113-knockdown",
          "apw113-recovery",
          "apw113-hitstop",
        ),
      );
    apw113ShowMove(kind, side, epoch);
    const flash = $("tagflash"),
      ring = $("tagarena");
    flash.textContent = text;
    flash.classList.remove("show");
    void flash.offsetWidth;
    flash.classList.add("show");
    const attacker = $("tagfighter" + active[side]),
      target = $("tagfighter" + active[1 - side]);
    const partnerIndex = active[side] === side * 2 ? side * 2 + 1 : side * 2;
    const partner = $("tagfighter" + partnerIndex);
    const mode =
      kind === "double"
        ? "apw38-double"
        : kind === "tag"
          ? "apw38-tag"
          : kind === "special"
            ? "apw38-finisher"
            : kind === "grapple"
              ? "apw38-grapple"
              : kind === "pin"
                ? "apw38-pin"
                : "apw38-strike";
    ring.classList.remove("apw38-impact", "apw38-tagglow");
    [...ring.querySelectorAll(".tagwrestler")].forEach((n) => {
      if (n)
        n.classList.remove(
          "apw38-attacker",
          "apw38-target",
          "apw38-partner",
          "apw38-tag-out",
          "apw38-tag-in",
          "apw38-aerial",
          "apw38-power",
          "apw99-animating",
          "apw112-bracing",
          "apw112-reeling",
        );
    });
    ring.classList.remove(
      "apw38-double",
      "apw38-tag",
      "apw38-finisher",
      "apw38-grapple",
      "apw38-pin",
      "apw38-strike",
    );
    void ring.offsetWidth;
    ring.classList.add(mode);
    if (attacker) {
      void attacker.offsetWidth;
      attacker.classList.add(
        kind === "tag" ? "apw38-tag-in" : "apw38-attacker",
      );
      if (kind === "special")
        attacker.classList.add(
          side === 1 && fighters[active[side]].name === "Whiskey Sixx"
            ? "apw38-aerial"
            : "apw38-power",
        );
    }
    if (target && kind !== "tag") target.classList.add("apw38-target");
    if (target && kind !== "tag") {
      // A guard wind-up, visible contact and recovery instead of a single frozen pose.
      target.classList.add("apw112-bracing");
      later(
        () => {
          if (epoch !== cinemaEpoch) return;
          target.classList.remove("apw112-bracing");
          target.classList.add("apw112-reeling");
          impactVisual(kind, side, epoch);
          apw113Contact(kind, side, epoch);
          later(
            () => apw113Knockdown(target, kind, side, epoch),
            kind === "special" ? 225 : kind === "double" ? 200 : 190,
          );
        },
        kind === "special" ? 450 : kind === "double" ? 410 : 350,
      );
    }
    if (attacker) {
      const idx = active[side];
      attacker.classList.add("apw99-animating");
      tagPose(
        idx,
        kind === "special"
          ? "grapple"
          : kind === "double"
            ? "guard"
            : kind === "tag"
              ? "walk"
              : kind === "grapple"
                ? "walk"
                : "guard",
      );
      if (kind !== "tag")
        later(
          () => {
            if (epoch === cinemaEpoch) apw113Trail(attacker, epoch);
          },
          kind === "special" ? 260 : 140,
        );
    }
    if (target && kind !== "tag") {
      target.classList.add("apw99-animating");
      tagPose(active[1 - side], "guard");
      later(
        () => {
          if (epoch === cinemaEpoch) tagPose(active[1 - side], "hurt");
        },
        kind === "special" ? 450 : kind === "double" ? 410 : 350,
      );
    }
    if (attacker && kind !== "tag") {
      const attackerIndex = active[side];
      later(() => {
        if (epoch !== cinemaEpoch) return;
        tagPose(
          attackerIndex,
          kind === "special"
            ? "finisher"
            : kind === "grapple" || kind === "double"
              ? "grapple"
              : "strike",
        );
      }, 280);
    }
    if (kind === "tag" && attacker) {
      const incoming = active[side];
      tagPose(incoming, "walk");
      later(() => {
        if (epoch === cinemaEpoch) tagPose(incoming, "walk2");
      }, 190);
      later(() => {
        if (epoch === cinemaEpoch) tagPose(incoming, "guard");
      }, 490);
    }
    if (kind === "double" && partner) {
      partner.classList.add("apw99-animating");
      tagPose(partnerIndex, "strike");
    }
    if (kind === "double" && partner) {
      partner.classList.add("apw38-partner");
      partner.style.setProperty(
        "--apw38-travel",
        side === 0 ? "115px" : "-115px",
      );
    }
    if (kind === "tag") ring.classList.add("apw38-tagglow");
    if (kind === "double" || kind === "special") {
      later(() => {
        if (epoch !== cinemaEpoch) return;
        ring.classList.add("apw38-impact");
        const spark = document.createElement("span");
        spark.className = "apw38-burst";
        ring.appendChild(spark);
        later(() => spark.remove(), 700);
      }, 450);
    }
    later(() => {
      if (epoch !== cinemaEpoch) return;
      flash.classList.remove("show");
      ring.classList.remove(
        mode,
        "apw38-impact",
        "apw38-tagglow",
        "apw112-superhit",
        "apw113-impactfreeze",
        "apw113-finalshot",
        "apw113-slowmo",
      );
      const callout = $("apw113Move");
      if (callout) callout.classList.remove("show");
      [...ring.querySelectorAll(".tagwrestler")].forEach((n) => {
        n.classList.remove(
          "apw38-attacker",
          "apw38-target",
          "apw38-partner",
          "apw38-tag-in",
          "apw38-aerial",
          "apw38-power",
          "apw99-animating",
          "apw112-bracing",
          "apw112-reeling",
          "apw113-knockdown",
          "apw113-recovery",
          "apw113-hitstop",
        );
        n.style.removeProperty("--apw38-travel");
      });
      arena();
    }, 1350);
  }
  const cap = (v, a, b) => Math.max(a, Math.min(b, v)),
    rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
  function log(t) {
    let p = document.createElement("p");
    p.textContent = t;
    $("taglog").prepend(p);
  }
  function draw() {
    arena();
    $("tagfighters").innerHTML = fighters
      .map(
        (f, i) =>
          '<div class="tagbox" style="' +
          (active[Math.floor(i / 2)] === i ? "border-color:#ffcf66" : "") +
          '"><b>' +
          f.name +
          "</b> " +
          (active[Math.floor(i / 2)] === i ? "⭐ ACTIVE" : "APRON") +
          '<div class="tagmeter"><i style="width:' +
          (f.hp / 260) * 100 +
          '%"></i></div>HP ' +
          f.hp +
          "/260</div>",
      )
      .join("");
    $("tagturn").textContent = finished
      ? "MATCH OVER"
      : turn === 0
        ? "Your turn • Momentum " + mom + "/100"
        : "Outer Realm attacks…";
    document.querySelectorAll("[data-tagact]").forEach((b) => {
      const a = b.dataset.tagact;
      b.disabled =
        finished ||
        locked ||
        turn !== 0 ||
        (a === "double" && mom < 60) ||
        (a === "special" && mom < 85) ||
        (a === "assist" && (aidActive || mom < 20)) ||
        (a === "out" && !aidActive) ||
        (a === "distract" && (aidActive || distractionShield || mom < 15)) ||
        (a === "ref" && (!aidActive || refUsed || mom < 20)) ||
        (a === "hot" &&
          (aidActive ||
            isolation < 2 ||
            fighters[active[0] === 0 ? 1 : 0].hp <= 0)) ||
        (a === "tag" && fighters[active[0] === 0 ? 1 : 0].hp <= 0) ||
        (a === "setup" && (aidActive || mom < 20 || comboSetup >= 2)) ||
        (a === "rescue" && (!playerRescueReady || rescueArmed || mom < 30)) ||
        (a === "isolate" && mom < 15) ||
        ((a === "pin" || a === "tag" || a === "hot") && aidActive);
    });
    $("apw72Tactics").classList.toggle(
      "apw72-danger",
      aidActive && refCount >= 4,
    );
    $("apw72Tactics").textContent =
      "YOUR ISOLATION " +
      isolation +
      "/4 · RIVAL CORNER PRESSURE " +
      cornerPressure +
      "/3\n" +
      (aidActive
        ? "YOUR ILLEGAL PARTNER: COUNT " +
          refCount +
          "/5" +
          (refCount >= 4
            ? " — SEND THEM OUT NOW!"
            : " · Strikes +8, grapples +10, double teams +12 damage.")
        : "Your partner is on the apron. Tag normally or call them in for a risky double team.") +
      (refHold
        ? "\nRef distracted: your next counted action holds the count."
        : "") +
      (distractionShield
        ? "\nRival distracted: their next hit deals 40% less damage."
        : "") +
      (enemyAid
        ? "\nOUTER REALM ILLEGAL PARTNER: COUNT " + enemyCount + "/5"
        : "") +
      "\nPIN RESCUE: " +
      (rescueArmed ? "ARMED" : playerRescueReady ? "READY" : "USED") +
      " · HARK COMBO SETUP " +
      comboSetup +
      "/2" +
      (hotTagThreat ? " · HOT TAG PRESSURE " + hotTagThreat : "");
  }
  function postMatch(side, why) {
    const winner = side === 0 ? "THE HARK FOUNDATION" : "THE OUTER REALM";
    const losing = side === 0 ? "The Outer Realm" : "The Hark Foundation";
    const post = $("tagpost");
    post.hidden = false;
    post.innerHTML =
      '<div class="belt">🏆</div><h3>' +
      winner +
      ' — TAG TEAM CHAMPIONS!</h3><div class="promo">David Hilder raises the winners’ hands!<br>' +
      why +
      "<br><br><b>" +
      winner +
      "</b> stand tall while " +
      losing +
      " retreat to the locker room.<br><em>APW IS NO TEA PARTY!</em></div>";
    const ref = $("tagref");
    ref?.classList.add("counting");
    later(() => ref?.classList.remove("counting"), 1350);
  }
  function end(side, why) {
    finished = true;
    winnerSide = side;
    postMatch(side, why);
    $("tagvictory").textContent =
      "🏆 " +
      (side === 0 ? "THE HARK FOUNDATION" : "THE OUTER REALM") +
      " VICTORIOUS!";
    cinematic(
      why.includes("DISQUALIFIED")
        ? "FIVE COUNT — DQ!"
        : why === "Knockout"
          ? "KNOCKOUT!"
          : "ONE! TWO! THREE!",
      side,
      why.includes("DISQUALIFIED")
        ? "tag"
        : why === "Knockout"
          ? "strike"
          : "pin",
    );
    log(
      "🔔 " +
        why +
        " — " +
        (side === 0 ? "THE HARK FOUNDATION" : "THE OUTER REALM") +
        " WINS!",
    );
    draw();
    [side * 2, side * 2 + 1].forEach((i) =>
      $("tagfighter" + i)?.classList.add("victory"),
    );
    later(() => {
      $("tagflash").textContent =
        side === 0
          ? "THE HARK FOUNDATION — TAG CHAMPIONS!"
          : "THE OUTER REALM — TAG CHAMPIONS!";
      $("tagflash").classList.add("show");
      $("tagarena").classList.add("championship-celebration");
      later(
        () => $("tagarena").classList.remove("championship-celebration"),
        3000,
      );
    }, 900);
  }
  function hit(side, amount) {
    if (side === 1) {
      if (enemyAid) amount += 8;
      if (rescueArmed) {
        amount = Math.ceil(amount * 0.6);
        rescueArmed = false;
        playerRescueReady = false;
        log(
          "Your partner cover softens the attack: 40% less damage. Rescue used.",
        );
      }
      if (distractionShield) {
        amount = Math.ceil(amount * 0.6);
        distractionShield = false;
        log("Your apron distraction spoils the attack: 40% less damage!");
      }
    }
    lastHitDamage = amount;
    let target = fighters[active[1 - side]];
    target.hp = cap(target.hp - amount, 0, 260);
    return target;
  }
  function enemy() {
    if (finished) return;
    const counterHotTag = hotTagThreat > 0;
    hotTagThreat = 0;
    let e = fighters[active[1]],
      p = fighters[active[0]];
    const partner = active[1] === 2 ? 3 : 2,
      bench = fighters[partner];
    enemyMom = Math.min(100, enemyMom + 24);
    function finishTurn(countAid = true) {
      if (fighters[active[0]].hp === 0) {
        end(1, "Knockout");
        return;
      }
      if (enemyAid && countAid) enemyCount++;
      // The Outer Realm's hit has to finish before the next button can interrupt it.
      const completedEpoch = cinemaEpoch;
      later(() => {
        if (finished || completedEpoch !== cinemaEpoch) return;
        turn = 0;
        locked = false;
        draw();
      }, 1390);
    }
    if (enemyAid && enemyCount >= 5) {
      end(0, "DISQUALIFIED — Outer Realm broke the five-count.");
      return;
    }
    if (enemyAid && enemyCount >= 4) {
      enemyAid = false;
      enemyCount = 0;
      log(
        "David Hilder reaches FOUR! Outer Realm pulls its illegal partner out to avoid disqualification.",
      );
      turn = 0;
      locked = false;
      draw();
      return;
    }
    if (
      !enemyAid &&
      bench.hp > 0 &&
      counterHotTag &&
      enemyMom >= 35 &&
      Math.random() < 0.6
    ) {
      enemyMom -= 35;
      hotTagThreat = 0;
      isolation = Math.min(4, isolation + 1);
      hit(1, rnd(14, 24));
      log(
        "🛑 HOT TAG COUNTER! " +
          e.name +
          " cuts off the incoming wrestler with a lariat!",
      );
      cinematic("HOT TAG COUNTER!", 1, "strike");
      finishTurn();
      return;
    }
    if (
      !enemyAid &&
      enemyMom >= 50 &&
      bench.hp > 0 &&
      (p.hp < 110 || isolation >= 2) &&
      Math.random() < 0.48
    ) {
      enemyMom -= 50;
      enemyAid = true;
      enemyCount = 1;
      hit(1, rnd(22, 36));
      log(
        "⚠️ OUTER REALM DOUBLE TEAM! " +
          e.name +
          " and " +
          bench.name +
          " attack together — David Hilder counts ONE!",
      );
      cinematic("OUTER REALM DOUBLE TEAM!", 1, "double");
      finishTurn(false);
      return;
    }
    if (
      !enemyAid &&
      bench.hp > 0 &&
      enemyMom >= 70 &&
      p.hp < 145 &&
      Math.random() < 0.5
    ) {
      enemyMom -= 70;
      hit(1, rnd(44, 63));
      log(
        "💥 OUTER REALM COMBINATION! " +
          e.name +
          " drives " +
          p.name +
          " into " +
          bench.name +
          " for a coordinated corner attack!",
      );
      cinematic("OUTER REALM COMBO!", 1, "double");
      finishTurn();
      return;
    }
    if (enemyMom >= 85 && e.hp > 0 && p.hp < 165) {
      enemyMom -= 85;
      const move =
        e.name === "Whiskey Sixx" ? "450 SPLASH!" : "RUNNING SPLASH!";
      hit(1, e.name === "Whiskey Sixx" ? rnd(72, 92) : rnd(78, 98));
      log(
        "🌟 " +
          e.name +
          " sets up " +
          move +
          " for " +
          lastHitDamage +
          " damage!",
      );
      cinematic(move, 1, "special");
      finishTurn();
      return;
    }
    if (
      !enemyAid &&
      bench.hp > 35 &&
      (e.hp < 100 || (e.hp < 175 && bench.hp > e.hp + 35)) &&
      Math.random() < 0.82 * (1 - cornerPressure * 0.2)
    ) {
      active[1] = partner;
      cornerPressure = 0;
      rivalRescueReady = true;
      enemyMom = Math.min(100, enemyMom + 8);
      log(
        "🔄 SMART TAG! " +
          e.name +
          " escapes to the apron; " +
          bench.name +
          " enters fresh.",
      );
      cinematic("OUTER REALM TAG!", 1, "tag");
      finishTurn();
      return;
    }
    if (
      !enemyAid &&
      isolation < 4 &&
      p.hp > 0 &&
      (isolation >= 1 || p.hp < 150) &&
      Math.random() < 0.48
    ) {
      isolation = Math.min(4, isolation + 1);
      hit(1, rnd(13, 23) + isolation * 2);
      log(
        "⛓️ CUT OFF THE RING! " +
          e.name +
          " traps " +
          p.name +
          " away from the Hark corner. Isolation " +
          isolation +
          "/4.",
      );
      cinematic("CORNER CUT-OFF!", 1, "grapple");
      finishTurn();
      return;
    }
    if (
      !enemyAid &&
      bench.hp > 0 &&
      enemyMom >= 25 &&
      p.hp < 130 &&
      Math.random() < 0.32
    ) {
      enemyMom -= 25;
      hit(1, rnd(10, 18));
      log(
        "🎭 " +
          bench.name +
          " distracts the referee while " +
          e.name +
          " sneaks in a cheap shot!",
      );
      cinematic("REFEREE DISTRACTED!", 1, "strike");
      finishTurn();
      return;
    }
    if (p.hp < 75 && enemyMom >= 40 && Math.random() < 0.38) {
      enemyMom -= 40;
      if (
        (rescueArmed || (playerRescueReady && Math.random() < 0.3)) &&
        fighters[active[0] === 0 ? 1 : 0].hp > 0
      ) {
        playerRescueReady = false;
        rescueArmed = false;
        log(
          "🛡️ PIN BREAKUP! " +
            fighters[active[0] === 0 ? 1 : 0].name +
            " storms in to save the match!",
        );
        cinematic("HARK FOUNDATION SAVE!", 0, "tag");
        finishTurn();
        return;
      }
      if (distractionShield) {
        distractionShield = false;
        log("🛡️ The Hark corner disrupts the cover!");
        finishTurn();
        return;
      }
      let odds = Math.min(0.86, 0.18 + ((260 - p.hp) / 260) * 0.75);
      if (Math.random() < odds) {
        end(1, "ONE! TWO! THREE!");
        return;
      }
      log("ONE! TWO! KICK OUT! " + p.name + " stays alive!");
      finishTurn();
      return;
    }
    if (p.hp < 85 && Math.random() < 0.65) {
      hit(1, rnd(19, 31));
      log(
        "💀 " +
          e.name +
          " presses the advantage: " +
          lastHitDamage +
          " damage.",
      );
      cinematic("HEAVY STRIKE!", 1, "strike");
    } else {
      hit(1, rnd(13, 26));
      log(
        "👊 " + e.name + " attacks " + p.name + " for " + lastHitDamage + ".",
      );
      cinematic(
        e.name === "Mauler Y" ? "MAULER SPLASH!" : "WHISKEY STRIKE!",
        1,
        "strike",
      );
    }
    finishTurn();
  }
  function act(a) {
    if (finished || locked || turn !== 0) return;
    const hadAid = aidActive;
    if (
      ![
        "tag",
        "strike",
        "grapple",
        "double",
        "special",
        "pin",
        "assist",
        "out",
        "distract",
        "ref",
        "hot",
        "isolate",
        "recover",
        "setup",
        "rescue",
      ].includes(a)
    )
      return;
    if (aidActive && (a === "pin" || a === "tag" || a === "hot")) {
      log("Send your illegal partner out before tagging or pinning.");
      return;
    }
    if (a === "assist") {
      if (aidActive || mom < 20) return;
      mom -= 20;
      aidActive = true;
      refCount = 1;
      refHold = 0;
      refUsed = false;
      log("Your partner enters illegally! David Hilder: ONE!");
      cinematic("PARTNER IN — REF COUNT 1!", 0, "double");
    }
    if (a === "out") {
      if (!aidActive) return;
      aidActive = false;
      refCount = 0;
      refHold = 0;
      refUsed = false;
      log("Your partner returns to the apron. The five-count is cleared.");
      cinematic("PARTNER OUT — LEGAL!", 0, "tag");
    }
    if (a === "distract") {
      if (aidActive || distractionShield || mom < 15) return;
      mom -= 15;
      distractionShield = true;
      log(
        "Your apron partner distracts the rival. Their next hit deals 40% less damage.",
      );
      cinematic("APRON DISTRACTION!", 0, "tag");
    }
    if (a === "ref") {
      if (!aidActive || refUsed || mom < 20) return;
      mom -= 20;
      refUsed = true;
      refHold = 1;
      log(
        "Your partner distracts David Hilder. Your next counted action holds the count; only once per entry.",
      );
      cinematic("REFEREE DISTRACTED!", 0, "tag");
    }
    let f = fighters[active[0]],
      e = fighters[active[1]];
    if (a === "tag") {
      if (fighters[active[0] === 0 ? 1 : 0].hp <= 0) {
        log("Your partner cannot tag in!");
        return;
      }
      if (isolation > 0 && Math.random() < Math.min(0.8, isolation * 0.19)) {
        log(
          "⛓️ TAG DENIED! Outer Realm cuts off the corner. Fight free or attempt a HOT TAG!",
        );
        turn = 1;
        locked = true;
        draw();
        enemyTimer = later(() => {
          enemyTimer = null;
          enemy();
        }, 850);
        return;
      }
      isolation = 0;
      hotTagThreat = 0;
      let partner = active[0] === 0 ? 1 : 0;
      if (fighters[partner].hp === 0) {
        log("Your partner cannot tag in!");
        return;
      }
      active[0] = partner;
      mom = cap(mom + 12, 0, 100);
      log("🤝 TAG! " + fighters[partner].name + " enters the ring!");
      cinematic("TAG!", 0, "tag");
    }
    if (a === "strike" || a === "grapple") {
      if (isolation > 0 && a === "grapple") {
        isolation = Math.max(0, isolation - 1);
        log("💪 " + f.name + " fights out of corner isolation!");
      }
      let d = a === "strike" ? rnd(15, 27) : rnd(24, 37);
      d += aidActive ? (a === "strike" ? 8 : 10) : 0;
      hit(0, d);
      mom = cap(mom + (a === "strike" ? 18 : 24), 0, 100);
      log(
        "💥 " + f.name + " hits " + e.name + " with a " + a + " for " + d + "!",
      );
      cinematic(
        a === "strike"
          ? "FOREARM SMASH!"
          : f.name === "Simon Temple"
            ? "POWERHOUSE SUPLEX!"
            : "RIPCORD SUPLEX!",
        0,
        a,
      );
    }
    if (a === "double") {
      if (mom < 60) return;
      mom -= 60;
      let d = rnd(68, 90) + comboSetup * 12;
      comboSetup = 0;
      d += aidActive ? 12 : 0;
      hit(0, d);
      log(
        "⚡ HARK FOUNDATION DOUBLE TEAM! " +
          f.name +
          " and " +
          fighters[active[0] === 0 ? 1 : 0].name +
          " crush " +
          e.name +
          " for " +
          d +
          "!",
      );
      cinematic("HARK FOUNDATION: RIPCORD CHOKE SLAM!", 0, "double");
    }
    if (a === "special") {
      if (mom < 85) return;
      mom -= 85;
      let name =
        f.name === "Simon Temple"
          ? "DEVASTATING CHOKE SLAM!"
          : "RIPCORD CLOTHESLINE!";
      let d = f.name === "Simon Temple" ? rnd(84, 104) : rnd(75, 95);
      hit(0, d);
      log("🌟 " + f.name + " executes " + name + " " + d + " damage!");
      cinematic(name, 0, "special");
    }
    if (a === "setup") {
      if (mom < 20 || aidActive || comboSetup >= 2) return;
      mom -= 20;
      comboSetup = Math.min(2, comboSetup + 1);
      log(
        "🤝 HARK FOUNDATION signal a coordinated finish! Combo setup " +
          comboSetup +
          "/2.",
      );
      cinematic("TAG TEAM PSYCHOLOGY!", 0, "tag");
    }
    if (a === "rescue") {
      if (!playerRescueReady || rescueArmed || mom < 30) return;
      mom -= 30;
      rescueArmed = true;
      log(
        "🛡️ PARTNER ON ALERT! The Hark partner is ready to break up one dangerous cover or soften the next attack.",
      );
      cinematic("PARTNER RESCUE READY!", 0, "tag");
    }
    if (a === "pin") {
      let breakup = fighters[active[1] === 2 ? 3 : 2];
      if (breakup.hp > 0 && rivalRescueReady && Math.random() < 0.42) {
        rivalRescueReady = false;
        log(
          "🛑 PIN BREAKUP! " + breakup.name + " dives in and breaks the cover!",
        );
        mom = cap(mom + 5, 0, 100);
      } else {
        let chance = cap(0.12 + ((260 - e.hp) / 260) * 0.75, 0.12, 0.92);
        if (Math.random() < chance) {
          end(0, "ONE! TWO! THREE!");
          return;
        }
        log("ONE! TWO! KICK OUT! " + e.name + " survives!");
        mom = cap(mom + 8, 0, 100);
      }
    }
    if (a === "hot") {
      if (isolation < 2 || fighters[active[0] === 0 ? 1 : 0].hp <= 0) return;
      active[0] = active[0] === 0 ? 1 : 0;
      isolation = 0;
      hotTagThreat = 2;
      mom = cap(mom + 22, 0, 100);
      hit(0, 24);
      log("🔥 HOT TAG! " + fighters[active[0]].name + " storms into the ring!");
      cinematic("HOT TAG — HOUSE OF FIRE!", 0, "tag");
    }
    if (a === "isolate") {
      if (mom < 15) return;
      mom -= 15;
      comboSetup = Math.min(2, comboSetup + 1);
      cornerPressure = Math.min(3, cornerPressure + 1);
      hit(0, 12 + cornerPressure * 4);
      log(
        "⛓️ HARK FOUNDATION traps " +
          e.name +
          " in the corner! Pressure " +
          cornerPressure +
          "/3.",
      );
      cinematic("CORNER ISOLATION!", 0, "grapple");
    }
    if (a === "recover") {
      mom = cap(mom + 12, 0, 100);
      isolation = Math.max(0, isolation - 1);
      log("💨 " + f.name + " recovers and inches closer to the corner.");
    }
    if (a === "double" && !hadAid) {
      aidActive = true;
      refCount = 1;
      refHold = 0;
      refUsed = false;
      log("Your double-team partner stays in. David Hilder: ONE!");
    } else if (hadAid && aidActive && a !== "ref") {
      if (refHold) {
        refHold = 0;
        log("The referee looks away — the count holds at " + refCount + ".");
      } else {
        refCount++;
        log("David Hilder counts: " + refCount + "!");
      }
    }
    if (aidActive && refCount >= 5) {
      end(
        1,
        "DISQUALIFIED — your illegal partner ignored David Hilder’s five-count.",
      );
      return;
    }
    if (fighters[active[1]].hp === 0) {
      end(0, "Knockout");
      return;
    }
    turn = 1;
    locked = true;
    draw();
    enemyTimer = later(
      () => {
        enemyTimer = null;
        enemy();
      },
      a === "special" || a === "double" ? 1750 : 1460,
    );
  }
  function start() {
    cinemaEpoch++;
    winnerSide = null;
    isolation = 0;
    cornerPressure = 0;
    hotTagThreat = 0;
    playerRescueReady = true;
    rivalRescueReady = true;
    comboSetup = 0;
    rescueArmed = false;
    aidActive = false;
    refCount = 0;
    refHold = 0;
    refUsed = false;
    distractionShield = false;
    enemyAid = false;
    enemyCount = 0;
    clearMatchTimers();
    $("tagarena")
      .querySelectorAll(
        ".apw38-burst, .apw112-hitburst, .apw113-trail, .apw113-ripple, .apw113-sparks",
      )
      .forEach((n) => n.remove());
    $("tagflash").classList.remove("show");
    $("tagarena").classList.remove(
      "championship-celebration",
      "apw38-double",
      "apw38-tag",
      "apw38-finisher",
      "apw38-grapple",
      "apw38-pin",
      "apw38-strike",
      "apw38-impact",
      "apw38-tagglow",
      "whiskey-flight",
      "mauler-crash",
      "apw112-superhit",
      "apw113-impactfreeze",
      "apw113-finalshot",
      "apw113-slowmo",
    );
    $("tagref")?.classList.remove("counting");
    clearTimeout(enemyTimer);
    enemyTimer = null;
    $("tagpost").hidden = true;
    fighters = names.map((name) => ({ name, hp: 260 }));
    for (let i = 0; i < 4; i++) {
      const el = $("tagfighter" + i);
      el?.classList.remove(
        "apw99-animating",
        "apw38-attacker",
        "apw38-target",
        "apw38-partner",
        "apw38-tag-out",
        "apw38-tag-in",
        "apw38-aerial",
        "apw38-power",
        "tag-enter",
        "apw112-bracing",
        "apw112-reeling",
        "apw113-knockdown",
        "apw113-recovery",
        "apw113-hitstop",
      );
      el?.style.removeProperty("--apw38-travel");
      const img = el?.querySelector(".apw99-art");
      if (img) img.dataset.pose = "";
    }
    active = [0, 2];
    turn = 0;
    mom = 20;
    enemyMom = 0;
    finished = false;
    locked = false;
    $("tagplay").hidden = false;
    $("tagsetup").hidden = true;
    $("taglog").innerHTML = "";
    $("tagvictory").textContent = "";
    log(
      "🔔 David Hilder calls for the bell! The Tag Championship match begins.",
    );
    draw();
  }

  // Optional close-up camera: larger active wrestlers without affecting combat.
  const closeup = document.createElement("button");
  closeup.type = "button";
  closeup.id = "apw112Zoom";
  closeup.textContent = "🔍 CLOSE-UP CAMERA: OFF";
  closeup.setAttribute("aria-pressed", "false");
  closeup.setAttribute("aria-controls", "tagarena");
  $("tagarena").before(closeup);
  closeup.addEventListener("click", () => {
    const on = $("tagarena").classList.toggle("apw112-closeup");
    closeup.textContent = "🔍 CLOSE-UP CAMERA: " + (on ? "ON" : "OFF");
    closeup.setAttribute("aria-pressed", String(on));
  });
  const tacticHUD = document.createElement("div");
  tacticHUD.id = "apw72Tactics";
  tacticHUD.setAttribute("aria-live", "polite");
  $("tagbuttons").before(tacticHUD);
  for (const [action, label] of [
    ["assist", "PARTNER IN · 20 MOM"],
    ["out", "PARTNER OUT · BEAT THE COUNT"],
    ["distract", "DISTRACT RIVAL · 15 MOM"],
    ["ref", "DISTRACT REF · 20 MOM"],
    ["hot", "🔥 HOT TAG"],
    ["isolate", "⛓️ CORNER ISOLATION · 15 MOM"],
    ["recover", "💨 FIGHT FREE / RECOVER"],
    ["setup", "🤝 PLAN DOUBLE TEAM · 20 MOM"],
    ["rescue", "🛡️ PARTNER COVER · 30 MOM"],
  ]) {
    const b = document.createElement("button");
    b.dataset.tagact = action;
    b.textContent = label;
    b.type = "button";
    $("tagbuttons").append(b);
  }
  const tacticStyle = document.createElement("style");
  tacticStyle.textContent =
    "#apw72Tactics{border:1px solid #45e9ff;background:#14132f;color:#ddfaff;padding:12px;margin:10px 0;border-radius:7px;white-space:pre-wrap;font-weight:bold}#apw72Tactics.apw72-danger{border:2px solid #ff63a9;color:#ffe091;box-shadow:0 0 14px #ff2c6a44}.tagwrestler.apw72-helping{opacity:1!important;filter:drop-shadow(0 0 7px #38eaff)}";
  document.head.append(tacticStyle);
  $("tagstart").onclick = start;
  $("tagrestart").onclick = start;
  document
    .querySelectorAll("[data-tagact]")
    .forEach((b) => b.addEventListener("click", () => act(b.dataset.tagact)));
})();
