/* Custom portraits */
(function () {
  "use strict";
  const names = [
    "Birdman Phil Picasso",
    "Gideon Hark",
    "Simon Temple",
    "Bruza The Serb",
    "Evangeline Strange",
    "The Gatekeeper",
    "Nikki Poteet",
    "Johnny Putrid",
    "Nightmare Cat",
    "Whiskey Sixx",
    "Mauler Y",
    "TNT",
    "Al Straya",
    "Trucker Mark Taylor",
    "Taras Jones",
    "Harvey Falco",
    "Doomslayer",
    "Jay Payne",
    "Drako Savage",
    "The Outlaw",
    "Black Diamond",
    "Trashbag Dan",
    "Eli Driftwood",
    "Hotshot Hansel",
  ];
  const $ = (id) => document.getElementById(id);
  const choose = $("apw52choose"),
    preview = $("apw52preview"),
    status = $("apw52status");
  names.forEach((n) => {
    const o = document.createElement("option");
    o.value = n;
    o.textContent = n;
    choose.appendChild(o);
  });
  const key = (n) => "apw52portrait:" + n;
  function saved(n) {
    try {
      return localStorage.getItem(key(n));
    } catch (e) {
      return null;
    }
  }
  function builtin(n) {
    const c = window.APW_ROSTER_SPRITES || {};
    const k = Object.keys(c).find((k) => k.toLowerCase() === n.toLowerCase());
    if (k && c[k]) return c[k].idle || Object.values(c[k])[0];
    const images = document.querySelectorAll("#apw46left,#apw46right");
    for (const im of images) {
      if (im && im.getAttribute("data-wrestler") === n) return im.src;
    }
    return "";
  }
  const uploadRequests = new Map();
  let uploadSequence = 0;
  function refresh() {
    const n = choose.value;
    const custom = saved(n);
    const uri = custom || builtin(n);
    preview.src = uri || "";
    status.textContent =
      (custom
        ? "Custom portrait saved for "
        : "Current built-in artwork for ") +
      n +
      (uri ? "" : " (no preview available)");
  }
  choose.addEventListener("change", refresh);
  $("apw52launch").addEventListener("click", () => {
    $("apw52modal").classList.add("open");
    refresh();
  });
  $("apw52close").addEventListener("click", () =>
    $("apw52modal").classList.remove("open"),
  );
  $("apw52remove").addEventListener("click", () => {
    uploadRequests.set(choose.value, ++uploadSequence);
    try {
      localStorage.removeItem(key(choose.value));
    } catch (e) {}
    refresh();
  });
  $("apw52file").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      status.textContent = "Choose a PNG, JPG or WebP image.";
      return;
    }
    const wrestler = choose.value;
    const request = ++uploadSequence;
    uploadRequests.set(wrestler, request);
    const img = new Image();
    const u = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(u);
      if (uploadRequests.get(wrestler) !== request) return;
      const c = document.createElement("canvas");
      const scale = Math.min(1, 560 / img.width, 560 / img.height);
      c.width = Math.max(1, Math.round(img.width * scale));
      c.height = Math.max(1, Math.round(img.height * scale));
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      const data = c.toDataURL("image/jpeg", 0.78);
      try {
        localStorage.setItem(key(wrestler), data);
        if (choose.value === wrestler) refresh();
      } catch (err) {
        if (choose.value !== wrestler) return;
        preview.src = data;
        status.textContent =
          "Preview loaded, but browser storage is full. This portrait will not persist.";
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(u);
      if (choose.value === wrestler && uploadRequests.get(wrestler) === request)
        status.textContent = "Could not read image";
    };
    img.src = u;
  });
  // Apply user-imported art to the animated cinematic portraits, matching the nameplates.
  function apply() {
    const overlay = $("apw46overlay");
    if (!overlay || !overlay.classList.contains("apw46open")) return;
    const ims = [$("apw46left"), $("apw46right")];
    const labels = Array.from(overlay.querySelectorAll("*")).filter(
      (el) =>
        el.children.length === 0 &&
        names.some(
          (n) => el.textContent.trim().toLowerCase() === n.toLowerCase(),
        ),
    );
    ims.forEach((im, i) => {
      if (!im) return;
      const label = labels[i];
      if (!label) return;
      const n = names.find(
        (n) => n.toLowerCase() === label.textContent.trim().toLowerCase(),
      );
      const data = APW_V54_CANONICAL_ART[n.toUpperCase()] || saved(n);
      if (data && im.src !== data) im.src = data;
    });
  }
  setInterval(apply, 450);
  refresh();
})();
