/* Story actors */
(() => {
  "use strict";
  const modes = [
    ["#fighters", "ORIGINAL SINGLES"],
    ["#apw30Canvas", "CONSPIRACY ELIMINATOR"],
    ["#apw32Arena", "STEEL CAGE"],
    ["#apw33Canvas", "HEAVYWEIGHT MAIN EVENT"],
    ["#apw35visual", "CHAMPIONSHIP DEFENCE"],
  ];
  const roster = () =>
    document.getElementById("careerWrestler")?.value || "Gideon Hark";
  function portrait(name) {
    const n = (name || "").toLowerCase(),
      big = /simon temple|mauler y|bruza|drako/.test(n),
      mask = /gatekeeper|mauler|outlaw|drako|trashbag|eli driftwood/.test(n),
      hair = /gideon|whiskey|tnt|taras|johnny|black diamond/.test(n),
      pink = /simon|trashbag|nikki/.test(n),
      red = /bruza|gideon|eli|tnt/.test(n),
      color = pink ? "#d66a9b" : red ? "#b8324d" : "#3a517c";
    return `<svg viewBox="0 0 80 130" preserveAspectRatio="xMidYMax meet" aria-hidden="true"><g stroke="#111020" stroke-width="3" stroke-linejoin="miter"><path fill="#181722" d="M24 88L14 125H34L40 92 46 125H67L55 87Z"/><path fill="${color}" d="M23 47L14 88 63 88 55 47 43 40 34 40Z"/><path fill="#ba836d" d="M24 48L10 74 18 79 34 55M55 48L71 72 64 79 44 54"/><path fill="${mask ? "#3a222f" : "#d9a68a"}" d="M28 20Q40 8 53 20L54 40 46 49 33 47 26 39Z"/>${hair ? '<path fill="#2b1a21" d="M23 20L29 7 51 8 59 22 56 52 50 45 51 19 29 18 28 49 23 52Z"/>' : '<path fill="#35222a" d="M27 19L31 13 48 13 53 19Z"/>'}<path fill="#fff" stroke="none" d="M31 29h7v3h-7zm13 0h7v3h-7z"/><path fill="#181722" d="M27 122h13v7H14v-7zm22 0h14v7H45v-7z"/>${big ? '<path fill="none" stroke="#e2ac8a" stroke-width="6" d="M18 49L9 70M62 49L73 70"/>' : ""}</g></svg>`;
  }
  function setup(target, label) {
    const el = document.querySelector(target);
    if (!el) return;
    const base = el.id === "fighters" ? el.closest(".arena") : el;
    const stage =
      base.parentElement && base.tagName === "CANVAS"
        ? base.parentElement
        : base;
    stage.classList.add("apw36-stage");
    if (getComputedStyle(stage).position === "static")
      stage.style.position = "relative";
    const layer = document.createElement("div");
    layer.className = "apw36-overlay";
    layer.innerHTML = `<div class="apw36-actor a"></div><div class="apw36-actor b"></div><div class="apw36-spark">IMPACT!</div><div class="apw36-label">v3.6 • ${label}</div>`;
    stage.appendChild(layer);
    const actors = [layer.querySelector(".a"), layer.querySelector(".b")];
    let rival = target.includes("32")
      ? "Birdman Phil Picasso"
      : target.includes("33")
        ? "Bruza The Serb"
        : target.includes("30")
          ? "Bruza The Serb"
          : target.includes("35")
            ? "Al Straya"
            : "The Gatekeeper";
    function refresh() {
      actors[0].innerHTML = portrait(roster());
      actors[1].innerHTML = portrait(rival);
    }
    refresh();
    document
      .getElementById("careerWrestler")
      ?.addEventListener("change", refresh);
    if (target === "#fighters") {
      layer.style.zIndex = "4";
      actors.forEach((a) => (a.style.opacity = ".92"));
    } else if (base.tagName === "CANVAS") {
      layer.style.display = "none";
      const obs = new MutationObserver(() => {
        layer.style.display = base.hidden ? "none" : "block";
      });
      obs.observe(base, {
        attributes: true,
        attributeFilter: ["hidden", "style"],
      });
      layer.style.display = base.hidden ? "none" : "block";
    }
    function action(kind) {
      const cls =
        kind === "finisher"
          ? "finisher"
          : kind === "grapple"
            ? "grapple"
            : kind === "victory"
              ? "victory"
              : "strike";
      actors.forEach((a) =>
        a.classList.remove("strike", "grapple", "finisher", "hurt", "victory"),
      );
      void actors[0].offsetWidth;
      actors[0].classList.add(cls);
      if (cls !== "victory") actors[1].classList.add("hurt");
      const spark = layer.querySelector(".apw36-spark");
      spark.textContent =
        cls === "finisher"
          ? "FINISHER!"
          : cls === "victory"
            ? "CHAMPION!"
            : cls === "grapple"
              ? "SLAM!"
              : "HIT!";
      spark.classList.remove("on");
      void spark.offsetWidth;
      spark.classList.add("on");
      setTimeout(
        () =>
          actors.forEach((a) =>
            a.classList.remove("strike", "grapple", "finisher", "hurt"),
          ),
        1100,
      );
    }
    stage.addEventListener("click", (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      const t = btn.textContent.toLowerCase();
      if (/finisher|signature|special|choke slam|splash|ddt/.test(t))
        action("finisher");
      else if (/grapple|slam|throw|suplex/.test(t)) action("grapple");
      else if (/strike|punch|attack|kick|hit|climb|escape/.test(t))
        action("strike");
      else if (/victory|celebrat/.test(t)) action("victory");
    });
    // Buttons commonly sit outside the visual stage: listen at the mode container.
    const parent =
      el.closest("#apw30,#apw32,#apw33,#apw34") ||
      document.querySelector("main");
    if (parent && parent !== stage)
      parent.addEventListener("click", (e) => {
        const b = e.target.closest("button");
        if (!b) return;
        const t = b.textContent.toLowerCase();
        if (/finisher|signature|special|choke slam|splash|ddt/.test(t))
          action("finisher");
        else if (/grapple|slam|throw|suplex/.test(t)) action("grapple");
        else if (/strike|punch|attack|kick|hit|climb|escape/.test(t))
          action("strike");
        else if (/victory|celebrat/.test(t)) action("victory");
      });
  }
  modes.forEach(([target, label]) => setup(target, label));
})();
