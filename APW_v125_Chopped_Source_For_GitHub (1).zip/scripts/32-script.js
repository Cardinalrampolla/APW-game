/* Tactical Tag */
/* Tactical Tag */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id),
    names = ["Gideon Hark", "Simon Temple"],
    foes = ["Whiskey Sixx", "Mauler Y"];
  let g, buttons;
  const MOVES = [
    ["strike", "STRIKE"],
    ["grapple", "GRAPPLE"],
    ["tag", "TAG PARTNER"],
    ["hot", "HOT TAG"],
    ["double", "DOUBLE TEAM"],
    ["isolate", "CORNER ISOLATION"],
    ["distract", "REF DISTRACTION"],
    ["pin", "PIN ATTEMPT"],
    ["rest", "RECOVER"],
  ];
  const COSTS = {
    strike: 8,
    grapple: 15,
    tag: 0,
    hot: 0,
    double: 25,
    isolate: 12,
    distract: 10,
    pin: 0,
    rest: 0,
  };

  const rand = (n) => Math.floor(Math.random() * n),
    clamp = (x) => Math.max(0, Math.min(100, x));
  function say(t) {
    const p = document.createElement("p");
    p.textContent = t;
    $("apw86log").prepend(p);
  }
  function init() {
    g = {
      hp: [100, 125],
      ehp: [100, 125],
      active: 0,
      enemy: 0,
      stamina: 80,
      heat: 0,
      isolated: 0,
      ref: 0,
      turn: 0,
      over: false,
    };
    $("apw86log").textContent = "";
    say("The bell rings! APW is no tea party!");
    draw();
  }
  function draw() {
    const a = names[g.active],
      e = foes[g.enemy];
    $("apw86score").innerHTML =
      `<div><b>HARK FOUNDATION</b><p>${a} • HP ${g.hp[g.active]} • Stamina ${g.stamina}</p><p>Partner: ${names[1 - g.active]} • HP ${g.hp[1 - g.active]}</p><p>Isolation: ${g.isolated} • Momentum: ${g.heat}</p></div><div><b>OUTER REALM</b><p>${e} • HP ${g.ehp[g.enemy]}</p><p>Partner: ${foes[1 - g.enemy]} • HP ${g.ehp[1 - g.enemy]}</p><p>Referee warning: ${g.ref}/5</p></div>`;
    if (!buttons) {
      buttons = MOVES.map(([key, label]) => {
        const b = document.createElement("button");
        b.textContent = label;
        b.onclick = () => act(key);
        b.dataset.action = key;
        return b;
      });
      $("apw86moves").replaceChildren(...buttons);
    }
    for (const b of buttons) {
      const key = b.dataset.action;
      b.disabled =
        g.over ||
        COSTS[key] > g.stamina ||
        (key === "hot" && (g.isolated < 2 || g.hp[1 - g.active] <= 0)) ||
        (key === "tag" && g.hp[1 - g.active] <= 0) ||
        (key === "pin" && g.ehp[g.enemy] > 45);
    }
  }
  function hit(n) {
    g.ehp[g.enemy] = Math.max(0, g.ehp[g.enemy] - n);
  }
  function enemyTurn() {
    if (g.over) return;
    g.turn++;
    if (g.ref > 0) {
      g.ref = Math.max(0, g.ref - 1);
      say("David Hilder resumes his count.");
    }
    if (g.turn % 4 === 0 && g.ehp[g.enemy] < 50 && g.ehp[1 - g.enemy] > 0) {
      g.enemy = 1 - g.enemy;
      say("Outer Realm makes a desperate tag!");
    }
    const r = rand(100);
    if (r < 24) {
      g.isolated = Math.min(4, g.isolated + 1);
      say(foes[g.enemy] + " cuts off the ring! Isolation increases.");
    } else if (r < 42) {
      g.hp[g.active] = Math.max(0, g.hp[g.active] - 14);
      say("Outer Realm hits a double-team combination! -14 HP.");
    } else {
      let d = 7 + rand(9);
      g.hp[g.active] = Math.max(0, g.hp[g.active] - d);
      say(foes[g.enemy] + " attacks! -" + d + " HP.");
    }
    g.stamina = clamp(g.stamina + 6);
    if (g.hp[g.active] === 0 && g.hp[1 - g.active] === 0) {
      g.over = true;
      say("OUTER REALM WINS BY KNOCKOUT!");
    } else if (g.hp[g.active] === 0) {
      g.over = true;
      say("OUTER REALM WINS! The active wrestler cannot continue.");
    }
  }
  function act(k) {
    if (g.over) return;
    if (!Object.prototype.hasOwnProperty.call(COSTS, k)) return;
    const cost = COSTS[k];
    if (cost > g.stamina) {
      say("Too exhausted! Recover first.");
      draw();
      return;
    }
    switch (k) {
      case "strike":
        hit(9 + rand(7));
        g.heat = clamp(g.heat + 8);
        say(names[g.active] + " lands a strike!");
        break;
      case "grapple":
        hit(15 + rand(8));
        g.heat = clamp(g.heat + 12);
        say(names[g.active] + " executes a grapple!");
        break;
      case "tag":
        if (g.hp[1 - g.active] <= 0) {
          say("Your partner cannot tag in!");
          draw();
          return;
        }
        if (g.isolated > 0 && rand(100) < g.isolated * 18) {
          say("Tag cut off! Outer Realm drags you back to their corner.");
          break;
        }
        g.active = 1 - g.active;
        g.isolated = 0;
        g.stamina = 85;
        say("LEGAL TAG! " + names[g.active] + " enters the ring.");
        break;
      case "hot":
        if (g.isolated < 2 || g.hp[1 - g.active] <= 0) return;
        g.active = 1 - g.active;
        g.isolated = 0;
        g.stamina = 100;
        hit(22);
        g.heat = clamp(g.heat + 25);
        say("HOT TAG! " + names[g.active] + " cleans house!");
        break;
      case "double":
        g.ref += 2;
        if (g.ref >= 5) {
          g.over = true;
          say("FIVE COUNT! David Hilder disqualifies the Hark Foundation!");
          break;
        }
        hit(27 + rand(10));
        say("DOUBLE TEAM! The referee starts the five-count.");
        break;
      case "isolate":
        hit(11);
        g.heat = clamp(g.heat + 15);
        say("Corner isolation! Opponent is trapped, setting up team offence.");
        break;
      case "distract":
        if (rand(100) < 25) {
          g.over = true;
          say(
            "David Hilder catches the illegal interference! DISQUALIFICATION!",
          );
          break;
        }
        g.ref = 0;
        hit(17);
        say("Partner distracts the referee! Sneaky strike connects.");
        break;
      case "pin":
        if (g.ehp[g.enemy] > 45) return;
        let chance = 70 - g.ehp[g.enemy] + Math.floor(g.heat / 4);
        if (rand(100) < chance) {
          g.over = true;
          say("ONE! TWO! THREE! THE HARK FOUNDATION WINS!");
        } else
          say(
            "ONE! TWO! KICKOUT! " + foes[1 - g.enemy] + " breaks up the pin!",
          );
        break;
      case "rest":
        g.stamina = clamp(g.stamina + 28);
        g.isolated = Math.max(0, g.isolated - 1);
        say(
          names[g.active] + " catches a breath and fights toward the corner.",
        );
        break;
    }
    g.stamina = clamp(g.stamina - cost);
    if (!g.over && g.ehp[g.enemy] <= 0) {
      g.over = true;
      say("HARK FOUNDATION WINS BY KNOCKOUT!");
    }
    if (!g.over) enemyTurn();
    draw();
  }
  $("apw86open").onclick = () => {
    $("apw86modal").classList.add("on");
    if (!g) init();
  };
  $("apw86close").onclick = () => $("apw86modal").classList.remove("on");
  $("apw86reset").onclick = init;
})();
