/* Champion defence */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id),
    KEY = "apwChampion34";
  const fresh = () => ({
    chapter: 20,
    challenger: "",
    wins: 0,
    hp: 130,
    enemy: 125,
    stamina: 80,
    momentum: 0,
    turn: 0,
    allies: false,
    evidence: 0,
    champion: true,
    log: "",
    lastResult: "",
  });
  let s;
  try {
    s = window.APW_TEAM_B.restore(
      fresh(),
      JSON.parse(localStorage.getItem(KEY) || "{}"),
    );
  } catch (e) {
    s = fresh();
  }
  const save = () => {
    try {
      window.APW_TEAM_B.store(KEY, JSON.stringify(s));
    } catch (e) {}
  };
  // Existing v10.8 progress is loaded before the UI paints. Only correct a
  // confirmed title-loss record; never infer a victory from missing data.
  if (s.lastResult === "loss" && s.champion === false)
    window.APW_TOWER?.setChampion(false);
  const prior = () => {
    try {
      return JSON.parse(localStorage.getItem("apwMainEvent33") || "null");
    } catch (e) {
      return null;
    }
  };
  const player = () => window.APW_CAREER?.name || "Your wrestler";
  const choice = (txt, fn, disabled = false) => {
    const b = document.createElement("button");
    b.textContent = txt;
    b.disabled = disabled;
    b.onclick = () => {
      fn();
      save();
      render();
    };
    $("apw34choices").append(b);
  };
  function startFight(opp) {
    s.challenger = opp;
    s.chapter = 23;
    s.trainingStats = APW_GROWTH.stats();
    s.hp = 130;
    s.enemy = opp === "Birdman Phil Picasso" ? 150 : 125;
    s.stamina = 80;
    s.momentum = 0;
    s.turn = 0;
    s.log = "The bell rings! " + opp + " steps forward.";
    APW_STAKES.init(s);
  }
  function action(type) {
    if (
      s.chapter !== 23 ||
      (type === "grapple" &&
        s.stamina < APW_GROWTH.cost(12, s.trainingStats)) ||
      (type === "finish" &&
        (s.stamina < APW_GROWTH.cost(50, s.trainingStats) || s.momentum < 50))
    )
      return;
    APW_STAKES.clearNotices(s);
    const wasChampion = s.champion;
    let dmg = 0,
      msg = "",
      guard = false;
    if (type === "strike") {
      dmg = 15 + (s.turn % 5);
      s.stamina = Math.min(
        100,
        s.stamina + 8 + APW_GROWTH.recovery(s.trainingStats),
      );
      s.momentum = Math.min(
        100,
        s.momentum + 13 + APW_GROWTH.momentum(s.trainingStats),
      );
      msg = "A heavy strike connects!";
    }
    if (type === "grapple") {
      dmg = 24 + (s.turn % 5);
      s.stamina = Math.max(0, s.stamina - APW_GROWTH.cost(12, s.trainingStats));
      s.momentum = Math.min(
        100,
        s.momentum + 20 + APW_GROWTH.momentum(s.trainingStats),
      );
      msg = "A crushing grapple sends the challenger down!";
    }
    if (type === "guard") {
      guard = true;
      s.hp = Math.min(130, s.hp + 13);
      s.stamina = Math.min(
        100,
        s.stamina + 22 + APW_GROWTH.recovery(s.trainingStats),
      );
      msg = "You defend and recover.";
    }
    if (type === "finish") {
      dmg = 65;
      s.stamina -= APW_GROWTH.cost(50, s.trainingStats);
      s.momentum -= 50;
      msg = "SIGNATURE FINISHER! THE CROWD ERUPTS!";
    }
    dmg = APW_GROWTH.hit(dmg, s.trainingStats);
    s.enemy = Math.max(0, s.enemy - dmg);
    if (s.enemy === 0) {
      APW_GROWTH.reward(true, s.trainingStats);
      const retained = s.champion;
      if (retained) s.wins++;
      s.champion = true;
      window.APW_TOWER?.setChampion(true);
      s.chapter = 24;
      s.lastResult = "win";
      s.log =
        msg +
        APW_STAKES.note(s) +
        "\nONE! TWO! THREE! " +
        player().toUpperCase() +
        (retained
          ? " RETAINS THE TITLE!"
          : " WINS THE APW HEAVYWEIGHT CHAMPIONSHIP!");
      return;
    }
    let interferenceDamage = 0;
    let counter = 12 + ((s.turn * 3) % 12);
    if (guard) counter = Math.floor(counter / 3);
    if (s.turn % 4 === 2) {
      if (s.allies) {
        counter = Math.max(0, counter - 9);
        msg += "\nYour allies stop a ringside distraction!";
      } else {
        counter += 9;
        interferenceDamage = 9;
        msg += "\nEvangeline’s security distracts the referee!";
      }
    }
    if (s.turn % 5 === 4) {
      counter += 7;
      msg += "\n" + s.challenger + " lands a signature attack!";
    }
    counter = APW_STAKES.counter(s, counter, interferenceDamage, "defence");
    counter = APW_GROWTH.hurt(counter, s.trainingStats);
    s.hp = Math.max(0, s.hp - counter);
    s.turn++;
    s.log =
      msg +
      APW_STAKES.note(s) +
      "\nThe challenger counters for " +
      counter +
      " damage.";
    if (s.hp === 0) {
      APW_GROWTH.reward(false, s.trainingStats);
      s.chapter = 24;
      s.lastResult = "loss";
      s.champion = false;
      window.APW_TOWER?.setChampion(false);
      s.log +=
        "\nONE! TWO! THREE! " +
        (wasChampion
          ? "THE TITLE CHANGES HANDS!"
          : s.challenger.toUpperCase() + " RETAINS THE TITLE!");
    }
  }
  function render() {
    const won =
      (prior()?.phase === 4 && prior()?.result === "win") ||
      window.APW_TOWER?.state().champion;
    $("apw34choices").replaceChildren();
    $("apw34ring").hidden = s.chapter !== 23 || !won;
    $("apw34hud").textContent = won
      ? "DEFENCES: " +
        s.wins +
        "  |  CHAMPION: " +
        (s.champion ? "YES" : "NO") +
        "  |  EVIDENCE: " +
        s.evidence +
        (s.chapter === 23
          ? "  |  YOU " +
            s.hp +
            " HP  •  " +
            s.challenger +
            " " +
            s.enemy +
            " HP  •  STAMINA " +
            s.stamina +
            "  •  MOMENTUM " +
            s.momentum
          : "")
      : "CHAMPIONSHIP STORY LOCKED";
    const story = (t) => ($("apw34story").textContent = t);
    if (!won) {
      story(
        "Win the v3.3 APW Heavyweight Championship Main Event against Bruza The Serb to unlock Life as APW Champion. Your earlier save remains untouched.",
      );
      choice("↻ Check title result", () => {});
      return;
    }
    if (!s.champion && s.chapter !== 24 && s.chapter !== 23) {
      story(
        "You no longer hold the APW Heavyweight Championship. Your comeback starts here.",
      );
      choice("Fight for a rematch", () => {
        startFight("Bruza The Serb");
      });
      return;
    }
    if (s.chapter === 20) {
      story(
        "CHAPTER 20 — THE NEW CHAMPION\n\nDavid Hilder raises your hand. The APW Heavyweight Championship belongs to " +
          player() +
          "! But Birdman Phil Picasso storms into the arena with his Trashbag Police camera crew.\n\n“TEA PARTY NINTENDO WRESTLERS DOING TOO MANY FLIPS! THIS IS APW!”\n\nEvangeline Strange announces that every champion must defend their title on her terms.",
      );
      choice("🎤 Confront Birdman", () => {
        s.evidence++;
        s.chapter = 21;
      });
      choice("🏆 Celebrate with the crowd", () => {
        s.momentum = 15;
        s.chapter = 21;
      });
      return;
    }
    if (s.chapter === 21) {
      story(
        "CHAPTER 21 — THE BOOKING OFFICE\n\nEvangeline presents two challengers: Al Straya, the hardcore bruiser, or Birdman Phil Picasso, who wants to humiliate the champion on Trashbag Police. Doomslayer and Taras Jones warn that the booking office is hiding something.",
      );
      choice("🔎 Investigate the booking sheet", () => {
        s.evidence += 2;
        s.chapter = 22;
      });
      choice("🤝 Recruit your allies", () => {
        s.allies = true;
        s.chapter = 22;
      });
      return;
    }
    if (s.chapter === 22) {
      story(
        "CHAPTER 22 — CHOOSE YOUR FIRST TITLE DEFENCE\n\nThe championship committee demands a defence. Your choice changes the opponent and the match commentary. " +
          (s.evidence >= 2
            ? "You have copies of suspicious booking orders that could expose Evangeline."
            : "The backstage conspiracy remains difficult to prove."),
      );
      choice("⚔️ Face Al Straya", () => startFight("Al Straya"));
      choice("🦅 Face Birdman", () => startFight("Birdman Phil Picasso"));
      return;
    }
    if (s.chapter === 23) {
      story(
        "CHAPTER 23 — APW HEAVYWEIGHT TITLE DEFENCE\n\n" +
          player() +
          (s.champion ? " (c)" : " (challenger)") +
          " vs " +
          s.challenger +
          "\n\n" +
          s.log +
          "\n\nStrike builds momentum and stamina; grapple hits harder; guard restores health and stamina. Finisher costs 50 momentum and a base 50 stamina, reduced by Speed training.",
      );
      choice("👊 Strike", () => action("strike"));
      choice(
        "🤼 Grapple",
        () => action("grapple"),
        s.stamina < APW_GROWTH.cost(12, s.trainingStats),
      );
      choice("🛡️ Guard", () => action("guard"));
      choice(
        "💥 Finisher",
        () => action("finish"),
        s.stamina < APW_GROWTH.cost(50, s.trainingStats) || s.momentum < 50,
      );
      return;
    }
    if (s.chapter === 24) {
      story(
        "CHAPTER 24 — CHAMPIONSHIP FALLOUT\n\n" +
          s.log +
          "\n\n" +
          (s.lastResult === "win"
            ? "Your reign survives another night. Birdman rages at ringside, and Evangeline is already preparing another challenger."
            : "The championship is out of reach tonight. Win your comeback match to regain the belt.") +
          "\n\nAPW IS NO TEA PARTY!",
      );
      if (s.lastResult === "win") {
        choice("🏆 Defend title again", () => {
          s.chapter = 21;
          s.allies = false;
          s.evidence = 0;
        });
        choice("🔁 Replay champion storyline", () => {
          s = fresh();
        });
      } else
        choice("🔥 Begin comeback", () => {
          s.allies = false;
          s.evidence = 0;
          startFight("Bruza The Serb");
        });
      return;
    }
  }
  const c = $("apw34ring"),
    g = c.getContext("2d");
  g.imageSmoothingEnabled = false;
  let tick = 0;
  function draw() {
    tick++;
    if (!c.hidden) {
      g.fillStyle = "#11152e";
      g.fillRect(0, 0, 480, 240);
      for (let x = 0; x < 480; x += 20) {
        g.fillStyle = x % 60 === 0 ? "#503054" : "#282744";
        g.fillRect(x, 35, 16, 85);
      }
      g.fillStyle = "#78608a";
      g.fillRect(15, 142, 450, 80);
      for (let y = 95; y < 146; y += 18) {
        g.fillStyle = "#e8d6cb";
        g.fillRect(6, y, 468, 3);
      }
      g.font = "bold 15px monospace";
      g.fillStyle = "#f4c35d";
      g.fillText("APW HEAVYWEIGHT CHAMPIONSHIP", 73, 23);
      function wrestler(x, color) {
        const bob = Math.round(Math.sin(tick / 12 + x) * 3);
        g.fillStyle = "#171827";
        g.fillRect(x - 20, 180 + bob, 16, 40);
        g.fillRect(x + 4, 180 + bob, 16, 40);
        g.fillStyle = color;
        g.fillRect(x - 25, 130 + bob, 50, 53);
        g.fillStyle = "#c58b70";
        g.fillRect(x - 16, 103 + bob, 32, 30);
        g.fillRect(x - 35, 136 + bob, 10, 36);
        g.fillRect(x + 25, 136 + bob, 10, 36);
        g.fillStyle = "#1a1422";
        g.fillRect(x - 10, 116 + bob, 5, 4);
        g.fillRect(x + 6, 116 + bob, 5, 4);
      }
      wrestler(145, "#ad416d");
      wrestler(335, s.challenger === "Al Straya" ? "#333b40" : "#171a25");
      g.fillStyle = "#fff";
      g.font = "bold 11px monospace";
      g.fillText(player().slice(0, 18).toUpperCase(), 12, 234);
      g.fillText(s.challenger.slice(0, 19).toUpperCase(), 315, 234);
    }
    requestAnimationFrame(draw);
  }
  draw();
  $("careerWrestler")?.addEventListener("change", render);
  render();

  window.APW_TEAM_B.register(() => {
    s = fresh();
    save();
    render();
  });
  window.addEventListener("apw:path-refresh", render);
})();
