/* Character classes */
(function () {
  const names = [
    ["gideon", "Gideon Hark"],
    ["gatekeeper", "The Gatekeeper"],
  ];
  const states = [
    "attack",
    "hit",
    "grabbing",
    "spinning",
    "slowhit",
    "finishing",
    "down",
    "flyback",
    "haunt",
  ];
  const timers = new WeakMap();
  function init() {
    const root = document.getElementById("fighters");
    if (!root) return;
    const actors = names
      .map(([id]) => document.getElementById(id))
      .filter(Boolean);
    // Capture the existing raster frames from the original six-pose system
    // without modifying that system's combat hooks.
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        const actor = record.target;
        if (!actors.includes(actor)) continue;
        const state = states.find((k) => actor.classList.contains(k));
        if (!state || actor.dataset.apw68state === state) continue;
        actor.dataset.apw68state = state;
        const old = timers.get(actor) || [];
        old.forEach(clearTimeout);
        actor.classList.remove(
          "apw68-anticipate",
          "apw68-contact",
          "apw68-recover",
        );
        actor.classList.add("apw68-anticipate");
        const ts = [
          setTimeout(
            () => {
              actor.classList.remove("apw68-anticipate");
              actor.classList.add("apw68-contact");
            },
            state === "finishing" || state === "slowhit" ? 300 : 115,
          ),
          setTimeout(
            () => {
              actor.classList.remove("apw68-contact");
              actor.classList.add("apw68-recover");
            },
            state === "finishing" || state === "slowhit" ? 670 : 380,
          ),
          setTimeout(() => {
            actor.classList.remove("apw68-recover");
            actor.dataset.apw68state = "";
          }, 1050),
        ];
        timers.set(actor, ts);
      }
    });
    observer.observe(root, {
      subtree: true,
      attributes: true,
      attributeFilter: ["class"],
    });
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init);
  else init();
})();

/* ---- Module 44 ---- */

/* Motion sequences */
(function () {
  const seq = {
    ripcord: [
      [0, 0, 0, 0, 0, 0, 0, 0],
      [300, 13, 0, -7, -17, 0, 5],
      [650, 27, -3, 8, -27, -1, -15],
      [1050, 42, -2, -12, -39, 0, 20],
      [1450, 61, -3, 12, -29, -1, -20],
      [1780, 78, -8, 23, 16, -9, 43],
      [2110, 48, 0, 0, 23, 24, 83],
      [2650, 0, 0, 0, 0, 0, 0],
    ],
    ghost: [
      [0, 0, 0, 0, 0, 0, 0],
      [350, 0, 0, 0, -14, -3, -8],
      [700, -8, -2, -5, -26, -2, -15],
      [1000, -16, -12, -20, -38, -12, -28],
      [1400, -18, 24, 80, -17, 0, 0],
      [1850, -12, 28, 86, 0, 0, 0],
      [2350, 0, 0, 0, 0, 0, 0],
    ],
  };
  let active = 0,
    timers = [];
  function actor(id) {
    return document.getElementById(id);
  }
  function set(el, x, y, deg) {
    if (!el) return;
    el.style.setProperty(
      "transform",
      `translate(${x}%,${y}%) rotate(${deg}deg)`,
      "important",
    );
    el.style.setProperty(
      "transition",
      "transform 230ms cubic-bezier(.22,.72,.28,1)",
      "important",
    );
    el.style.setProperty("z-index", "6", "important");
  }
  function clear() {
    active++;
    timers.forEach(clearTimeout);
    timers = [];
    for (const id of ["gideon", "gatekeeper"]) {
      const el = actor(id);
      if (el) {
        el.style.removeProperty("transform");
        el.style.removeProperty("transition");
        el.style.removeProperty("z-index");
      }
    }
  }
  window.APW71Motion = {
    start(type) {
      clear();
      const token = active;
      const a = actor("gideon"),
        b = actor("gatekeeper");
      if (!a || !b) return;
      const frames = seq[type];
      if (!frames) return;
      for (const [t, ax, ay, ar, bx, by, br] of frames) {
        timers.push(
          setTimeout(() => {
            if (token !== active) return;
            set(a, ax, ay, ar);
            set(b, bx, by, br);
          }, t),
        );
      }
      timers.push(
        setTimeout(
          () => {
            if (token === active) clear();
          },
          type === "ripcord" ? 3000 : 2650,
        ),
      );
    },
    clear,
  };
  // Restarting a match must clear any unfinished transform.
  document.addEventListener(
    "click",
    (e) => {
      if (e.target.closest("#restart")) clear();
    },
    true,
  );
})();

/* ---- Module 45 ---- */

/* Frame controller */
(function () {
  const states = [
    "apw72-walk",
    "apw72-grab",
    "apw72-strike",
    "apw72-hurt",
    "apw72-fall",
    "apw72-rise",
  ];
  const timers = {};
  function setup() {
    for (const id of ["gideon", "gatekeeper"]) {
      const el = document.getElementById(id),
        hero = el?.querySelector(".apw61-hero");
      if (!hero || el.classList.contains("apw72-rigged")) continue;
      if (!hero.complete || !hero.naturalWidth) {
        hero.addEventListener("load", setup, { once: true });
        continue;
      }
      for (const part of [
        "leftleg",
        "rightleg",
        "body",
        "leftarm",
        "rightarm",
      ]) {
        const layer = document.createElement("img");
        layer.src = hero.src;
        layer.alt = "";
        layer.setAttribute("aria-hidden", "true");
        layer.className = "apw72-part apw72-" + part;
        el.appendChild(layer);
      }
      el.classList.add("apw72-rigged");
    }
  }
  function pose(id, action, duration = 600) {
    setup();
    const el = document.getElementById(id);
    if (!el?.classList.contains("apw72-rigged")) return;
    clearTimeout(timers[id]);
    el.classList.remove(...states);
    void el.offsetWidth;
    el.classList.add("apw72-" + action);
    if (duration > 0)
      timers[id] = setTimeout(() => {
        el.classList.remove(...states);
      }, duration);
  }
  function clear() {
    for (const id of ["gideon", "gatekeeper"]) {
      clearTimeout(timers[id]);
      document.getElementById(id)?.classList.remove(...states);
    }
  }
  window.APW72Frames = { pose, clear, setup };
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", setup, { once: true });
  else setup();
  const old = window.APW71Motion;
  if (old && typeof old.clear === "function") {
    const prev = old.clear.bind(old);
    old.clear = function () {
      clear();
      return prev();
    };
  }
})();

/* ---- Module 46 ---- */

/* Pose observer */
(() => {
  "use strict";
  const ids = ["gideon", "gatekeeper"],
    last = new Map(),
    clocks = new Map();
  const combat = [
    "finishing",
    "slowhit",
    "grabbing",
    "attacking",
    "flyback",
    "down",
    "haunt",
    "hit",
  ];
  function apply(el) {
    if (!el?.classList.contains("apw72-rigged")) return;
    const state = combat.find((x) => el.classList.contains(x));
    if (state === last.get(el)) return;
    last.set(el, state);
    const id = el.id,
      rig = window.APW72Frames;
    if (!rig) return;
    if (clocks.has(id)) clearTimeout(clocks.get(id));
    if (state) {
      el.classList.remove("apw74-stance");
      const pose =
        state === "finishing" || state === "attacking" || state === "slowhit"
          ? "strike"
          : state === "grabbing" || state === "haunt"
            ? "grab"
            : state === "flyback" || state === "down"
              ? "fall"
              : "hurt";
      rig.pose(
        id,
        pose,
        state === "finishing" ? 1050 : state === "down" ? 850 : 600,
      );
      clocks.set(
        id,
        setTimeout(
          () => {
            if (!el.classList.contains("apw72-rigged")) return;
            el.classList.add("apw74-stance");
          },
          state === "finishing" ? 1150 : 900,
        ),
      );
    } else {
      el.classList.add("apw74-stance");
    }
  }
  function init() {
    const root = document.getElementById("fighters");
    if (!root) return;
    const observer = new MutationObserver((records) => {
      for (const r of records) {
        if (r.type === "attributes" && ids.includes(r.target.id))
          apply(r.target);
      }
    });
    observer.observe(root, {
      subtree: true,
      attributes: true,
      attributeFilter: ["class"],
    });
    for (const id of ids) {
      const el = document.getElementById(id);
      if (el) {
        el.classList.add("apw74-stance");
        apply(el);
      }
    }
    document.addEventListener(
      "click",
      (e) => {
        if (e.target.closest("#restart")) {
          for (const id of ids) {
            clearTimeout(clocks.get(id));
            const el = document.getElementById(id);
            el?.classList.add("apw74-stance");
          }
        }
      },
      true,
    );
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init);
  else init();
})();

/* ---- Module 47 ---- */

/* Gideon atlas */
(() => {
  "use strict";
  const atlas = { Gideon_Hark: APW_MEDIA[237], The_Gatekeeper: APW_MEDIA[238] };
  const names = [
    "idle",
    "guard",
    "strike",
    "grab",
    "hurt",
    "fall",
    "rise",
    "walkA",
    "walkB",
  ];
  const actors = { gideon: "Gideon_Hark", gatekeeper: "The_Gatekeeper" };
  const caches = {},
    last = {};
  function install(id) {
    const el = document.getElementById(id);
    if (!el) return;
    const hero = el.querySelector(".apw61-hero");
    if (!hero || !hero.complete || !hero.naturalWidth) return;
    let img = el.querySelector(".apw75-frame");
    if (!img) {
      img = document.createElement("img");
      img.className = "apw75-frame";
      img.alt = "";
      img.setAttribute("aria-hidden", "true");
      el.appendChild(img);
    }
    const key = actors[id];
    if (!caches[key]) {
      const source = new Image();
      source.src = atlas[key];
      caches[key] = { source, frames: [] };
      source.onerror = () => {
        el.classList.remove("apw75-sprites");
        img.remove();
      };
      source.onload = () => {
        for (let i = 0; i < 9; i++) {
          const c = document.createElement("canvas");
          c.width = 150;
          c.height = 225;
          c.getContext("2d").drawImage(
            source,
            i * 150,
            0,
            150,
            225,
            0,
            0,
            150,
            225,
          );
          caches[key].frames.push(c.toDataURL("image/png"));
        }
        update(id, true);
      };
    }
    if (caches[key]?.frames.length === 9) {
      el.classList.add("apw75-sprites");
      update(id, true);
    } else {
      caches[key]?.source?.addEventListener(
        "load",
        () => {
          if (caches[key]?.frames.length === 9) {
            el.classList.add("apw75-sprites");
            update(id, true);
          }
        },
        { once: true },
      );
    }
  }
  function state(el) {
    if (
      el.classList.contains("down") ||
      el.classList.contains("flyback") ||
      el.classList.contains("apw72-fall")
    )
      return "fall";
    if (el.classList.contains("apw72-rise")) return "rise";
    if (
      el.classList.contains("grabbing") ||
      el.classList.contains("haunt") ||
      el.classList.contains("apw72-grab")
    )
      return "grab";
    if (
      el.classList.contains("attacking") ||
      el.classList.contains("finishing") ||
      el.classList.contains("slowhit") ||
      el.classList.contains("apw72-strike")
    )
      return "strike";
    if (el.classList.contains("hit") || el.classList.contains("apw72-hurt"))
      return "hurt";
    if (el.classList.contains("apw72-walk"))
      return Math.floor(performance.now() / 185) % 2 ? "walkA" : "walkB";
    return Math.floor(performance.now() / 800) % 2 ? "idle" : "guard";
  }
  function update(id, force) {
    const el = document.getElementById(id),
      img = el?.querySelector(".apw75-frame"),
      key = actors[id];
    if (!img) return;
    const frame = state(el),
      idx = names.indexOf(frame),
      src = caches[key]?.frames[idx];
    if (src && (force || last[id] !== frame)) {
      img.src = src;
      last[id] = frame;
    }
    el.classList.toggle("apw75-fall", frame === "fall");
    if (el.dataset.apwPose !== frame) el.dataset.apwPose = frame;
  }
  function init() {
    for (const id of Object.keys(actors)) {
      install(id);
      update(id);
    }
  }
  // Avoid a MutationObserver feedback loop on the character class attribute.
  // Start atlas decoding only after the player enters the arena, keeping the menu responsive.
  let started = false;
  function start() {
    if (started) return;
    started = true;
    setTimeout(() => {
      init();
      setInterval(() => {
        for (const id of Object.keys(actors)) update(id);
      }, 90);
    }, 500);
  }
  function ready() {
    const play = document.getElementById("apw43play");
    const choose = document.getElementById("apw43choose");
    for (const btn of [play, choose])
      btn?.addEventListener("click", start, { once: true });
    if (document.getElementById("apw43menu")?.hidden) start();
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", ready);
  else ready();
})();

/* ---- Module 48 ---- */

/* Character sheets */
(() => {
  "use strict";
  const sheets = { gideon: APW_MEDIA[239], gatekeeper: APW_MEDIA[240] };

  let generation = 0,
    timers = [],
    loaded = false;
  const state = { gideon: 0, gatekeeper: 0 };
  function actor(id) {
    return document.getElementById(id);
  }
  function install() {
    if (loaded) return true;
    const a = actor("gideon"),
      b = actor("gatekeeper");
    if (!a || !b) return false;
    for (const id of Object.keys(sheets)) {
      const el = actor(id);
      if (el.querySelector(".apw80-cel")) continue;
      const im = document.createElement("img");
      im.className = "apw80-cel";
      im.alt = "";
      im.setAttribute("aria-hidden", "true");
      im.decoding = "async";
      im.src = sheets[id];
      im.addEventListener(
        "error",
        () => {
          el.classList.remove("apw80-playing", "apw81-ready");
        },
        { once: true },
      );
      im.addEventListener(
        "load",
        () => {
          if (im.naturalWidth > 0) el.classList.add("apw81-ready");
        },
        { once: true },
      );
      el.appendChild(im);
      if (im.complete && im.naturalWidth > 0) el.classList.add("apw81-ready");
    }
    loaded = true;
    return true;
  }
  function cel(id, index) {
    const el = actor(id);
    if (!el) return;
    const im = el.querySelector(".apw80-cel");
    if (!im) return;
    state[id] = index;
    im.style.objectPosition = "0 0";
    im.style.transform = "translateX(" + (-index * 100) / 8 + "%)";
  }
  function show() {
    for (const id of Object.keys(sheets)) {
      actor(id)?.classList.add("apw80-playing");
    }
  }
  function clear() {
    generation++;
    timers.forEach(clearTimeout);
    timers = [];
    for (const id of Object.keys(sheets)) {
      const el = actor(id);
      el?.classList.remove("apw80-playing");
      cel(id, 0);
    }
  }
  function play(type) {
    clear();
    if (!install()) return;
    const token = generation;
    show();
    const seq =
      type === "ripcord"
        ? [
            [0, 1, 0],
            [330, 2, 1],
            [650, 3, 2],
            [1000, 4, 3],
            [1450, 5, 4],
            [1800, 5, 6],
            [2300, 7, 6],
            [2900, 0, 7],
          ]
        : [
            [0, 0, 1],
            [330, 1, 2],
            [690, 2, 3],
            [1050, 3, 4],
            [1420, 6, 5],
            [1860, 6, 6],
            [2350, 7, 7],
            [2900, 0, 0],
          ];
    for (const [ms, g, k] of seq) {
      timers.push(
        setTimeout(() => {
          if (token !== generation) return;
          cel("gideon", g);
          cel("gatekeeper", k);
        }, ms),
      );
    }
    timers.push(
      setTimeout(() => {
        if (token === generation) clear();
      }, 3200),
    );
  }
  function hook() {
    const motion = window.APW71Motion;
    if (!motion || motion.__apw80) return;
    const orig = motion.start.bind(motion),
      oldClear = motion.clear?.bind(motion);
    motion.start = function (type) {
      orig(type);
      if (type === "ripcord" || type === "ghost") play(type);
    };
    motion.clear = function () {
      clear();
      return oldClear?.();
    };
    motion.__apw80 = true;
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", hook);
  else hook();
  // Preload only after the arena has been entered; do not block the title-screen button.
  document.addEventListener(
    "click",
    (e) => {
      if (e.target.closest("#enterArena,#enter-arena,#startGame,#start-game"))
        setTimeout(install, 300);
    },
    { passive: true },
  );
  window.APW80Cels = { play, clear };
})();

/* ---- Module 49 ---- */

/* Roster render bridge */
(() => {
  "use strict";
  /* The game's existing APW_ROSTER_SPRITES collection contains character-specific
   idle, strike, grapple, hit, down, walk, finisher and victory artwork.
   This bridge connects those assets to the MAIN ring, not just the roster gallery. */
  const poseOrder = [
    ["finishing", "finisher"],
    ["slowhit", "finisher"],
    ["finisher", "finisher"],
    ["down", "down"],
    ["flyback", "down"],
    ["grabbing", "grapple"],
    ["haunt", "grapple"],
    ["grapple", "grapple"],
    ["attack", "strike"],
    ["attacking", "strike"],
    ["strike", "strike"],
    ["hit", "hit"],
    ["walk", "walk"],
    ["victory", "victory"],
  ];
  const ids = ["gideon", "gatekeeper"];
  let live = false;
  function roster() {
    return window.APW_ROSTER_SPRITES || {};
  }
  function names() {
    return [
      window.APW_CAREER?.name ||
        document.getElementById("careerWrestler")?.value ||
        "Gideon Hark",
      window.APW_OPPONENT || "The Gatekeeper",
    ];
  }
  function pose(el) {
    for (const [state, frame] of poseOrder)
      if (el.classList.contains(state)) return frame;
    const p = el.dataset.apwPose || "idle";
    return (
      {
        grab: "grapple",
        hurt: "hit",
        fall: "down",
        rise: "idle",
        walkA: "walk",
        walkB: "walk",
      }[p] || p
    );
  }
  function refresh() {
    if (!live) return;
    const all = roster(),
      who = names();
    ids.forEach((id, i) => {
      const el = document.getElementById(id),
        name = who[i],
        art = all[name];
      if (!el) return;
      const enhanced = [
        "Birdman Phil Picasso",
        "Bruza The Serb",
        "Nikki Poteet",
        "Doomslayer",
      ].includes(name);
      if (el.classList.contains("apw112-enhanced") !== enhanced)
        el.classList.toggle("apw112-enhanced", enhanced);
      // Keep v8.1's specially composed Gideon/Gatekeeper cinematic intact.
      const bespoke =
        (i === 0 && name === "Gideon Hark") ||
        (i === 1 && name === "The Gatekeeper");
      if (bespoke || !art) {
        if (el.classList.contains("apw82-roster-active"))
          el.classList.remove("apw82-roster-active");
        return;
      }
      let im = el.querySelector(".apw82-roster-sprite");
      if (!im) {
        im = document.createElement("img");
        im.className = "apw82-roster-sprite";
        im.alt = "";
        im.setAttribute("aria-hidden", "true");
        im.decoding = "async";
        im.addEventListener("error", () => {
          el.classList.remove("apw82-roster-active");
        });
        el.appendChild(im);
      }
      const requested = pose(el),
        p = art[requested] ? requested : "idle";
      const url = art[p] || art.idle;
      if (!url) {
        if (el.classList.contains("apw82-roster-active"))
          el.classList.remove("apw82-roster-active");
        return;
      }
      if (im.dataset.who !== name || im.dataset.pose !== p) {
        el.classList.remove("apw82-roster-active");
        im.dataset.who = name;
        im.dataset.pose = p;
        // Do not hide fallback until the chosen roster pose has decoded.
        const check = url;
        const test = new Image();
        test.onload = () => {
          if (im.dataset.who !== name || im.dataset.pose !== p) return;
          im.src = check;
          el.classList.add("apw82-roster-active");
          el.dataset.apw82Pose = p;
        };
        test.onerror = () => {
          if (im.dataset.who === name)
            el.classList.remove("apw82-roster-active");
        };
        test.src = check;
        if (test.complete && test.naturalWidth) test.onload();
      } else el.dataset.apw82Pose = p;
    });
  }
  function start() {
    if (live) return;
    live = true;
    refresh();
    document
      .getElementById("careerWrestler")
      ?.addEventListener("change", refresh);
    const observer = new MutationObserver(refresh);
    for (const id of ids) {
      const el = document.getElementById(id);
      if (el)
        observer.observe(el, {
          attributes: true,
          attributeFilter: ["class", "data-apw-pose"],
        });
    }
  }
  function ready() {
    for (const id of ["apw43play", "apw43choose"])
      document
        .getElementById(id)
        ?.addEventListener("click", () => setTimeout(start, 350), {
          once: true,
        });
    if (document.getElementById("apw43menu")?.hidden) start();
    document
      .getElementById("careerWrestler")
      ?.addEventListener("change", () => {
        start();
        setTimeout(refresh, 0);
        setTimeout(refresh, 300);
      });
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", ready);
  else ready();
  window.addEventListener("apw:career-changed", () => {
    start();
    refresh();
  });
  window.APW82RosterSprites = { refresh, start };
})();

/* ---- Module 50 ---- */

/* Simon artwork */
(() => {
  "use strict";
  const art = APW_MEDIA[241];
  let active = "";
  function update() {
    const name = window.APW_CAREER?.name || "Gideon Hark";
    const fighter = document.getElementById("gideon");
    if (!fighter) return;
    const simon = name === "Simon Temple";
    fighter.classList.toggle("apw84-simon", simon);
    if (simon) {
      let img = fighter.querySelector(".apw84-simon-art");
      if (!img) {
        img = document.createElement("img");
        img.className = "apw84-simon-art";
        img.alt = "Simon Temple detailed wrestler sprite";
        img.src = art;
        fighter.appendChild(img);
      }
      const panel = document.querySelector(".stats .panel h3");
      if (panel) panel.textContent = "SIMON TEMPLE";
    } else {
      const panel = document.querySelector(".stats .panel h3");
      if (panel) panel.textContent = name.toUpperCase();
    }
    if (active !== name) {
      active = name;
      const btn = document.querySelector('[data-move="finisher"]');
      if (btn) {
        const names = {
          "Simon Temple": "CHOKE SLAM",
          "Gideon Hark": "RIPCORD CLOTHESLINE",
          "Birdman Phil Picasso": "DOUBLE UNDERHOOK DDT",
          "Bruza The Serb": "RUSSIAN LEG SWEEP",
        };
        let label = btn.querySelector(".apw84-move-label");
        if (!label) {
          label = document.createElement("span");
          label.className = "apw84-move-label";
          btn.insertBefore(label, btn.firstChild);
          for (const node of [...btn.childNodes])
            if (
              node !== label &&
              node.nodeType === Node.TEXT_NODE &&
              node.textContent.trim()
            )
              node.textContent = "";
        }
        label.textContent = "★ " + (names[name] || "FINISHER");
      }
    }
  }
  window.addEventListener("apw:career-changed", update);
  function init() {
    update();
    document
      .getElementById("restart")
      ?.addEventListener("click", () => setTimeout(update, 60));
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init);
  else init();
})();

/* ---- Module 51 ---- */

/* Simon chokeslam */
(() => {
  "use strict";
  let pending = [],
    running = false;
  function stop() {
    pending.forEach(clearTimeout);
    pending = [];
    running = false;
    document.getElementById("gideon")?.classList.remove("apw85-chokeslam");
    document
      .getElementById("gatekeeper")
      ?.classList.remove("apw85-chokeslam-victim");
  }
  window.APW85Chokeslam = { trigger, clear: stop };
  function selected() {
    return (
      document.getElementById("careerWrestler")?.value ||
      window.APW_CAREER?.name ||
      "Gideon Hark"
    );
  }
  function trigger() {
    if (running || selected() !== "Simon Temple") return;
    const p = document.getElementById("gideon"),
      e = document.getElementById("gatekeeper");
    if (!p || !e) return;
    stop();
    running = true;
    // Animation only; the game's existing combat code remains authoritative.
    p.classList.add("apw85-chokeslam");
    e.classList.add("apw85-chokeslam-victim");
    pending.push(setTimeout(stop, 2750));
  }
  function init() {
    window.addEventListener("apw:finisher", (e) => {
      if (e.detail?.wrestler === "Simon Temple") trigger();
    });
    document.getElementById("restart")?.addEventListener("click", stop);
    document.getElementById("careerWrestler")?.addEventListener("change", stop);
    window.addEventListener("apw:career-changed", stop);
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init);
  else init();
})();

/* ---- Module 52 ---- */

/* Career lifecycle */
(() => {
  "use strict";
  const old = window.apwChoose;
  window.apwChoose = function (name) {
    if (
      !Array.from(document.getElementById("careerWrestler").options).some(
        (o) => o.value === name,
      )
    )
      return;
    window.APW_TEAM_B.settleResult();
    document.getElementById("careerWrestler").value = name;
    old(name);
    window.APW_TEAM_B.resets.forEach((reset) => reset());
    window.dispatchEvent(new Event("apw:career-changed"));
  };
})();

/* ---- Module 53 ---- */

/* Career route */
(() => {
  "use strict";
  const read = (k) => {
    try {
      const x = JSON.parse(localStorage.getItem(k) || "null");
      if (
        !x ||
        typeof x !== "object" ||
        Array.isArray(x) ||
        (x._career && x._career !== APW_CAREER.name)
      )
        return null;
      if (k === "apwStory27") return APW_TEAM_B.story();
      for (const [f, lo, hi, fallback] of [
        ["phase", 0, 4, 0],
        ["stage", 0, 4, 0],
        [
          "chapter",
          k === "apwChampion34" ? 20 : 0,
          k === "apwChampion34" ? 24 : 4,
          k === "apwChampion34" ? 20 : 0,
        ],
      ])
        if (f in x && (!Number.isInteger(x[f]) || x[f] < lo || x[f] > hi))
          x[f] = fallback;
      if ("champion" in x && typeof x.champion !== "boolean") delete x.champion;
      return x;
    } catch (e) {
      return null;
    }
  };
  const panel = document.createElement("section");
  panel.className = "apw-tower";
  panel.id = "apwCareerPath";
  panel.innerHTML =
    '<h2>CAREER ROAD TO BRUZA</h2><p id="apwCareerObjective"></p><button id="apwCareerContinue">CONTINUE CAREER ▶</button>';
  document.querySelector(".career-panel").after(panel);
  function step() {
    const t = window.APW_TOWER.state(),
      story = read("apwStory27"),
      show = read("apwShowdown28"),
      elim = read("apwConspiracy30"),
      cage = read("apwCage32"),
      main = read("apwMainEvent33");
    const reign = read("apwChampion34");
    if (reign?.champion === false && reign.lastResult === "loss")
      return [
        "Regain the APW Heavyweight Championship — win your comeback match.",
        "#apw34",
      ];
    if (t.champion || main?.result === "win")
      return ["Champion — defend the APW Heavyweight Championship.", "#apw34"];
    // Resume the furthest earned narrative stage in legacy saves without replaying cleared floors.
    if (main?.phase > 0)
      return ["Resume the APW Heavyweight Championship challenge.", "#apw33"];
    if (cage?.finish === "win")
      return [
        "Challenge Bruza for the APW Heavyweight Championship.",
        "#apw33",
      ];
    if (cage?.phase > 0)
      return ["Resume the steel cage challenge against Birdman.", "#apw32"];
    if (elim?.stage === 4 && elim.outcome === "win")
      return [
        "Beat Birdman inside the steel cage to secure your title shot.",
        "#apw32",
      ];
    if (elim?.stage > 0)
      return ["Resume the championship eliminator against Bruza.", "#apw30"];
    if (show?.wins && show.phase >= 4)
      return ["Win the championship eliminator against Bruza.", "#apw30"];
    if (show?.phase > 0)
      return [
        show.phase === 4 && show.wins === 0
          ? "Rematch Birdman to advance your career."
          : "Finish the Birdman showdown.",
        "#apw28Scene",
      ];
    if ((story?.chapter || 0) >= 4)
      return ["Defeat Birdman in the grudge match.", "#apw28Scene"];
    if ((story?.chapter || 0) > 0)
      return ["Continue your backstage investigation.", "#politicsScene"];
    if (!APW_CAREER.qualified)
      return ["Defeat The Gatekeeper to enter the APW Tower.", ".arena", 0];
    if (t.floor < 5)
      return [
        "Clear Tower floor " +
          Math.max(1, t.floor) +
          " to earn your confrontation with Birdman.",
        ".arena",
        Math.max(1, t.floor),
      ];
    return [
      "Complete the four backstage chapters and choose your allies.",
      "#politicsScene",
    ];
  }
  function refresh() {
    window.APW_TOWER.refresh();
    document.getElementById("apwCareerObjective").textContent = step()[0];
    window.dispatchEvent(new Event("apw:path-refresh"));
  }
  window.APW_PATH = {
    objective: step,
    storyReady() {
      return !!APW_CAREER.qualified && window.APW_TOWER.state().floor >= 5;
    },
    refresh,
  };
  let refreshQueued = false;
  function scheduleRefresh() {
    if (refreshQueued) return;
    refreshQueued = true;
    queueMicrotask(() => {
      refreshQueued = false;
      refresh();
    });
  }
  // Only progress saves refresh the route; art/venue persistence stays independent.
  const store = APW_TEAM_B.store;
  APW_TEAM_B.store = function (k, v) {
    store.call(this, k, v);
    if (
      [
        "apwCareer08",
        "apwTower12",
        "apwChapter13",
        "apwStory27",
        "apwShowdown28",
        "apwConspiracy30",
        "apwCage32",
        "apwMainEvent33",
        "apwChampion34",
      ].includes(k)
    )
      scheduleRefresh();
  };
  window.addEventListener("load", refresh);
  window.addEventListener("apw:career-changed", refresh);
  refresh();
})();

/* ---- Module 54 ---- */

/* Unified views */
/* Screen navigation owns presentation only. Combat/save modules retain their nodes and state. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const main = document.querySelector("main"),
    panel = $("apwCareerPath");
  const titles = {
    home: "APW Headquarters",
    career: "Career",
    match: "Your match",
    roster: "Choose your wrestler",
    training: "Training centre",
    tower: "APW Tower rankings",
    tag: "Tag-team wrestling",
    extras: "Art & extras",
    rules: "Rules & strategy",
    saves: "Saves & backups",
    settings: "Settings",
    "move-studio": "Move studio",
    "sprite-studio": "Roster sprite studio",
    records: "Career records",
    "side-story": "Backstage extras",
    guide: "Roster guide",
  };
  const primary = [
    "home",
    "career",
    "match",
    "training",
    "tower",
    "roster",
    "tag",
    "extras",
    "rules",
    "saves",
    "settings",
  ];
  let view = "home",
    exhibition = false,
    scheduled = false,
    initialized = false;
  const read = (key) => {
    try {
      const value = JSON.parse(localStorage.getItem(key) || "null");
      return value && (!value._career || value._career === APW_CAREER.name)
        ? value
        : null;
    } catch {
      return null;
    }
  };
  const style = document.createElement("style");
  style.textContent = `
  .apw68-away,body.apw105-screens [hidden],body.apw105-screens [data-apw-screen][hidden]{display:none!important}
  body.apw105-screens{margin:0;padding:0 0 env(safe-area-inset-bottom);background:radial-gradient(ellipse at top,#2a1645,#0a0c1b 65%);color:#f5edff}
  body.apw105-screens main{max-width:1240px;margin:0 auto;padding:16px;background:none!important;display:grid;grid-template-columns:190px minmax(0,1fr);gap:18px;align-items:start}
  #apw105Header{grid-column:1/-1;display:flex;align-items:center;gap:16px;padding:16px 18px;border:1px solid #63537e;border-top:3px solid #ff6cba;border-radius:12px;background:#151328}
  #apw105Brand{flex:1;font:bold 20px monospace;letter-spacing:1px;color:#ffb2e2}#apw105Brand small{display:block;margin-top:5px;font:11px monospace;letter-spacing:2px;color:#75e7fa}
  #apw105Header button,#apw105ScreenSelect{min-height:44px;border:1px solid #76dfee;border-radius:6px;background:#231b39;color:white;padding:9px 12px;font-weight:bold}
  #apw105ScreenSelect{display:none;max-width:100%}#apw105Nav{position:sticky;top:16px;display:grid;gap:7px;padding:12px;border:1px solid #514566;border-radius:12px;background:#141326}
  #apw105Nav button{min-height:44px;padding:12px;text-align:left;background:transparent;border:1px solid transparent;border-radius:6px;color:#d5c7e6;font:bold 12px monospace;cursor:pointer}
  #apw105Nav button[aria-current=page]{border-color:#ff75bc;background:#442340;color:#fff3fc;box-shadow:inset 3px 0 #7aeaff}
  #apw68stage{min-width:0}#apw68stage>[data-apw-screen]{min-width:0;padding:0 0 20px}#apw68stage>:not([data-apw-screen]){display:none!important}
  [data-apw-screen]>h1{border:0!important;background:none!important;box-shadow:none!important;padding:0!important;margin:0 0 16px;font:bold 24px monospace;color:#ffe6a3;line-height:1.3}
  [data-apw-screen]>h1:focus{outline:none!important}[data-apw-screen] p{line-height:1.6}[data-apw-screen] section{max-width:100%;box-sizing:border-box}
  .apw105-card{padding:22px;border:1px solid #675079;border-radius:12px;background:linear-gradient(135deg,#251c39,#14152b);margin-bottom:16px}
  .apw105-kicker{font:bold 11px monospace;color:#70eafa;letter-spacing:2px;margin:0 0 10px}.apw105-card h2{font:900 clamp(23px,4vw,38px)/1.15 monospace;color:#ffa8d9;margin:0 0 12px}
  .apw105-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}.apw105-actions button,.apw105-tiles button,[data-apw-back]{min-height:48px;padding:13px 16px;border-radius:7px;border:1px solid #d578b7;background:#2b203e;color:#fff;font-weight:bold;cursor:pointer}
  .apw105-actions .primary{background:#563061;border-color:#ffb2de;box-shadow:0 0 16px #ff64c12b}.apw105-tiles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
  .apw105-tiles button{text-align:left;padding:18px;background:#19182d;border-color:#57506d}.apw105-tiles button small{display:block;margin-top:7px;line-height:1.5;color:#bdadcf;font-weight:normal}
  #apwCareerPath{max-width:none;margin:0;padding:20px;border-radius:12px}#apwCareerPath>h2{display:none}#apwCareerObjective{font-size:18px;color:#fff2c9}
  #apwCareerContinue{min-height:48px;padding:12px 20px}#apw68map{list-style:none;padding:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
  #apw68map li{padding:10px;border:1px solid #514361;border-radius:6px;font-size:12px}#apw68map .done{color:#8effc1}#apw68map [aria-current=step]{border-color:#fbd280;color:#fbd280}
  #apw68result{white-space:pre-wrap;font-size:13px}#apw105Journey,#apw105LastResult{margin-top:18px;border-top:1px solid #675079;padding-top:12px}#apw105Journey summary,#apw105LastResult summary{cursor:pointer;color:#9feaff;padding:8px 0}
  #apw105MatchResult:empty{display:none}#apw105MatchResult{white-space:pre-wrap;background:#242038;border-left:3px solid #ffe09a;padding:12px;font-size:13px}
  [data-apw-screen=match]>.top{margin-bottom:12px;padding:10px;border-radius:7px;background:#18162b}[data-apw-screen=match]>.top .brand{font-size:13px}[data-apw-screen=match]>.top .tag{display:none}
  [data-apw-screen=match]>.top>div{display:none!important}[data-apw-screen=match]>.top{justify-content:flex-end!important;padding:6px!important;min-height:24px}[data-apw-screen=match] .command{display:block!important;margin-top:12px}[data-apw-screen=match] .command button{min-height:46px}[data-apw-screen=match] .stats{margin:10px 0}
  #apw105Venue{margin:0 0 10px;border:1px solid #514566;border-radius:8px;padding:10px}#apw105Venue summary{cursor:pointer;color:#97e9ff;padding:4px}#apw105Venue button{min-height:44px;margin-top:8px}#apw105Log{margin-top:12px;border:1px solid #514566;border-radius:8px;padding:10px}#apw105Log summary{cursor:pointer;color:#97e9ff;padding:4px}#apw105Log #log{max-height:220px;overflow:auto}
  #apw62utilityDock{display:flex!important;position:static!important;flex-wrap:wrap!important;gap:12px!important;max-width:none!important;margin:0!important;padding:0!important;background:none!important;border:0!important}
  #apw62utilityDock button,[data-apw-screen] #apw86open,[data-apw-screen] #apw100-launch,[data-apw-screen] #apw43launcher{position:static!important;inset:auto!important;transform:none!important;margin:0!important;min-height:48px;font-size:13px!important;white-space:normal}
[data-apw-screen=settings] #apw43launcher{display:inline-block}
  [data-apw-screen]>.apw40-gallery,[data-apw-screen]>#apw37-preview{margin:0!important}
  #apw105Header button:focus-visible,#apw105Nav button:focus-visible,[data-apw-screen] button:focus-visible,#apw105ScreenSelect:focus-visible{outline:3px solid #7fefff;outline-offset:3px}
  @media(min-width:1000px){
  body.apw105-screens #apw105-match.apw105-singles:not([hidden]){display:grid;grid-template-columns:minmax(0,1.6fr) minmax(260px,1fr);grid-template-areas:"title title" "status status" "options options" "ring commands" "stats commands" "log log";gap:12px}
  #apw105-match.apw105-singles>h1{grid-area:title;margin:0!important}#apw105-match.apw105-singles>.top{grid-area:status;margin:0!important}
  #apw105-match.apw105-singles>#apw105Venue{grid-area:options;margin:0}#apw105-match.apw105-singles>.arena{grid-area:ring;margin:0}
  #apw105-match.apw105-singles>.stats{grid-area:stats;margin:0}#apw105-match.apw105-singles>.command{grid-area:commands;margin:0;align-self:stretch}
  #apw105-match.apw105-singles>.command>.panel{height:100%;box-sizing:border-box}#apw105-match.apw105-singles .command .buttons{grid-template-columns:repeat(2,minmax(0,1fr));height:100%;align-content:stretch}
  #apw105-match.apw105-singles>#apw105Log{grid-area:log;margin:0}
  }
  @media(max-width:720px){body.apw105-screens main{display:block;padding:10px}#apw105Header{position:sticky;top:0;z-index:1000;flex-wrap:wrap;padding:12px;margin-bottom:18px;gap:10px;background:#151328f5;backdrop-filter:blur(8px)}#apw105Brand{font-size:16px}#apw105Brand small{font-size:9px}#apw105Nav{display:none}#apw105ScreenSelect{display:block;flex-basis:100%;width:100%}[data-apw-screen]>h1{font-size:21px}.apw105-card{padding:18px}.apw105-tiles{gap:9px}.apw105-tiles button{padding:14px;font-size:12px}#apw105Header button{font-size:11px}}
  @media(prefers-reduced-motion:reduce){#apw105Header{backdrop-filter:none}}
  `;
  document.head.append(style);
  document.body.classList.add("apw105-screens");
  const header = document.createElement("header");
  header.id = "apw105Header";
  header.innerHTML =
    '<div id="apw105Brand">APW: NO TEA PARTY!<small>SYDNEY · WRESTLING RPG</small></div><button type="button" id="apw105Home">⌂ HOME</button><select id="apw105ScreenSelect" aria-label="Go to screen"></select>';
  const nav = document.createElement("nav");
  nav.id = "apw105Nav";
  nav.setAttribute("aria-label", "Main menu");
  const stage = document.createElement("div");
  stage.id = "apw68stage";
  const screens = {};
  for (const [id, title] of Object.entries(titles)) {
    const page = document.createElement("section");
    page.dataset.apwScreen = id;
    page.id = "apw105-" + id;
    page.hidden = true;
    page.inert = true;
    page.setAttribute("aria-labelledby", page.id + "-title");
    const h = document.createElement("h1");
    h.id = page.id + "-title";
    h.textContent = title;
    h.tabIndex = -1;
    page.append(h);
    screens[id] = page;
    stage.append(page);
  }
  main.prepend(header, nav);
  main.append(stage);
  function button(label, action) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    b.onclick = action;
    return b;
  }
  for (const id of primary) {
    const b = button(titles[id], () => navigate(id));
    b.dataset.view = id;
    nav.append(b);
    const o = document.createElement("option");
    o.value = id;
    o.textContent = titles[id];
    $("apw105ScreenSelect").append(o);
  }
  $("apw105Home").onclick = () => navigate("home");
  $("apw105ScreenSelect").onchange = (e) => navigate(e.target.value);
  const home = document.createElement("div");
  home.innerHTML =
    '<div class="apw105-card"><p class="apw105-kicker">APW HEADQUARTERS</p><h2>YOUR ROAD TO<br>THE HEAVYWEIGHT TITLE.</h2><p id="apw105Identity"></p><p id="apw105Objective"></p><div class="apw105-actions" id="apw105HomeActions"></div></div><div class="apw105-tiles" id="apw105HomeTiles"></div>';
  screens.home.append(home);
  const resume = button("CONTINUE CAREER ▶", next);
  resume.className = "primary";
  $("apw105HomeActions").append(
    resume,
    button("TAG-TEAM MATCH", () => navigate("tag")),
  );
  for (const [id, detail] of [
    ["career", "Your next objective, journey and last result."],
    ["training", "Train and upgrade your wrestler."],
    ["tower", "Rankings and unlocked opponents."],
    ["roster", "Start a career with any roster wrestler."],
    ["rules", "Learn moves, tactics and career rules."],
    ["saves", "Back up or restore your progress."],
  ]) {
    const b = button(titles[id], () => navigate(id));
    const small = document.createElement("small");
    small.textContent = detail;
    b.append(small);
    $("apw105HomeTiles").append(b);
  }
  screens.career.append(panel);
  const map = document.createElement("ol");
  map.id = "apw68map";
  map.setAttribute("aria-label", "Career journey");
  const journey = document.createElement("details");
  journey.id = "apw105Journey";
  journey.innerHTML = "<summary>Your career journey</summary>";
  journey.append(map);
  const last = document.createElement("details");
  last.id = "apw105LastResult";
  last.innerHTML =
    '<summary>Last match result</summary><p id="apw68result"></p>';
  panel.append(journey, last);
  const matchOptions = document.createElement("details");
  matchOptions.id = "apw105Venue";
  matchOptions.innerHTML = "<summary>Venue & match options</summary>";
  screens.match.append(matchOptions);
  const logDetails = document.createElement("details");
  logDetails.id = "apw105Log";
  logDetails.innerHTML = "<summary>Match commentary</summary>";
  screens.match.append(logDetails);
  const extrasIntro = document.createElement("p");
  extrasIntro.textContent =
    "Choose a gallery or studio. Each opens separately.";
  screens.extras.append(extrasIntro);
  const dock = document.createElement("section");
  dock.id = "apw62utilityDock";
  screens.extras.append(dock);
  const extraLinks = document.createElement("div");
  extraLinks.className = "apw105-tiles";
  screens.extras.append(extraLinks);
  for (const id of [
    "move-studio",
    "sprite-studio",
    "records",
    "side-story",
    "guide",
  ]) {
    extraLinks.append(button(titles[id], () => navigate(id)));
    const back = button("← ART & EXTRAS", () => navigate("extras"));
    back.dataset.apwBack = "extras";
    screens[id].insertBefore(back, screens[id].firstChild);
  }
  const settingsIntro = document.createElement("div");
  settingsIntro.className = "apw105-card";
  settingsIntro.innerHTML =
    "<h2>MAKE IT YOUR RING.</h2><p>Open game options for sound, motion and the original browser save slots.</p>";
  screens.settings.append(settingsIntro);
  const rosterHint = document.createElement("p");
  rosterHint.textContent =
    "Choosing a different wrestler starts a new career. Use Saves & backups to keep an independent copy before switching.";
  screens.roster.insertBefore(rosterHint, screens.roster.children[1] || null);
  const hint = document.createElement("p");
  hint.textContent =
    "Choose the classic championship match below, or open Tactical Tag for its separate tactics mode.";
  screens.tag.append(hint);
  function adopt(el, id) {
    if (!el) return;
    if (el.parentElement !== screens[id]) screens[id].append(el);
    el.classList.remove("apw68-away");
    el.inert = false;
  }
  function organize() {
    adopt(dock, "extras");
    const consequences = $("apw69Consequences");
    if (consequences && !consequences.dataset.screenReady) {
      consequences.open = false;
      consequences.dataset.screenReady = "true";
    }
    adopt(document.querySelector(".career-panel"), "roster");
    adopt($("apwHub"), "training");
    adopt($("towerMatches")?.closest("section"), "tower");
    adopt($("tagmode"), "tag");
    adopt($("apw86open"), "tag");
    adopt($("apw70Rules"), "rules");
    adopt($("apw71Saves"), "saves");
    adopt($("apw37-preview"), "move-studio");
    adopt(document.querySelector(".apw40-gallery"), "sprite-studio");
    adopt($("apw13"), "side-story");
    adopt($("apw41guide"), "guide");
    adopt($("apw42"), "records");
    for (const id of [
      "apw49launch",
      "apw46launch",
      "apw52launch",
      "apw51open",
      "apw53launch",
      "apw55open",
      "apw100-launch",
      "apw106launch",
    ]) {
      const el = $(id);
      if (el && el.parentElement !== dock) dock.append(el);
    }
    adopt($("apw43launcher"), "settings");
    const restart = $("restart");
    if (restart && restart.parentElement !== matchOptions)
      matchOptions.append(restart);
    const top = main.querySelector(":scope > .top");
    if (top) screens.match.insertBefore(top, matchOptions);
    const venue = $("apw60venuebar"),
      arena = document.querySelector(".arena"),
      stats = document.querySelector(".stats"),
      command = document.querySelector(".command");
    if (venue && venue.parentElement !== matchOptions) {
      venue.classList.remove("apw68-away");
      venue.inert = false;
      matchOptions.insertBefore(venue, $("restart") || null);
    }
    for (const el of [arena, stats, command])
      if (el) {
        el.classList.remove("apw68-away");
        el.inert = false;
        if (el.parentElement !== screens.match)
          screens.match.insertBefore(el, logDetails);
      }
    const logPanel = $("log")?.closest("section");
    if (logPanel && logPanel.parentElement !== logDetails)
      logDetails.append(logPanel);
    if (!initialized) {
      initialized = true;
      if ($("apw43menu")) $("apw43menu").hidden = true;
      if ($("apw43launcher")) $("apw43launcher").hidden = false;
      $("apw43launcher")?.addEventListener("click", () =>
        document.querySelector('[data-panel="options"]')?.click(),
      );
    }
  }
  function current() {
    const o = APW_PATH.objective();
    const target =
      o[1] === "#politicsScene"
        ? "apwPolitics"
        : o[1] === "#apw28Scene"
          ? "apw28"
          : o[1].slice(1);
    const index =
      o[1] === ".arena"
        ? o[2] === 0
          ? 0
          : 1
        : ({ apwPolitics: 2, apw28: 3, apw30: 4, apw32: 5, apw33: 6, apw34: 7 }[
            target
          ] ?? 0);
    return { o, target, index };
  }
  function lastResult() {
    for (const [key, field] of [
      ["apwChampion34", "lastResult"],
      ["apwMainEvent33", "result"],
      ["apwCage32", "finish"],
      ["apwConspiracy30", "outcome"],
    ]) {
      const s = read(key);
      if (s?.[field]) return s.log || "";
    }
    const s = read("apwShowdown28");
    return s?.phase >= 3 ? s.log || "" : "";
  }
  function render() {
    organize();
    const s = current(),
      singles = exhibition || s.o[1] === ".arena";
    screens.match.classList.toggle("apw105-singles", singles);
    for (const [id, page] of Object.entries(screens)) {
      page.hidden = id !== view;
      page.inert = id !== view;
    }
    for (const b of nav.querySelectorAll("button")) {
      if (b.dataset.view === view) b.setAttribute("aria-current", "page");
      else b.removeAttribute("aria-current");
    }
    $("apw105ScreenSelect").value =
      primary.includes(view) || view === "match" ? view : "extras";
    $("apw105Identity").textContent =
      APW_CAREER.name + " · " + APW_CAREER.wins + " career wins";
    $("apw105Objective").textContent = s.o[0];
    $("apwCareerObjective").textContent = s.o[0];
    $("apwCareerContinue").textContent = "ENTER / RESUME MATCH ▶";
    const labels = [
      "Qualifier",
      "Tower · floors 1–4",
      "Backstage",
      "Birdman showdown",
      "Eliminator",
      "Steel cage",
      "Bruza title match",
      "Championship reign",
    ];
    if (map.dataset.step !== String(s.index)) {
      map.dataset.step = s.index;
      map.replaceChildren(
        ...labels.map((text, i) => {
          const li = document.createElement("li");
          li.textContent = (i < s.index ? "✓ " : "") + text;
          if (i < s.index) li.className = "done";
          if (i === s.index) li.setAttribute("aria-current", "step");
          return li;
        }),
      );
    }
    $("apw68result").textContent = lastResult();
    last.hidden = !$("apw68result").textContent;
    for (const el of [
      screens.match.querySelector(":scope > .top"),
      matchOptions,
      document.querySelector(".arena"),
      document.querySelector(".stats"),
      document.querySelector(".command"),
      logDetails,
    ])
      if (el) {
        el.hidden = !singles;
        el.inert = !singles;
      }
    for (const id of [
      "apwPolitics",
      "apw28",
      "apw30",
      "apw32",
      "apw33",
      "apw34",
    ]) {
      const el = $(id);
      if (!el) continue;
      adopt(el, "match");
      el.hidden = singles || id !== s.target;
      el.inert = el.hidden;
    }
  }
  function scrollTop() {
    try {
      window.scrollTo({ top: 0, behavior: "instant" });
    } catch {}
  }
  function navigate(id, { record = true, scroll = true } = {}) {
    if (!screens[id]) return;
    const changed = view !== id;
    view = id;
    render();
    if (changed)
      window.dispatchEvent(
        new CustomEvent("apw:screen-changed", { detail: { screen: id } }),
      );
    if (record && changed) {
      try {
        history.pushState({ apwScreen: id }, "", "#apw-screen-" + id);
      } catch {}
    }
    if (scroll) {
      scrollTop();
      screens[id].querySelector("h1")?.focus({ preventScroll: true });
    }
  }
  function next() {
    const s = current();
    if (!(exhibition && $("status").textContent !== "MATCH OVER")) {
      exhibition = false;
      if (s.o[1] === ".arena") {
        const name = [
          "The Gatekeeper",
          "Trucker Mark Taylor",
          "Harvey Falco",
          "Al Straya",
          "Simon Temple",
        ][s.o[2]];
        if (
          window.APW_OPPONENT !== name ||
          $("status").textContent === "MATCH OVER"
        )
          document.querySelector('[data-floor="' + s.o[2] + '"]')?.click();
      }
    }
    navigate("match");
    window.dispatchEvent(new Event("apw:career-start"));
  }
  APW_PATH.continue = next;
  $("apwCareerContinue").onclick = next;
  window.APW_JOURNEY = {
    view: (id) => navigate(id),
    refresh: render,
    current: () => view,
  };
  window.addEventListener("apw:path-refresh", () => {
    if (scheduled) return;
    scheduled = true;
    queueMicrotask(() => {
      scheduled = false;
      render();
    });
  });
  window.addEventListener("apw:career-changed", () => {
    exhibition = false;
    navigate("career");
  });
  $("towerMatches")
    ?.closest("section")
    ?.addEventListener("click", (e) => {
      const b = e.target.closest("button[data-floor]");
      if (!b || b.disabled) return;
      if (Number(b.dataset.floor) < 5) exhibition = true;
      navigate("match");
    });
  window.addEventListener("popstate", () => {
    const id = location.hash.replace("#apw-screen-", "");
    navigate(screens[id] ? id : "home", { record: false });
  });
  window.addEventListener("load", () => {
    render();
    const id = location.hash.replace("#apw-screen-", "");
    if (screens[id]) navigate(id, { record: false, scroll: false });
  });
  render();
})();

/* ---- Module 55 ---- */

/* Consequence summary */
(() => {
  "use strict";
  const host = document.getElementById("apwCareerPath"),
    box = document.createElement("details");
  box.id = "apw69Consequences";
  box.open = true;
  const title = document.createElement("summary");
  title.textContent = "YOUR BACKSTAGE CONSEQUENCES";
  const list = document.createElement("ul");
  box.append(title, list);
  host.append(box);
  function refresh() {
    list.replaceChildren();
    const effects = APW_STAKES.summary();
    for (const line of effects.length
      ? effects
      : [
          "No career decisions made yet. Backstage choices unlock after Tower floor 4.",
        ]) {
      const li = document.createElement("li");
      li.textContent = line;
      list.append(li);
    }
  }
  window.addEventListener("apw:path-refresh", refresh);
  window.addEventListener("apw:career-changed", refresh);
  window.addEventListener("load", refresh);
  refresh();
})();

/* ---- Module 56 ---- */

/* Rules */
(() => {
  "use strict";
  const section = document.createElement("section");
  section.id = "apw70Rules";
  section.className = "apw68-away";
  section.inert = true;
  section.setAttribute("aria-labelledby", "apw70Title");
  section.innerHTML =
    '\n<header class="apw70-cover"><p class="apw70-kicker">PLAYER MANUAL \u00b7 v7.0</p><h2 id="apw70Title">KNOW THE RING.<br>RULE THE TOWER.</h2><p>Your field guide to APW: No Tea Party! \u2014 from your first forearm to the heavyweight championship.</p><div class="apw70-pills"><span>TURN-BASED WRESTLING</span><span>SYDNEY, AUSTRALIA</span><span>APW IS NO TEA PARTY!</span></div></header>\n<div class="apw70-tools"><label for="apw70Search">FIND A RULE</label><input id="apw70Search" type="search" placeholder="Try pin, save, Nikki, stamina\u2026" autocomplete="off"><div class="apw70-toolbuttons"><button id="apw70Expand" type="button">EXPAND ALL</button><button id="apw70Collapse" type="button">COLLAPSE ALL</button><button id="apw70Return" type="button">BACK TO CAREER \u25b6</button></div><p id="apw70SearchStatus" role="status" aria-live="polite"></p></div>\n<nav id="apw70Contents" aria-label="Manual chapters"></nav>\n<div class="apw70-alert"><strong>Know your match type.</strong> Singles, story battles and tag matches use different finish rules. Opening this manual does not pause a queued opponent turn. Your current match is kept when you switch views; reloading the page is different.</div>\n<details class="apw70-topic" id="apw70-start" open><summary>01 \u00b7 START HERE</summary><div>\n<ol><li>Open <strong>Career</strong> and choose your wrestler. All 23 selectable wrestlers can start the career. Choosing a wrestler starts a fresh career, including when you reselect the same wrestler.</li><li>Use <strong>Enter / Resume Match</strong> to face The Gatekeeper. Build momentum with strikes and grapples; defend before stamina runs low.</li><li>In singles, weaken the opponent, then use <strong>Pin</strong> or <strong>Submission</strong>. A finisher alone does not guarantee victory.</li><li>Follow <strong>Continue Career</strong>. Spend match XP in <strong>Training</strong>. Upgrades and new backstage effects apply when the next match starts.</li><li>Use browser save slots before changing careers. Keep older game files until your progress is confirmed in a new version.</li></ol>\n<p><strong>Views:</strong> Career shows your active chapter; Training contains drills/upgrades; Rankings shows the Tower and rematches; Tag Match is a separate exhibition; Extras contains locker-room encounters, career records and older help/testing panels. Rules &amp; Strategy opens this manual. Saves &amp; Backups exports progress, previews imports and restores recent checkpoints.</p>\n<p><strong>Controls:</strong> tap or click an enabled move once. Buttons lock while the opponent responds and during finishers. Disabled moves usually need more stamina, momentum or chapter progress. Continue resumes an active singles match without resetting it. Restart starts that fight again; it is not a rewind of already recorded career results.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-meters" open><summary>02 \u00b7 HP, STAMINA &amp; MOMENTUM</summary><div>\n<ul><li><strong>HP:</strong> your health. In singles, you start at 320 HP and the opponent at 380 HP. Your HP reaching zero is a loss. An opponent at zero HP still needs a successful pin or submission.</li><li><strong>SP:</strong> stamina, capped at 100. Singles starts you at 100. Most moves spend it. Normal non-winning singles actions restore 12 SP afterwards; Stamina training can increase that recovery.</li><li><strong>MOM:</strong> momentum, capped at 100. Singles starts you at 30. Most attacks and defensive moves build it; finishers spend it. It is not a second health bar.</li></ul>\n<p>The values below are <strong>starting-stat singles values</strong>. Training changes damage, SP costs, recovery and momentum gains. Resource gains are capped at 100. Opponent turns follow your actions, including failed pins and submissions.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-singles" open><summary>03 \u00b7 SINGLES MOVE REFERENCE</summary><div>\n<div class="apw70-table"><table><caption>Gatekeeper, Tower floors 1\u20134 and singles rematches</caption><thead><tr><th scope="col">Move</th><th scope="col">Base SP</th><th scope="col">Effect</th></tr></thead><tbody>\n<tr><th scope="row">Strike</th><td>5</td><td>17\u201327 damage; +17 MOM.</td></tr><tr><th scope="row">Grapple</th><td>10</td><td>25\u201339 damage; +23 MOM.</td></tr><tr><th scope="row">Defend</th><td>0</td><td>+28 SP and +6 MOM; next incoming attack is reduced to about 45% before training defence.</td></tr><tr><th scope="row">Dirty trick</th><td>9</td><td>25% chance David Hilder catches you: immediate disqualification. Otherwise 32\u201350 damage and +25 MOM.</td></tr><tr><th scope="row">Finisher</th><td>24</td><td>Requires 70 MOM and spends it; 65\u201387 damage. Still pin or submit afterwards.</td></tr><tr><th scope="row">Pin</th><td>6</td><td>Chance-based instant win; failed attempt gives +9 MOM and the opponent responds.</td></tr><tr><th scope="row">Submission</th><td>14</td><td>Chance-based instant win; weakened opponent, momentum and Technique help. Failed hold gives +8 MOM.</td></tr><tr><th scope="row">Reverse</th><td>8</td><td>+10 SP and +16 MOM; reduces the next incoming attack like Defend. It does not automatically return damage.</td></tr>\n</tbody></table></div>\n<p>The normal +12 SP recovery is <em>in addition</em> to Defend\u2019s +28 and Reverse\u2019s +10, on a non-winning action. A caught dirty trick ends the fight immediately.</p>\n<p><strong>Enemy rhythm:</strong> the opponent attacks, recovers when low on stamina, and can use a signature when momentum and stamina are high. Defend or Reverse before a likely finisher. Reading this guide does not stop a turn already queued.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-finishes"><summary>04 \u00b7 PINS, SUBMISSIONS &amp; FINISHERS</summary><div>\n<p><strong>Pin chance:</strong> roughly 4% against a fresh singles opponent, rising as HP falls. At zero HP it reaches 95%, so a kick-out is still possible. Pin attempts can win early, but repeated early failures give the opponent turns.</p>\n<p><strong>Submission chance:</strong> starts with a 4% base, adds up to 72 percentage points from opponent damage, up to 14 from your current momentum, and up to 5 from Technique training. Final chance caps at 91%. The hold is resolved immediately; there is no button-mashing escape meter.</p>\n<p><strong>A finisher is a powerful attack, not a guaranteed win.</strong> It needs both SP and MOM. Its animation does not change the damage calculation. In story battles, zero enemy HP resolves the finish automatically; in singles, choose Pin or Submission.</p>\n<details><summary>Singles roster finishing moves</summary><div class="apw70-table"><table><thead><tr><th>Wrestler</th><th>Singles finisher</th></tr></thead><tbody>\n<tr><td>Gideon Hark</td><td>Ripcord Clothesline</td></tr><tr><td>Simon Temple</td><td>Choke Slam</td></tr><tr><td>Birdman Phil Picasso</td><td>Double Underhook DDT</td></tr><tr><td>Bruza The Serb</td><td>Russian Leg Sweep</td></tr><tr><td>Nikki Poteet</td><td>Running Cannonball</td></tr><tr><td>Johnny Putrid</td><td>The Stroke</td></tr><tr><td>Nightmare Cat</td><td>The Cat Splash</td></tr><tr><td>TNT</td><td>The Unprettier</td></tr><tr><td>Whiskey Sixx</td><td>450 Splash</td></tr><tr><td>Mauler Y</td><td>Running Splash</td></tr><tr><td>Al Straya</td><td>44 Gallon Drum</td></tr><tr><td>Trucker Mark Taylor</td><td>The Final Cut</td></tr><tr><td>Taras Jones</td><td>Rear Naked Choke</td></tr><tr><td>Harvey Falco</td><td>Falcon Punch</td></tr><tr><td>Doomslayer</td><td>Map of Tassie</td></tr><tr><td>Drako Savage</td><td>Finger Poke of Doom</td></tr><tr><td>Trashbag Dan</td><td>The Oil Check</td></tr><tr><td>Eli Driftwood</td><td>Five Star Frog Splash</td></tr><tr><td>Evangeline Strange</td><td>Running Neckbreaker</td></tr><tr><td>Hotshot Hansel</td><td>Power Slam</td></tr><tr><td>Jay Payne</td><td>Guitar Smash</td></tr><tr><td>Black Diamond</td><td>Black Diamond Strike</td></tr><tr><td>The Outlaw</td><td>Outlaw Finisher</td></tr>\n</tbody></table></div></details>\n</div></details>\n<details class="apw70-topic" id="apw70-training"><summary>05 \u00b7 TRAINING, XP &amp; MATCH-START BONUSES</summary><div>\n<p>Win a career match for <strong>100 base XP</strong>; lose for <strong>40</strong>. Charisma can increase match XP by up to 10%. A drill grants <strong>10 XP</strong> once between completed matches; reloading does not reset the drill limit. Spend <strong>50 XP for +5</strong> in a chosen stat, up to 100.</p>\n<div class="apw70-table"><table><thead><tr><th>Stat</th><th>Benefit from 50 to 100</th></tr></thead><tbody>\n<tr><td>Strength</td><td>Up to +15% attack damage.</td></tr><tr><td>Stamina</td><td>Up to +5 SP added to recovery gains.</td></tr><tr><td>Speed</td><td>Up to 2 less SP per move; never below zero.</td></tr><tr><td>Technique</td><td>Up to +5% damage and +5 percentage points to singles submissions.</td></tr><tr><td>Durability</td><td>Up to 20% less incoming damage.</td></tr><tr><td>Charisma</td><td>Up to +5 MOM per gain and +10% match XP.</td></tr>\n</tbody></table></div>\n<p>Starting stats are 50 and preserve the original balance. Strength and Technique combine for at most +20% damage. Recovery and momentum bonuses increase by whole points per 10 stat points above 50; Speed reduces costs by one point at 75 and two at 100. Damage/XP are rounded, so not every +5 upgrade changes every small attack immediately.</p>\n<p><strong>Bonuses lock in at the starting bell.</strong> An upgrade bought during a fight applies on its next start, not halfway through. Story battles use the same rules where those resources exist. An older saved story fight without a snapshot uses baseline bonuses until restarted. Title-entrance restarts reuse their starting momentum and proof; they do not bank resources from the abandoned attempt. Tag exhibition combat does not use career stat upgrades or grant career match XP.</p>\n<p>Weigh-in shows your recorded career weight. This version has no active weight-loss management or automatic firing from a weigh-in.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-career"><summary>06 \u00b7 YOUR ROAD TO BRUZA</summary><div>\n<ol><li><strong>Qualifier:</strong> defeat The Gatekeeper.</li><li><strong>Tower floor 1:</strong> Trucker Mark Taylor.</li><li><strong>Floor 2:</strong> Harvey Falco.</li><li><strong>Floor 3:</strong> Al Straya.</li><li><strong>Floor 4:</strong> Simon Temple.</li><li><strong>Backstage:</strong> make the four story decisions.</li><li><strong>Floor 5:</strong> defeat Birdman in the grudge match, then select Reveal next chapter.</li><li><strong>Eliminator:</strong> beat Bruza in the non-title fight.</li><li><strong>Steel cage:</strong> defeat Birdman to secure your title opportunity.</li><li><strong>Floor 6:</strong> win the heavyweight main event against Bruza.</li><li><strong>Champion:</strong> continue the existing defence storyline. Losing a defence leads to a real comeback match; you must win to regain the belt.</li></ol>\n<p><strong>Continue Career follows saved progress.</strong> Only the active chapter appears in Career. Rankings can launch earlier singles rematches; winning one returns you to your current story stage. Final-floor buttons lead into the story route rather than a separate shortcut title fight. Losses leave rematch/replay choices; they do not qualify as a win.</p>\n<p>The existing narrative choices still matter: Birdman is the saboteur, Evangeline the authority behind the conspiracy, Bruza the champion, and Nikki his ally. Older saves may resume a later earned chapter without replaying the earlier route. Selecting a Tower opponent as your wrestler can produce a mirror match.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-story"><summary>07 \u00b7 STORY MATCHES HAVE THEIR OWN RULES</summary><div>\n<div class="apw70-table"><table><caption>Starting values before training/politics bonuses</caption><thead><tr><th>Match</th><th>HP: you / rival</th><th>Finisher</th><th>Finish condition</th></tr></thead><tbody>\n<tr><td>Birdman grudge</td><td>100 / 100</td><td>60 MOM; 39 damage</td><td>Enemy HP zero automatically resolves the win.</td></tr><tr><td>Bruza eliminator</td><td>100 / 125</td><td>60 MOM; 43 damage</td><td>Enemy HP zero; non-title victory.</td></tr><tr><td>Steel cage</td><td>110 / 145</td><td>55 base SP; 53 damage</td><td>Enemy HP zero or escape reaches 100%.</td></tr><tr><td>Heavyweight main event</td><td>125 / 175</td><td>50 base SP + 50 MOM; 64 damage</td><td>Enemy HP zero wins the championship.</td></tr><tr><td>Title defence / comeback</td><td>130 / 125; Birdman has 150</td><td>50 base SP + 50 MOM; 65 damage</td><td>Enemy HP zero retains or regains the title.</td></tr>\n</tbody></table></div>\n<p>Story attack damage and counters follow turn patterns rather than the singles damage ranges. Guard can restore <strong>HP as well as resources</strong>. Strike builds stamina in cage/main-event/defence fights. Main-event grapples cost 9 base SP; defence grapples cost 12. Speed reduces these costs. The cage has no momentum requirement for its finisher. Do not apply the singles 70-MOM finisher rule to these fights.</p>\n<p>Interference is scripted into particular turns. Existing allies, warning evidence and the main event\u2019s <strong>Expose Nikki</strong> action can help. Expose Nikki uses available proof and takes a turn; it is not a free attack. Guard is useful while building resources, but the opponent still gets a counter.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-cage"><summary>08 \u00b7 STEEL CAGE: ESCAPE OR FIGHT</summary><div>\n<p>Climb costs <strong>20 base SP</strong>, reduced by Speed. Each attempt adds 17% escape at 110+ rival HP, 27% below 110, or 40% below 65. If Birdman still has more than 50 HP, he drags you down by 14% and adds 5 counter damage. If your climb reaches 100%, you escape immediately.</p>\n<p>Damaging Birdman reduces your own accumulated climb by 8%. Choose your moment: weaken him first, recover stamina, then commit to escape. Birdman adds 30% to his escape on every fourth counter turn. If his escape reaches 100%, you lose. His accumulated escape is not reduced by your ordinary attacks in this version, so watch the meter.</p>\n<p>You can also reduce his HP to zero for an automatic pinfall finish. Running out of HP loses the match. Abandon / restart resets the cage fight\u2019s resources and escape meters; it does not erase the earlier career.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-politics"><summary>09 \u00b7 BACKSTAGE CHOICES &amp; THEIR PRICE</summary><div>\n<p>Choice buttons show their tradeoffs before you commit. The hub lists your current consequences. New effects apply to <strong>the five narrative battle types</strong>, not ordinary singles or tag exhibitions. Damage adjustments below are before Durability training; resource gains cap at 100.</p>\n<div class="apw70-table"><table><thead><tr><th>Choice</th><th>Consequence</th></tr></thead><tbody>\n<tr><td>Furious promo</td><td>+10 starting MOM; +2 damage on every third rival counter.</td></tr><tr><td>Public challenge</td><td>+5 starting MOM.</td></tr><tr><td>Calm focus</td><td>+8 starting SP where available; 3 less opening damage.</td></tr><tr><td>Doomslayer</td><td>4 less opening damage, plus existing ally protection.</td></tr><tr><td>Taras Jones</td><td>Evidence support and one warning contribution to the referee.</td></tr><tr><td>Independent</td><td>+10 starting MOM; no ally support from the new politics effects.</td></tr><tr><td>Question the photograph</td><td>One evidence warning contribution.</td></tr><tr><td>Evangeline\u2019s protection</td><td>+15 starting SP, or +8 MOM in a battle without SP; an opening cheap shot adds 8 damage each match.</td></tr><tr><td>Refuse the office</td><td>+10 starting MOM; opening retaliation adds 3 damage.</td></tr><tr><td>Respect Bruza</td><td>3 less opening damage in the eliminator, main event and championship defences.</td></tr><tr><td>Accuse the office</td><td>+10 starting MOM; Nikki\u2019s interference adds another 4 damage.</td></tr><tr><td>Ask Bruza about Birdman</td><td>One extra warning contribution.</td></tr>\n</tbody></table></div>\n<p><strong>Referee warnings:</strong> capped at two per match. A warning cancels the extra interference damage on an identified cheating incident, not the whole normal attack. Spent warnings stay spent when you reload that saved match. The main event also has its existing proof / Expose Nikki action.</p>\n<p><strong>Locker-room encounters in Extras:</strong> Trucker Mark Taylor can add 10 starting SP and stop one interference; three evidence clips contribute a warning. High Trashbag Police heat (40+) adds the third-counter retaliation, but does not double that same promo retaliation. The original limited encounter actions are replenished by the existing singles post-match system.</p>\n<p><strong>Snapshots:</strong> decisions, warnings and the office debt are saved with a narrative fight at its start. Changing a decision later does not rewrite that active match. A fresh match resets its resources and warnings; restarting does not repeatedly add Taras evidence. Older active fights without a politics snapshot retain their earlier behaviour until restarted.</p>\n<p>You can replay the backstage story to try another route, but it does not rewind results or erase all later matches. A fresh wrestler selection resets that career\u2019s story. Use save slots if you want to keep different routes.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-tag"><summary>10 \u00b7 TAG TEAM CHAMPIONSHIP</summary><div>\n<p>You control <strong>The Hark Foundation: Gideon Hark and Simon Temple</strong>, against <strong>The Outer Realm: Whiskey Sixx and Mauler Y</strong>. TNT is part of the Outer Realm storyline but is not one of the four controlled wrestlers in this exhibition.</p>\n<p>Each wrestler has <strong>260 HP</strong>. Your team starts at <strong>20 MOM</strong>. A tag takes your turn and gives +12 MOM; the enemy then responds. Partners keep their own HP, and being on the apron does not heal them in this version.</p>\n<div class="apw70-table"><table><thead><tr><th>Action</th><th>Tag effect</th></tr></thead><tbody>\n<tr><td>Strike</td><td>15\u201327 damage; +18 MOM.</td></tr><tr><td>Grapple</td><td>24\u201337 damage; +24 MOM.</td></tr><tr><td>Tag</td><td>Switch active partner; +12 MOM.</td></tr><tr><td>Double team</td><td>Costs 60 MOM; 68\u201390 damage (+12 with a partner already in); opens an illegal-partner window.</td></tr><tr><td>Special</td><td>Costs 85 MOM. Gideon: 75\u201395 damage; Simon: 84\u2013104.</td></tr><tr><td>Pin</td><td>Chance rises as rival HP falls; a failed attempt gives +8 MOM.</td></tr>\n</tbody></table></div>\n<p>With your partner outside, a successful pin wins immediately. Reducing the active enemy to zero HP wins by knockout; your active wrestler reaching zero loses the match, even if a partner still has HP. Tag early rather than expecting an automatic rescue.</p>\n<p>The Outer Realm gains 24 MOM on its turn and can unleash a special at 85. Whiskey\u2019s 450 Splash deals 72\u201392 damage; Mauler\u2019s Running Splash deals 78\u201398. They may tag a healthier partner. The exhibition has its own momentum and victory sequence; it does not advance the singles career or award its XP.</p>\n<h4>PLAY THE FIVE-COUNT</h4><p>The five-count is <strong>turn-based, not five real seconds</strong>. Partner In costs 20 MOM and starts your illegal partner at count 1. With them in, strikes gain +8 damage, grapples +10, and double teams +12. Your following counted actions advance the count. At 4, send them out: another counted action reaches 5 and you lose by disqualification, even if that attack would knock out the rival.</p><p><strong>Partner Out</strong> takes your turn and clears the count; the opponent still responds. You cannot tag or pin while your illegal partner remains in. A normal Double Team still costs 60 MOM and deals its original damage, but now leaves the partner in at count 1. A finisher can end the match inside the legal window; staying in for a fifth counted action is a DQ.</p><h4>DISTRACTIONS</h4><ul><li><strong>Distract Rival \u2014 15 MOM:</strong> your apron partner reduces the next enemy hit by 40%. It does not stack and remains ready if the rival tags instead of hitting. Available only while your partner is outside.</li><li><strong>Distract Ref \u2014 20 MOM:</strong> while your illegal partner is in, hold the count for your next counted action. Only once per illegal entry. It takes a turn, and the rival still responds.</li></ul><p>The Outer Realm can also send an illegal partner in. Watch its own count: assistance adds 8 damage to its hits, and it normally spends a turn sending the partner out before count 5. Use that opening to build momentum or tag a hurt wrestler. Neither team\u2019s five-count is a timer you must race with fast taps.</p><p><strong>Example:</strong> Partner In (count 1) \u2192 Strike (2) \u2192 Grapple (3) \u2192 Double Team (4, if you have 60 MOM) \u2192 Partner Out. Alternatively, spend 20 MOM on a referee distraction to buy one extra counted action. Check HP: every setup action gives the rival a turn.</p><h4>COMBOS &amp; PARTNER COVER</h4><p>Plan Double Team costs 20 MOM and adds one setup level (maximum 2); Corner Isolation also adds one. Your next Double Team consumes the setup for +12 damage per level. Partner Cover costs 30 MOM and arms one rescue per match: it breaks the next attempted rival pin, or reduces the next incoming hit by 40%, whichever happens first. Ordinary tags do not refresh your rescue. Outer Realm can break up your covers and can counter a hot tag on its following turn. Watch HP: partner cover does not guarantee survival.</p><h4>ISOLATION &amp; HOT TAGS</h4><p>Outer Realm can build your isolation up to 4. Ordinary tags can be denied (19% per isolation level). Grapple or Fight Free reduces isolation by 1; Fight Free also gives 12 MOM. At isolation 2+, Hot Tag switches partner, clears isolation, deals 24 damage and gives 22 MOM. Send an illegal partner out before a hot tag.</p><p>Corner Isolation costs 15 MOM, builds rival pressure up to 3 and deals 12 plus 4 damage per pressure level. Each pressure level reduces the rival\u2019s usual tag probability by 20% (up to 60% at level 3); a successful rival tag clears it. The separate Tactical Tag mode uses its own stamina, HP and move rules.</p></div></details>\n<details class="apw70-topic" id="apw70-saves"><summary>11 \u00b7 SAVES, RELOADS &amp; TRANSFERS</summary><div>\n<ul><li><strong>Autosave:</strong> career identity, progression, upgrades and story decisions save in the browser. Story fights save their action state, including politics snapshots.</li><li><strong>Live singles/tag fights:</strong> HP and turn state are not restored by reloading. Their current fight restarts. Switching in-game views keeps the live match in memory.</li><li><strong>Three slots:</strong> open the game menu / launcher, then its save-slot panel. Saves &amp; Backups also offers three recent recovery checkpoints and a before-import checkpoint. Save before starting another wrestler. Overwriting a slot requires confirmation.</li><li><strong>Load:</strong> replaces current APW progress and reloads the page. Slots are checked before loading; if a write fails the game attempts to restore the previous values.</li><li><strong>Browser storage:</strong> private mode, clearing browser data, storage restrictions or a different browser/location can affect saves. A new local filename may have different save access.</li><li><strong>ZIP transfer:</strong> contains the game, not your browser progress. Moving the HTML from laptop to phone does not transfer your save slots. Open Saves &amp; Backups to download a JSON backup and import it on the other device. Game files and transfer ZIPs still do not carry your browser progress by themselves.</li></ul>\n<p>If a save warning appears, keep the page open and resolve the browser storage problem before relying on progress being retained. Keep your previous build until the new file\u2019s progress is confirmed. Training drills and spent story warnings do not refresh simply by reopening a saved career.</p>\n</div></details>\n<details class="apw70-topic" id="apw70-tactics"><summary>12 \u00b7 STRATEGY &amp; TROUBLESHOOTING</summary><div>\n<ul><li><strong>Low SP?</strong> Defend or Reverse in singles. In story matches, use the named guard/recover action. Do not assume tag combat has stamina.</li><li><strong>Finisher greyed out?</strong> Check that mode\u2019s SP and MOM thresholds. Also wait for the opponent turn to finish.</li><li><strong>Enemy on zero HP but no win?</strong> In singles, press Pin or Submission. A kick-out is possible even at zero.</li><li><strong>Story locked?</strong> Use Continue Career and finish the previous required win. Birdman\u2019s showdown also needs Reveal next chapter after the victory.</li><li><strong>Upgrade seems inactive?</strong> It applies at the next starting bell. Small bonuses may round to the same damage on a particular attack.</li><li><strong>Lost the title?</strong> Follow the comeback objective. You have to win the rematch; selecting comeback does not award the belt.</li><li><strong>Match still acted while reading?</strong> Opening Rules does not pause the queued turn. Finish the exchange, then read. Your next action waits for you.</li><li><strong>Artwork &amp; venues?</strong> Use the venue selector for singles and Art &amp; Extras for galleries/cinematics. Those choices do not raise combat stats.</li><li><strong>Sound / motion?</strong> The menu has arcade sound and motion options. Effects and animation support can vary by browser; the motion option is not a guarantee that every animation stops.</li></ul>\n<p class="apw70-motto">APW IS NO TEA PARTY!</p>\n</div></details>\n';
  document.getElementById("apw68stage").append(section);
  const css = document.createElement("style");
  css.textContent =
    "\n#apw70Rules{max-width:960px;margin:16px auto;padding:clamp(12px,3vw,28px);color:#f1f3ff;background:#100d29;border:2px solid #37e9ff;border-radius:14px;box-shadow:0 0 24px #13b9db33;font-family:system-ui,sans-serif;line-height:1.65;text-align:left}#apw70Rules *{box-sizing:border-box}#apw70Rules .apw70-cover{padding:24px clamp(12px,3vw,28px);border:1px solid #ff59c8;background:linear-gradient(145deg,#331443,#11122c);border-radius:10px}.apw70-kicker{font:bold 12px monospace;letter-spacing:3px;color:#54ecff}#apw70Title{font:900 clamp(27px,6vw,52px)/1.1 system-ui,sans-serif;color:#fff0fa;letter-spacing:-1px;text-shadow:3px 3px #a21d86,0 0 16px #f152b577;margin:15px 0}.apw70-pills{display:flex;flex-wrap:wrap;gap:8px;font:bold 10px monospace;letter-spacing:1px}.apw70-pills span{border:1px solid #ffd568;padding:5px 8px;color:#ffe394;border-radius:3px}.apw70-tools{padding:20px 0}.apw70-tools label{display:block;font:bold 12px monospace;letter-spacing:2px;color:#60efff}#apw70Search{width:100%;padding:13px;margin:7px 0 12px;background:#080d21;border:1px solid #62eaff;border-radius:5px;color:#fff;font-size:16px}#apw70Search::placeholder{color:#b1b9d4}#apw70Rules button,#apw70Contents button{min-height:44px;padding:9px 13px;background:#23143d;color:#fff;border:1px solid #f762ca;border-radius:5px;font-weight:700;cursor:pointer}#apw70Rules button:focus-visible,#apw70Rules summary:focus-visible,#apw70Search:focus-visible{outline:3px solid #ffe18c;outline-offset:3px}.apw70-toolbuttons,#apw70Contents{display:flex;flex-wrap:wrap;gap:8px}#apw70Contents{padding-bottom:20px}#apw70Contents button{border-color:#48cadd;font-size:12px;background:#10263b}.apw70-alert{padding:14px;border-left:4px solid #ffcf66;background:#30243a;margin-bottom:18px}.apw70-topic{border:1px solid #5f527b;border-radius:8px;margin:10px 0;background:#15142f}.apw70-topic>summary{padding:16px;color:#66ecff;cursor:pointer;font:800 14px/1.5 monospace;letter-spacing:1px}.apw70-topic[open]>summary{border-bottom:1px solid #675078;color:#ff99db}.apw70-topic>div{padding:5px 18px 18px}.apw70-topic p,.apw70-topic li{font-size:14px}.apw70-topic li{margin:7px 0}.apw70-topic strong{color:#ffe39a}.apw70-table{overflow-x:auto;max-width:100%;margin:14px 0}.apw70-table table{width:100%;border-collapse:collapse;min-width:420px;font-size:13px;color:#edf0ff}.apw70-table th,.apw70-table td{padding:11px;text-align:left;border:1px solid #55486e;vertical-align:top}.apw70-table thead{background:#2e2045;color:#ffbcdf}.apw70-table tbody tr:nth-child(even){background:#1e1d39}.apw70-table caption{text-align:left;color:#69efff;padding-bottom:9px}#apw70Rules [hidden]{display:none!important}#apw70SearchStatus{font-size:12px;color:#d7cde8}.apw70-motto{font:bold 20px monospace;color:#ff86d1;text-align:center;text-shadow:0 0 12px #ed4da8}@media(max-width:480px){#apw70Rules{border-radius:8px;margin:12px 4px}.apw70-topic>div{padding:4px 11px 14px}.apw70-topic>summary{padding:13px 11px}.apw70-toolbuttons button{flex:1 1 120px}}\n";
  document.head.append(css);
  const topics = [...section.querySelectorAll(".apw70-topic")],
    search = section.querySelector("#apw70Search"),
    status = section.querySelector("#apw70SearchStatus"),
    contents = section.querySelector("#apw70Contents");
  const initial = new Map(topics.map((t) => [t, t.open]));
  for (const topic of topics) {
    let b = document.createElement("button");
    b.type = "button";
    b.textContent = topic.querySelector("summary").textContent;
    b.setAttribute("aria-controls", topic.id);
    b.onclick = () => {
      search.value = "";
      filter();
      topic.open = true;
      topic.scrollIntoView({ behavior: "smooth", block: "start" });
      topic.querySelector("summary").focus();
    };
    contents.append(b);
  }
  function filter() {
    const q = search.value.trim().toLowerCase();
    let count = 0;
    for (const t of topics) {
      const match = !q || t.textContent.toLowerCase().includes(q);
      t.hidden = !match;
      if (q) t.open = match;
      else t.open = initial.get(t);
      if (match) count++;
    }
    status.textContent = q
      ? count
        ? count + " chapter" + (count === 1 ? "" : "s") + " match your search."
        : "No matching rules. Try another word."
      : "12 chapters · Search or choose a topic.";
  }
  search.addEventListener("input", filter);
  section.querySelector("#apw70Expand").onclick = () => {
    topics
      .filter((t) => !t.hidden)
      .forEach((t) => {
        t.open = true;
        t.querySelectorAll("details").forEach((x) => (x.open = true));
      });
  };
  section.querySelector("#apw70Collapse").onclick = () => {
    topics.forEach((t) => {
      t.open = false;
      t.querySelectorAll("details").forEach((x) => (x.open = false));
    });
  };
  section.querySelector("#apw70Return").onclick = () => {
    APW_JOURNEY.view("career");
    document
      .getElementById("apwCareerPath")
      .scrollIntoView({ behavior: "smooth", block: "start" });
  };
  filter();
})();

/* ---- Module 57 ---- */

/* Save Vault */
/* v7.1: portable gameplay saves, bounded recovery checkpoints and journaled imports. */
(() => {
  "use strict";
  const KEYS = APW_SAVE_KEYS,
    REC = "apw71_recovery",
    PRE = "apw71_before_import",
    JOURNAL = "apw71_journal",
    MAX = 2000000;
  let queued = false,
    busy = false,
    pending = null,
    beforeBuffer = null,
    deferred = false,
    fileRequest = 0;
  const volatile = {};
  const names = [...document.querySelectorAll("#careerWrestler option")].map(
      (o) => o.value,
    ),
    gameKeys = KEYS.filter((k) => !k.startsWith("apw43_slot_"));
  const page = document.createElement("section");
  page.id = "apw71Saves";
  page.className = "apw68-away";
  page.inert = true;
  page.innerHTML = `<h2>SAVE VAULT · KEEP YOUR CAREER</h2><p>Download a portable backup before changing device or replacing your game file. Recent checkpoints stay in this browser.</p><div class="apw71buttons"><button id="apw71Export">DOWNLOAD BACKUP ↓</button><button id="apw71Checkpoint">CREATE CHECKPOINT</button></div><p id="apw71Status" role="status" aria-live="polite"></p><h3>IMPORT A BACKUP</h3><label for="apw71File">Choose an APW JSON backup</label><input id="apw71File" type="file" accept=".json,application/json"><p id="apw71Preview">A file is checked and previewed before it can replace progress.</p><button id="apw71Apply" disabled>IMPORT REVIEWED BACKUP</button><button id="apw71UndoDownload" hidden>DOWNLOAD BEFORE-IMPORT BACKUP</button><h3>RECENT RECOVERY CHECKPOINTS</h3><div id="apw71Checkpoints"></div><h3>WHAT IS PROTECTED?</h3><ul><li>Career, XP, training, story match state, choices, politics snapshots and your three browser save slots.</li><li>Up to three recent checkpoints, plus a separate before-import checkpoint. These share browser storage; downloaded files are the independent copies.</li><li>Live singles and tag HP/turns restart after reload. Portrait uploads, game artwork and the game HTML are not included in a save backup.</li><li>Imports reload the game after restoring checked values. Your artwork and unrelated browser data are kept.</li></ul><p>Checksums detect accidental file damage; they are not a security signature. Clearing browser data also clears local checkpoints. Keep downloaded backups somewhere safe.</p>`;
  document.getElementById("apw68stage").append(page);
  const css = document.createElement("style");
  css.textContent =
    "#apw71Saves{max-width:960px;margin:16px auto;padding:22px;background:linear-gradient(145deg,#16132e,#241334);border:2px solid #4ae8ff;border-radius:12px;color:#f4eeff;box-shadow:0 0 20px #1ed7f333;line-height:1.6}#apw71Saves h2,#apw71Saves h3{color:#ff9edc}#apw71Saves button{min-height:44px;padding:10px 14px;border:1px solid #f76cc6;border-radius:6px;background:#251b42;color:#fff;font-weight:bold;margin:5px 6px 5px 0;cursor:pointer}#apw71Saves button:disabled{opacity:.45;cursor:default}#apw71Saves button:focus-visible,#apw71File:focus-visible{outline:3px solid #ffe184;outline-offset:3px}#apw71File{display:block;max-width:100%;margin:12px 0;font-size:16px}#apw71Status,#apw71Preview{white-space:pre-wrap}#apw71Checkpoints>div{padding:12px 0;border-top:1px solid #6a4a80}.apw71buttons{display:flex;flex-wrap:wrap}";
  document.head.append(css);
  const $ = (id) => document.getElementById(id),
    say = (text) => {
      $("apw71Status").textContent = text;
    };
  function plain(v) {
    return !!v && typeof v === "object" && !Array.isArray(v);
  }
  function safe(v, depth = 0) {
    if (depth > 25) throw Error("Save data is too deeply nested.");
    if (typeof v === "number" && !Number.isFinite(v))
      throw Error("Invalid number in save.");
    if (v && typeof v === "object") {
      for (const [k, x] of Object.entries(v)) {
        if (["__proto__", "constructor", "prototype"].includes(k))
          throw Error("Unsafe save field.");
        safe(x, depth + 1);
      }
    }
  }
  function hash(data) {
    const canonical = JSON.stringify(
      Object.keys(data)
        .sort()
        .map((k) => [k, data[k]]),
    );
    let h = 2166136261;
    for (let i = 0; i < canonical.length; i++) {
      h ^= canonical.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(16).padStart(8, "0");
  }
  function object(raw) {
    let x;
    try {
      x = JSON.parse(raw);
    } catch (e) {
      throw Error("A saved record is not valid JSON.");
    }
    safe(x);
    return x;
  }
  function rosterName(n) {
    if (!names.includes(n)) throw Error("Unknown wrestler in save.");
  }
  function numeric(x, k, min, max) {
    if (
      k in x &&
      (!Number.isFinite(x[k]) ||
        x[k] < min ||
        x[k] > max ||
        !Number.isInteger(x[k]))
    )
      throw Error("Invalid " + k + " value.");
  }
  function validateData(data, allowSlots = true, requireCareer = true) {
    if (!plain(data) || Object.keys(data).length > KEYS.length)
      throw Error("Invalid save records.");
    if (requireCareer && !data.apwCareer08)
      throw Error("Backup is missing its career identity.");
    for (const [k, raw] of Object.entries(data)) {
      if (!KEYS.includes(k) || typeof raw !== "string" || raw.length > MAX)
        throw Error("Unknown or invalid save record: " + k);
      if (k === "apw_selected_venue") {
        if (!["outdoor", "bexley", "yagoona", "serbian"].includes(raw))
          throw Error("Unknown venue.");
        continue;
      }
      const x = object(raw);
      if (k.startsWith("apw43_slot_")) {
        if (
          !allowSlots ||
          !plain(x) ||
          typeof x.date !== "string" ||
          !Number.isFinite(Date.parse(x.date))
        )
          throw Error("Invalid save slot.");
        validateData(x.data, false, false);
        continue;
      }
      if (k === "apw42_release_checks") {
        if (
          !Array.isArray(x) ||
          x.some((n) => !Number.isInteger(n) || n < 0 || n > 9)
        )
          throw Error("Invalid test checklist.");
        continue;
      }
      if (!plain(x)) throw Error("Invalid " + k + " record.");
      if (x.name !== undefined) rosterName(x.name);
      if (x._career !== undefined) rosterName(x._career);
      const booleanFields = {
        apwCareer08: ["qualified"],
        apwCareer09: ["seenIntro", "trainingReady"],
        apwTower12: ["champion"],
        apwShowdown28: ["guard", "finished"],
        apwConspiracy30: ["guard"],
        apwCage32: ["guard"],
        apwMainEvent33: ["ally"],
        apwChampion34: ["champion", "allies"],
        apw43_options: ["sound", "motion"],
      };
      for (const field of booleanFields[k] || [])
        if (field in x && typeof x[field] !== "boolean")
          throw Error("Invalid " + field + " flag in " + k + ".");
      if (k === "apwCareer08") {
        rosterName(x.name);
        if (
          typeof x.qualified !== "boolean" ||
          !Number.isInteger(x.wins) ||
          x.wins < 0
        )
          throw Error("Invalid career record.");
      }
      if (k === "apwCareer09") {
        rosterName(x.name);
        if (
          !Array.isArray(x.stats) ||
          x.stats.length !== 6 ||
          x.stats.some((n) => !Number.isFinite(n) || n < 0 || n > 100)
        )
          throw Error("Invalid training stats.");
        numeric(x, "xp", 0, 100000000);
        numeric(x, "matches", 0, 10000000);
        numeric(x, "losses", 0, 10000000);
        if (
          x.trainingReady !== undefined &&
          typeof x.trainingReady !== "boolean"
        )
          throw Error("Invalid training cooldown.");
      }
      if (k === "apwTower12") numeric(x, "floor", 0, 7);
      if (k === "apwStory27") {
        numeric(x, "chapter", 0, 4);
        if (
          !Array.isArray(x.allies) ||
          x.allies.some((n) => !names.includes(n)) ||
          !Array.isArray(x.decisions) ||
          x.decisions.some(
            (d) =>
              !plain(d) ||
              !Number.isInteger(d.chapter) ||
              d.chapter < 0 ||
              d.chapter > 3 ||
              !Number.isInteger(d.choice) ||
              d.choice < 0 ||
              d.choice > 2,
          )
        )
          throw Error("Invalid story choices.");
      }
      if (["apwShowdown28", "apwCage32", "apwMainEvent33"].includes(k))
        numeric(x, "phase", 0, 4);
      if (k === "apwConspiracy30") numeric(x, "stage", 0, 4);
      if (k === "apwChampion34") numeric(x, "chapter", 20, 24);
      for (const f of ["hp", "enemy", "boss", "bruza"]) numeric(x, f, 0, 10000);
      for (const f of [
        "stamina",
        "momentum",
        "climb",
        "enemyClimb",
        "heat",
        "trust",
      ])
        numeric(x, f, 0, 100);
      numeric(x, "turn", 0, 10000000);
      numeric(x, "entranceMomentum", 0, 100);
      numeric(x, "entranceProof", 0, 100);
      if (
        x.trainingStats !== undefined &&
        (!Array.isArray(x.trainingStats) ||
          x.trainingStats.length !== 6 ||
          x.trainingStats.some((n) => !Number.isFinite(n) || n < 0 || n > 100))
      )
        throw Error("Invalid match training snapshot.");
      if (x.politics !== undefined) {
        if (!plain(x.politics)) throw Error("Invalid politics snapshot.");
        numeric(x.politics, "warnings", 0, 2);
        numeric(x.politics, "usedWarnings", 0, 2);
        if ((x.politics.usedWarnings || 0) > (x.politics.warnings || 0))
          throw Error("Invalid spent warnings.");
      }
    }
    const career = data.apwCareer08 ? object(data.apwCareer08) : null;
    if (career) {
      for (const [k, raw] of Object.entries(data)) {
        if (k.startsWith("apw43_slot_") || k === "apw_selected_venue") continue;
        const x = object(raw);
        if (
          plain(x) &&
          ((x._career && x._career !== career.name) ||
            (["apwCareer09", "apwChapter13"].includes(k) &&
              x.name &&
              x.name !== career.name))
        )
          throw Error("Mixed wrestler records in backup.");
      }
    }
    return data;
  }
  function normalizeSlot(raw) {
    const slot = object(raw);
    if (!plain(slot) || !plain(slot.data))
      throw Error("Invalid existing slot.");
    const data = {};
    for (const [k, v] of Object.entries(slot.data))
      if (gameKeys.includes(k)) data[k] = v;
    return JSON.stringify({ ...slot, data });
  }
  function collect() {
    const data = {};
    for (const k of KEYS) {
      const raw = volatile[k] ?? localStorage.getItem(k);
      if (raw !== null) {
        if (
          !k.startsWith("apw43_slot_") &&
          k !== "apw_selected_venue" &&
          k !== "apwCareer08"
        ) {
          const x = object(raw);
          if (
            plain(x) &&
            ((x._career && x._career !== APW_CAREER.name) ||
              (["apwCareer09", "apwChapter13"].includes(k) &&
                x.name &&
                x.name !== APW_CAREER.name))
          )
            continue;
        }
        data[k] = k.startsWith("apw43_slot_") ? normalizeSlot(raw) : raw;
      }
    }
    data.apwCareer08 = JSON.stringify(APW_CAREER);
    validateData(data);
    return data;
  }
  function pack(data) {
    validateData(data);
    const p = {
      format: "APW_SAVE_BACKUP",
      version: 1,
      gameVersion: "12.5-debug-animation-polish",
      createdAt: new Date().toISOString(),
      checksum: hash(data),
      data,
    };
    if (new Blob([JSON.stringify(p)]).size > MAX)
      throw Error("Backup is too large (maximum 2 MB).");
    return p;
  }
  function verify(value) {
    if (
      !plain(value) ||
      value.format !== "APW_SAVE_BACKUP" ||
      value.version !== 1 ||
      typeof value.createdAt !== "string" ||
      !Number.isFinite(Date.parse(value.createdAt))
    )
      throw Error("This is not a supported APW backup.");
    safe(value);
    validateData(value.data);
    if (value.checksum !== hash(value.data))
      throw Error("Backup integrity check failed.");
    return value;
  }
  function preview(value, label) {
    const p = verify(value),
      c = object(p.data.apwCareer08),
      t = p.data.apwTower12 ? object(p.data.apwTower12) : {},
      profile = p.data.apwCareer09 ? object(p.data.apwCareer09) : {};
    pending = p;
    $("apw71Preview").textContent =
      label +
      "\nWrestler: " +
      c.name +
      " · Wins: " +
      c.wins +
      " · Tower: " +
      (t.floor || 0) +
      "/6 · XP: " +
      (profile.xp || 0) +
      "\nSaved: " +
      new Date(p.createdAt).toLocaleString() +
      "\nReady to replace current gameplay progress and the three slots. Portrait uploads are excluded.";
    $("apw71Apply").disabled = false;
  }
  function prepare(text) {
    pending = null;
    $("apw71Apply").disabled = true;
    if (typeof text !== "string" || text.length > MAX)
      throw Error("Backup is too large (maximum 2 MB).");
    const value = JSON.parse(text);
    verify(value);
    preview(value, "Checked portable backup");
    return value;
  }
  function recoveryList() {
    try {
      const x = object(localStorage.getItem(REC) || "[]");
      return Array.isArray(x)
        ? x
            .filter((p) => {
              try {
                verify(p);
                return true;
              } catch (e) {
                return false;
              }
            })
            .slice(0, 3)
        : [];
    } catch (e) {
      return [];
    }
  }
  function renderCheckpoints() {
    const host = $("apw71Checkpoints");
    host.replaceChildren();
    const items = recoveryList();
    try {
      const before = localStorage.getItem(PRE);
      if (before) {
        const p = verify(object(before));
        items.push({ ...p, label: "Before last import" });
      }
    } catch (e) {}
    if (!items.length) {
      host.textContent =
        "No recovery checkpoints yet. Create one or complete a saved action.";
      return;
    }
    for (const p of items) {
      const row = document.createElement("div"),
        text = document.createElement("p"),
        c = object(p.data.apwCareer08),
        button = document.createElement("button");
      text.textContent =
        (p.label || "Checkpoint") +
        " · " +
        c.name +
        " · " +
        new Date(p.createdAt).toLocaleString();
      button.textContent = "REVIEW RESTORE";
      button.onclick = () => {
        fileRequest++;
        preview(p, p.label || "Recovery checkpoint");
        $("apw71Preview").scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      };
      row.append(text, button);
      host.append(row);
    }
  }
  function checkpoint(label = "Autosave checkpoint", force = false) {
    if (busy || window.APW_SAVE_RECOVERY_FAILED) return;
    if (APW_TEAM_B.hasPendingResult?.()) {
      if (!force) {
        if (!deferred) {
          deferred = true;
          setTimeout(() => {
            deferred = false;
            schedule();
          }, 1000);
        }
        return;
      }
      APW_TEAM_B.settleResult();
    }
    const data = collect(),
      list = recoveryList(),
      checksum = hash(data);
    if (!force && list[0]?.checksum === checksum) return;
    const p = { ...pack(data), label };
    const raw = JSON.stringify(
      [p, ...list.filter((x) => x.checksum !== checksum)].slice(0, 3),
    );
    if (raw.length > MAX)
      throw Error("Recovery checkpoints exceed the safe size limit.");
    localStorage.setItem(REC, raw);
    renderCheckpoints();
    say(
      "Checkpoint protected: " +
        object(data.apwCareer08).name +
        " · " +
        new Date(p.createdAt).toLocaleTimeString(),
    );
  }
  function schedule() {
    if (queued || busy || window.APW_SAVE_RECOVERY_FAILED) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      try {
        checkpoint();
      } catch (e) {
        say(
          "Progress may be saved, but a recovery checkpoint could not be written: " +
            e.message +
            " Download a backup now.",
        );
      }
    });
  }
  function serialize(p) {
    verify(p);
    const text = JSON.stringify(p);
    if (new Blob([text]).size > MAX)
      throw Error("Backup is too large (maximum 2 MB).");
    return text;
  }
  function download(p) {
    const blob = new Blob([serialize(p)], { type: "application/json" }),
      url = URL.createObjectURL(blob),
      link = document.createElement("a");
    link.href = url;
    link.download =
      "APW_" +
      object(p.data.apwCareer08).name.replace(/[^a-z0-9]+/gi, "_") +
      "_" +
      new Date().toISOString().replace(/[:.]/g, "-") +
      ".json";
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  function rawBefore() {
    const out = {};
    for (const k of KEYS) out[k] = localStorage.getItem(k);
    return out;
  }
  function restore(value, { reload = true } = {}) {
    const p = verify(value);
    if (window.APW_SAVE_RECOVERY_FAILED)
      throw Error(
        "Interrupted recovery must be resolved first. Download the before-import backup and use it in a fresh browser session.",
      );
    APW_TEAM_B.settleResult();
    const before = rawBefore();
    beforeBuffer = pack(collect());
    $("apw71UndoDownload").hidden = false;
    // These writes must succeed before any gameplay record is touched.
    localStorage.setItem(PRE, JSON.stringify(beforeBuffer));
    const journal = JSON.stringify({ before });
    if (journal.length > MAX)
      throw Error("Current save is too large to protect before importing.");
    localStorage.setItem(JOURNAL, journal);
    busy = true;
    try {
      for (const [k, v] of Object.entries(p.data)) localStorage.setItem(k, v);
      for (const k of KEYS) if (!(k in p.data)) localStorage.removeItem(k);
      localStorage.removeItem(JOURNAL);
    } catch (error) {
      let rolledBack = true;
      for (const [k, v] of Object.entries(before)) {
        try {
          if (v === null) localStorage.removeItem(k);
          else localStorage.setItem(k, v);
        } catch (e) {
          rolledBack = false;
        }
      }
      if (rolledBack) {
        try {
          localStorage.removeItem(JOURNAL);
        } catch (e) {
          rolledBack = false;
        }
      }
      busy = false;
      if (!rolledBack) {
        window.APW_SAVE_RECOVERY_FAILED = true;
        throw Error(
          "Restore failed and rollback is incomplete. Keep this page open and download the before-import backup.",
        );
      }
      throw Error(
        "Restore failed; previous progress was restored. " + error.message,
      );
    }
    for (const k of Object.keys(volatile)) delete volatile[k];
    busy = false;
    say("Backup restored. Reloading the game…");
    if (reload) {
      busy = true;
      location.reload();
    }
    return true;
  }
  const originalStore = APW_TEAM_B.store;
  APW_TEAM_B.store = function (k, v) {
    if (window.APW_SAVE_RECOVERY_FAILED)
      throw Error("Save recovery is incomplete.");
    if (busy) throw Error("Restore in progress; waiting for reload.");
    if (KEYS.includes(k)) {
      try {
        const parsed = JSON.parse(v);
        if (
          plain(parsed) &&
          [
            "apwCareer09",
            "apwTower12",
            "apwChapter13",
            "apwStory27",
            "apwShowdown28",
            "apwConspiracy30",
            "apwCage32",
            "apwMainEvent33",
            "apwChampion34",
          ].includes(k)
        )
          parsed._career = APW_CAREER.name;
        volatile[k] = JSON.stringify(parsed);
      } catch (e) {
        volatile[k] = v;
      }
    }
    try {
      originalStore.call(this, k, v);
      delete volatile[k];
      if (!Object.keys(volatile).length) {
        const notice = $("apwTeamBSaveNotice");
        if (notice) {
          notice.textContent = "Progress is saving again.";
          notice.setAttribute("role", "status");
        }
      }
      if (KEYS.includes(k)) schedule();
    } catch (e) {
      schedule();
      throw e;
    }
  };
  const originalChoose = window.apwChoose;
  window.apwChoose = function (name) {
    if (!names.includes(name)) return;
    if (window.APW_SAVE_RECOVERY_FAILED || busy) {
      $("careerWrestler").value = APW_CAREER.name;
      $("apw43roster").value = APW_CAREER.name;
      say("Career change stopped while save recovery or reload is pending.");
      APW_JOURNEY.view("saves");
      return;
    }
    try {
      checkpoint("Before career selection", true);
    } catch (e) {
      $("careerWrestler").value = APW_CAREER.name;
      $("apw43roster").value = APW_CAREER.name;
      say(
        "Career change stopped because the current career could not be protected. Download a backup first. " +
          e.message,
      );
      APW_JOURNEY.view("saves");
      return;
    }
    return originalChoose(name);
  };
  $("apw71Export").onclick = () => {
    try {
      APW_TEAM_B.settleResult();
      const p = window.APW_SAVE_RECOVERY_FAILED
        ? beforeBuffer
        : pack(collect());
      if (!p) throw Error("No valid recovery buffer available.");
      download(p);
      say(
        "Backup download started. Keep the JSON file to move progress to another device.",
      );
    } catch (e) {
      say("Could not create backup: " + e.message);
    }
  };
  $("apw71Checkpoint").onclick = () => {
    try {
      checkpoint("Manual checkpoint", true);
    } catch (e) {
      say("Could not protect checkpoint: " + e.message);
    }
  };
  $("apw71UndoDownload").onclick = () => {
    try {
      if (!beforeBuffer) {
        beforeBuffer = verify(object(localStorage.getItem(PRE) || "null"));
      }
      download(beforeBuffer);
    } catch (e) {
      say("Could not download the before-import backup: " + e.message);
    }
  };
  $("apw71File").addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const request = ++fileRequest;
    pending = null;
    $("apw71Apply").disabled = true;
    try {
      if (file.size > MAX) throw Error("Backup is too large (maximum 2 MB).");
      const text =
        typeof file.text === "function"
          ? await file.text()
          : await new Promise((resolve, reject) => {
              const r = new FileReader();
              r.onload = () => resolve(r.result);
              r.onerror = () => reject(Error("Could not read backup file."));
              r.readAsText(file);
            });
      if (request !== fileRequest) return;
      prepare(text);
      say("Backup checked. Review the wrestler and progress before importing.");
    } catch (error) {
      if (request !== fileRequest) return;
      $("apw71Preview").textContent = "Import rejected: " + error.message;
      say("Current progress was not changed.");
    }
  });
  $("apw71Apply").onclick = () => {
    if (!pending) return;
    if (
      !confirm(
        "Replace current APW gameplay progress and all three save slots with the reviewed backup? A before-import checkpoint will be kept.",
      )
    )
      return;
    try {
      restore(pending);
    } catch (e) {
      say(e.message);
    }
  };
  $("apw43slotlist")?.addEventListener(
    "click",
    (e) => {
      if (e.target.closest("button")) schedule();
    },
    true,
  );
  document.addEventListener("change", schedule);
  window.addEventListener("pagehide", () => {
    try {
      checkpoint("Exit checkpoint");
    } catch (e) {}
  });
  window.APW_SAVE_VAULT = {
    collect,
    pack,
    verify,
    prepare,
    restore,
    checkpoint,
    hash,
    recoveryList,
    serialize,
  };
  if (window.APW_SAVE_RECOVERY_FAILED) {
    try {
      const j = object(localStorage.getItem(JOURNAL) || "null"),
        data = {};
      for (const [k, v] of Object.entries(j.before))
        if (v !== null && KEYS.includes(k))
          data[k] = k.startsWith("apw43_slot_") ? normalizeSlot(v) : v;
      beforeBuffer = pack(data);
      $("apw71UndoDownload").hidden = false;
    } catch (e) {}
    if (!beforeBuffer) {
      try {
        beforeBuffer = verify(object(localStorage.getItem(PRE) || "null"));
        $("apw71UndoDownload").hidden = false;
      } catch (e) {}
    }
    say(
      "Interrupted restore could not be recovered automatically. Keep this page open and download the before-import backup.",
    );
    APW_JOURNEY.view("saves");
  } else {
    renderCheckpoints();
    if (window.APW_SAVE_RECOVERED)
      say("An interrupted restore was rolled back before loading your career.");
    window.addEventListener("load", schedule);
    schedule();
  }
})();
