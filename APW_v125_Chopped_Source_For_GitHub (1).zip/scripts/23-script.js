/* Menu and slots */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id),
    menu = $("apw43menu"),
    launch = $("apw43launcher"),
    msg = $("apw43msg");
  const settingKey = "apw43_options",
    slotPrefix = "apw43_slot_";
  let opts = { sound: false, motion: false };
  try {
    opts = Object.assign(
      opts,
      JSON.parse(localStorage.getItem(settingKey) || "{}"),
    );
  } catch (e) {}
  const store = () => {
    try {
      localStorage.setItem(settingKey, JSON.stringify(opts));
    } catch (e) {}
  };
  function tone(freq = 440, duration = 0.12) {
    if (!opts.sound) return;
    try {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return;
      const ctx = new C(),
        o = ctx.createOscillator(),
        g = ctx.createGain();
      o.type = "square";
      o.frequency.setValueAtTime(freq, ctx.currentTime);
      g.gain.setValueAtTime(0.035, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      o.connect(g);
      g.connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + duration);
      o.onended = () => ctx.close();
    } catch (e) {}
  }
  function show(panel) {
    document
      .querySelectorAll(".apw43panel")
      .forEach((e) => e.classList.toggle("active", e.id === "apw43" + panel));
    tone(540, 0.07);
  }
  function enter() {
    menu.hidden = true;
    launch.hidden = false;
    try {
      tone(660, 0.16);
    } catch (e) {}
  }
  $("apw43play").addEventListener("click", enter);
  launch.addEventListener("click", () => {
    menu.hidden = false;
    launch.hidden = true;
  });
  document
    .querySelectorAll("[data-panel]")
    .forEach((b) => b.addEventListener("click", () => show(b.dataset.panel)));
  const orig = $("careerWrestler"),
    roster = $("apw43roster");
  if (orig) {
    Array.from(orig.options).forEach((o) =>
      roster.add(new Option(o.text, o.value)),
    );
    roster.value = orig.value;
    orig.addEventListener("change", () => (roster.value = orig.value));
  }
  window.addEventListener("load", () => {
    if (orig) roster.value = orig.value;
  });
  $("apw43choose").addEventListener("click", () => {
    if (orig) {
      orig.value = roster.value;
      orig.dispatchEvent(new Event("change", { bubbles: true }));
    }
    enter();
  });
  $("apw43sound").checked = !!opts.sound;
  $("apw43motion").checked = !!opts.motion;
  $("apw43sound").addEventListener("change", (e) => {
    opts.sound = e.target.checked;
    store();
    tone(760, 0.1);
  });
  $("apw43motion").addEventListener("change", (e) => {
    opts.motion = e.target.checked;
    store();
  });
  $("apw43test").addEventListener("click", () => {
    if (!opts.sound) {
      msg.textContent = "Enable arcade sound effects first.";
      return;
    }
    tone(440, 0.12);
    setTimeout(() => tone(660, 0.14), 170);
  });
  function collect() {
    const out = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (
          /^apw/i.test(k) &&
          !k.startsWith(slotPrefix) &&
          !k.startsWith("apw71_") &&
          k !== settingKey
        )
          out[k] = localStorage.getItem(k);
      }
    } catch (e) {}
    return out;
  }
  function slots() {
    const host = $("apw43slotlist");
    host.replaceChildren();
    for (let n = 1; n <= 3; n++) {
      const key = slotPrefix + n,
        box = document.createElement("div");
      box.className = "apw43slot";
      let saved = null;
      try {
        saved = JSON.parse(localStorage.getItem(key) || "null");
      } catch (e) {}
      const heading = document.createElement("strong");
      heading.textContent =
        "SLOT " +
        n +
        " — " +
        (saved ? new Date(saved.date).toLocaleString() : "EMPTY");
      box.append(heading);
      const save = document.createElement("button");
      save.textContent = "SAVE";
      save.addEventListener("click", () => {
        if (saved && !confirm("Overwrite slot " + n + "?")) return;
        try {
          localStorage.setItem(
            key,
            JSON.stringify({ date: new Date().toISOString(), data: collect() }),
          );
          msg.textContent = "Slot " + n + " saved.";
          tone(780, 0.14);
          slots();
        } catch (e) {
          msg.textContent = "Unable to save: browser storage may be full.";
        }
      });
      const load = document.createElement("button");
      load.textContent = "LOAD";
      load.disabled = !saved;
      load.addEventListener("click", () => {
        if (
          !confirm(
            "Load slot " +
              n +
              "? This replaces current APW browser progress and reloads the game.",
          )
        )
          return;
        try {
          if (
            !saved ||
            !saved.data ||
            Array.isArray(saved.data) ||
            typeof saved.data !== "object"
          )
            throw new Error("Invalid slot");
          const entries = Object.entries(saved.data);
          if (
            !entries.length ||
            entries.some(
              ([k, v]) =>
                !/^apw/i.test(k) ||
                k.startsWith(slotPrefix) ||
                k === settingKey ||
                typeof v !== "string",
            )
          )
            throw new Error("Invalid slot data");
          const before = collect();
          try {
            entries.forEach(([k, v]) => localStorage.setItem(k, v));
            Object.keys(before)
              .filter((k) => !(k in saved.data))
              .forEach((k) => localStorage.removeItem(k));
          } catch (err) {
            Object.keys(collect())
              .filter((k) => !(k in before))
              .forEach((k) => localStorage.removeItem(k));
            Object.entries(before).forEach(([k, v]) =>
              localStorage.setItem(k, v),
            );
            throw err;
          }
          location.reload();
        } catch (e) {
          msg.textContent = "Unable to load slot.";
        }
      });
      box.append(save, load);
      host.append(box);
    }
  }
  slots();
  function celebrate() {
    if (opts.motion) return;
    const el = document.createElement("div");
    el.className = "apw43champ";
    el.innerHTML = '<span class="apw43belt">🏆</span>APW CHAMPION!';
    document.body.append(el);
    setTimeout(() => el.remove(), 2600);
    tone(880, 0.25);
  }
  const observer = new MutationObserver((records) => {
    for (const rec of records) {
      for (const node of rec.addedNodes) {
        if (node.nodeType !== 1) continue;
        const t = (node.textContent || "").slice(0, 220);
        if (
          /CAREER COMPLETE — CHAMPION ENDING/.test(t) &&
          !node.closest("#apw43menu")
        ) {
          celebrate();
          return;
        }
      }
    }
  });
  const ending = $("apw42ending");
  if (ending) observer.observe(ending, { childList: true });
  window.apw43Celebrate = celebrate;
})();

/* ---- Module 26 ---- */

/* Canonical portraits */
const APW_V54_CANONICAL_ART = {
  "BIRDMAN PHIL PICASSO": APW_MEDIA[206],
  "GIDEON HARK": APW_MEDIA[207],
  "EVANGELINE STRANGE": APW_MEDIA[208],
  "BRUZA THE SERB": APW_MEDIA[209],
  "SIMON TEMPLE": APW_MEDIA[210],
};

/* ---- Module 27 ---- */

/* Story cinema */
(() => {
  "use strict";
  const scenes = [
    {
      title: "TRASHBAG POLICE — BIRDMAN'S WARNING",
      a: "BIRDMAN PHIL PICASSO",
      b: "GIDEON HARK",
      type: "birdman",
      lines: [
        "BIRDMAN: APW IS NO TEA PARTY!",
        "BIRDMAN: These tea-party Nintendo wrestlers do too many flips!",
        "The Trashbag Police cameras roll as Birdman issues his warning.",
      ],
    },
    {
      title: "THE AUTHORITY REVEALED",
      a: "EVANGELINE STRANGE",
      b: "BRUZA THE SERB",
      type: "authority",
      lines: [
        "EVANGELINE: Every contender plays by my rules.",
        "The shadows lift. Evangeline has been steering the APW Tower all along.",
        "BRUZA: The championship stays where it belongs.",
      ],
    },
    {
      title: "HEAVYWEIGHT CHAMPIONSHIP — THE FINAL BELL",
      a: "BRUZA THE SERB",
      b: "GIDEON HARK",
      type: "title",
      lines: [
        "The arena lights burn bright over the APW Heavyweight Championship.",
        "DAVID HILDER: This contest is for the championship!",
        "The bell rings. The main event is underway.",
      ],
    },
    {
      title: "THE OUTER REALM VS HARK FOUNDATION",
      a: "WHISKEY SIXX",
      b: "SIMON TEMPLE",
      type: "tag",
      lines: [
        "THE OUTER REALM: The tag belts are ours!",
        "SIMON TEMPLE: You will have to get past the Hark Foundation.",
        "The two teams collide beneath the arena lights.",
      ],
    },
  ];
  let idx = 0,
    step = 0,
    playing = false,
    timer = null;
  const reduced = matchMedia("(prefers-reduced-motion: reduce)");
  const btn = document.createElement("button");
  btn.id = "apw46launch";
  btn.textContent = "🎬 ANIMATED CINEMATICS";
  document.body.append(btn);
  const layer = document.createElement("div");
  layer.id = "apw46overlay";
  layer.setAttribute("role", "dialog");
  layer.setAttribute("aria-modal", "true");
  layer.setAttribute("aria-label", "Animated APW cinematic gallery");
  layer.innerHTML =
    '<div id="apw46panel"><div id="apw46stage"><div class="apw47-backdrop"></div><div class="apw47-floor"></div><div class="apw47-caption"><span id="apw47namea"></span><span id="apw47nameb"></span></div><img id="apw46left" alt=""><img id="apw46right" alt=""><div class="apw47-flash"></div></div><div id="apw47progress"><div id="apw47bar"></div></div><h2 id="apw46title"></h2><p id="apw46text" aria-live="polite"></p><div id="apw47actions"><button id="apw47play">▶ REPLAY</button><button id="apw47pause">Ⅱ PAUSE</button><button id="apw47skip">SKIP DIALOGUE ▶</button></div><div id="apw46controls"><button id="apw46prev">◀ PREVIOUS</button><button id="apw46close">CLOSE</button><button id="apw46next">NEXT ▶</button></div></div>';
  document.body.append(layer);
  const $ = (id) => document.getElementById(id),
    stage = $("apw46stage");
  const APW_CINEMATIC_LOCAL_IMAGES = {
    "BIRDMAN PHIL PICASSO":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAYAAADHCaiQAAAIqElEQVR42u2dTWhdRRTH510ehUDyKCmmQrPLykUbCQS/0IYuKqjZPHAVN8aNUKQkcZGFSxdZmIQgBRHUTbMSHsirgi5KQrEqpcGkQlfRTRY12izaQJd1UecxbzJz73zPOfed/yZNmnffvPOb/zln5n6EMRKJRCKRSCQSiUQikUgkEolEIpFIJBKJRCKRSCQSLDUwDfbsmfGnEMbx98MDNHErCC7usdQGME04NzWxBXNr7f2sY5lZ/AbVRCwIrp3EMWBwMaXomqfqBlb3pk6VVe8PtbNGUYPLUnNneTb6+7dXusoxYajHBXT3quDywKaAy9+nCibUVF1AhqvrYjvLs8ngcveqIMuTDyJk0E2Wqu6lAquDXDVGaJALqO5VpeYccBljbHVupgf56PBfWgfHgKsLrKoBSg0ZsotRrINzw5Uh67pqiJAL6O5VweVBXp+/nCVdr87NoNmyBOfgqsBxsDngyqCrumoCXAFZdm8O13aWZ9nS5pYWss3kJMAlqTlXSq7S3bt/gYWLpsmCLt36HEKjBQJwVSCgupeaLBIBrhK5t8aACS6laBJWwJjd256eANNJZwcsBkAMDIlSNIkAk0AB7tzZf/Y104l97bhK9qMJMIkAk2oKuM4dNJSlEjmYHIxTH32xneQ10NUcVJg2x/r8w4ulrxGvuCTAHvqs8+uJn5073Uoygc6dbrG173f6fr749hQ5OIWqHOZ7HMypOxtg1w764/bLfd8vfP1TkgnUXun2XWQnu1nXSfPNm7Nnxp/muMUUVZMlw2WMsfX5y1nqH4b0jDpFL1zfYowx9uD+DbZwfYu1137s/V9n8U2/Nez/x3pw/wZ7/oV3nv3w1Cm29O1ttvruq7RMSqkeAGTHJsCRdHPngN3cOaCNjtgSGw7eiJBqXoPFrrOzPFt62c76ezN9nbTJKUbu3EtT46W/p6vhts2cOHFzPaQFZIqGuitEKZpEgG3qcGd5NslGRugyQ4AzBMi0/oYShPoLOkVTHa4JYCxpWt6LxpCeqckiB8Oow74ujl1/IV9SC/7uQoyC0mCBAQx927Ks/nL3Qr0qFE0NxrgmJsAJOtKY9RfD7SwoHuEAfozCZIRUf0EBNqnDPmk69HlgLDej1eKqyjKJqVmEbJqyTTY4KEUHrMM+Lr40Nd4Dy2G7uFp0L/R7qkAB1qVpuQ5zyL6gXRovbPcJo1km6Zot36WTDWQOV3f1CLQGC0UNFi/jaa90e8Hll/TIuvLVrSDve+2D11E7F5WDdXUu9qMeeIO1tLnFxkaHT0wsDPc0gwNctVxKvS4W4WIU+BTdubPP2tMT2lTNGGNjo8O9n70xOpptnNDqL5oU3QMrpETZyRxyaHH3Hh4do0vPjAH+45Sq51rwoMqPW2qvdNnY6HAPQqj6K6bmw6NjbV8glxJysGUtNl06cRf7OJm/vqzulsElB3s6WXaxnEplx5k6mk8KFVjRvVVwof2ZWXSAdZB1jqsCXQZWPgY2uCgAh4CsAm0CVnwtRrhoAJdBNgUsg7ZZ24qAMcFFs0zSBZGvkW2XPa5wXZtBAhwIsryUibmZgQEuqhRtU5NDbS1iTs0oHWwS2Pb0hLeTD4+OawEXrYOrXOzjZMwdc20cbFIjuZNt3Fw3uLWqwSbds8nyybdEEODAQHVXdthA9q3ZkIE3sLtU3pmygWwLdmikxZ48foQKdgML0KGR/scG80Dbnh50ObXIJ488BnEcUIE3MEH1hSsCc5kYZWMygZ0DeBMS2LLgBe22I12sp8syqs+eCnQzN9hUUHOoDHiq50c3CWx64Bx0Cjc3CWy9QTcJbHo9efyIDY20Tiy7YoAuYsMVP8jmlYtGnWZVcGI2SlWNWajx8688Pi57AEkdrAIrfyi+1OAzeBCdq/pehBw6bTdSgBUdIO44uUBWHTOFYoy77JjyZHAF3QgF1gRuzGBhg2tyfFU5sAXdSAk2ZNBSgE45xlhuboQC6xJwyJBzjS006EYOsNAh5x5T1fvbgG64NlAhgwsJMpaxmEI2BhzStbEC6zOuUO8feq1uClkHuMg5Q1UbCb4Sg2B6EUBIuDE2WMRNFtuNlsIWrDg7U+8mxYAMGW4IAxQ53ZYbMha40XayxBq83/209/Pdn3+LtuY0uWLCFoZcUnzAmo4hxp55e6XLrr7V/9dPN364Hb4G53albS3SudkGrviemNyO8sL385MX2PnJC1agORTuKFNI/D34e2JTEMBXN3eTuvje7p4T6KGRFpu7tm0EVwX23u5eUPemiFsRapC5ILs62taxseDaxM2lnjdDzkD+/cbcZLbUzWG41FjxGDGVMm6FSQc9NNJiE7Of9P5v8rWXSgfk6mYbILKLXWu0SY11cW/Z77vGbXvvYd/3X976Q8kraIremJtUDtgGsutzrcogV4E2bZ58U7Pus4WIW9IuOsVgQ3XdkLri2HErUgw2JugqF6tAm4IN3VjliFuRYrCx3WwD2VSp4MaOWxFrsPKAc3XWmBQjbtF2snRLAQwuTu3emHErUgyybCaanGSwhewKmr82FFx+HNNVgk3csgGOMUjboLq4mYOF4txQcYt+d2Gu2ivvWZeBDZVBIMatiDkLczdWVW7O7doUcTNysMkGPpRNDRM3Q3Jt7LhZOVi8koPvR0Oou7ZuhuBa27jJ+9D8So7oKRoDXFVniwlu1hrsszAPuUSCPqHkpVKqjaDgDo6991wXpYobiNOFg6janC4k0Hnjpr0uWnWFgOk1QaYNxCDUYHGZWRU/l7hV3Z9UYJyV5GbPFF12V6FPjVF9gEF4GIvNZ7Q9ZSgeW5V1i1SzUh5k6r8DDEE2n1kXt2hNls89NnSyP2zcbFhUAva9kJwUv3lLskwiwRQBJsAkzEr6QPAXX3mu9+8/v5sf6MD//ss/sACbtvgYHu8wSFJuVYZ8nC3J3gQ+ewTydiUBrplkwIXJL5FwwiWRSCQSaP0HS9jnhBZrVEEAAAAASUVORK5CYII=",
    "BRUZA THE SERB":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAYAAADHCaiQAAAJ9klEQVR42u2de2zVVBzHv7f33jHQIWzoSACjGwJjwMQwICK6SCCKr2wBUfG5aBRREcEnqDGKT6ZCkBifiYoRH1vwGY2axT+WwdSxEXGgDJOpgMaITtlkbvOPrbXt7b09ve1pz2l/34Rwb9fb255Pv7/f75ye3gIkEolEIpFIJBKJRCKRSCQSiUQikUgkUjrFZN75woKx/UF876HffpSm3RSCK9d3O1VCZrB9yaT/jujpkaq9FIIbbhfHCKw7F4uejxWC61yi7IfUDhYRrIwuVgiuexeLnI8TBNYdZNGrakV0d1C/PELdJArVBDiQwQiRI04irHDtIPOCUlgwtl+kqlqYHVHDW7YNbwZat2ZJ2nUr123lAl/ErlMoAOsbNhNYFtnBt9tHdV8IsAeAnbjWDfCapRVYtaWeCbJoLpY2B3vpWhZZQZahb6zICDaoBqxZWhFYpR4JwOZGfap6AUEOQ4gWAWw24ZocLAHcujVLMsKksegQOVfGUK3IANePKpkHZBHGpoUAbO4Dm+FWrtsqlHvTQSYHh8S5MuVjRXS4IrtXBshCF1kywRU12tAF/5BLIff6U0BGFrC+AarKi0PhGpGOg0I0hWgSAfZItU37hKxI7cajCTCJAJNCCDiMFbTV8QTZVSIHk4Pl1E3PfOTLZ0RXIqownWxr0/JzM36mZmkF03xqAmyj9bWNKcvGjBjuywk0ZsRwPPnB14blt513GjnYD9k5zO12ZA7dgQHOtoJeXTXb8H7lS5/4cgKpdzioMrs5XSWtDt4EdVOaVEWWGS4wMBEviPwnQ3iWOkSvfK0eAHDw2/ex8rV6VD5Rp/2t7vZKV9tWt3Xw2/cxuuT8gYU5OVj1VgNqFp9O3SQ/pQGQbNsEmJM+a9qLz5r20kAHb+kLDrUQIYU8B+urTrv50E9dXmGopFkuMarOnVc+IeN66XK402JOf+IGda+wkCFa1FEhCtEkAuwkD9etWeLLQIbXaYYAB9BArPnXK4mQf4UO0ZSHQwJYljBtHouWITxTkUUOFiMPu3Ux7/wr8pRa4e8ulFGiFFjCABZ92DJT/lXdK+qsUGlysIx9YgLsQ0XKM//KcDuL8A6WIQ/rT0aR8q9QgFnysJsw7fV1YFluRgvdL76bpQ/NesisIZtlgINCtId52I2L55VP0MCqsLNxtd69ot9TJRTgdGHanIfdVtQqaL8uPBDgAIstp5BXbalPO3tEtAJLCsD6EKiHTP3iEDk4XZ7jDdlcYKnuVU80Ge5pFg6wXXfJKh+TJO4m1TbtQ1V5sWHGZeW6rQaw+tdvvN3kyfdesqicOfeKmn+lCdFq46XLx7ylhytTeAYkeUC0ORf78XNL+uclmeGaAZtTCTnYYS72u+uUybl2cKnIcgHZ71CdDVzRHvceg+BiCdW8wrX55JENrhRFllWjWTmZJ1y1ipcNrjRVdCbIPEJ1upAsG1wpQjRLuOZV6FhFCJErZmkdbOdkHqE6DHClczBL4cV7sEU2wFLe2eB3w8oKV1rArBCiDjdUgHlAlh1uqHJwmFNE6AFnAqq/AE/AJQrRhQVj+9V/duv6dtE/N8/1vkbWwbaNY27c7k7f4GoRwgrw4H6I6u6YVFADgMsEmRF2EMATQoHN1HgyKE2UsTp2v0AnAgcrO9Qsgfv1+9EJAhsA8EHQfrg5QWDDDTpBYANQd+dAe+TmpYRtr0Er3OHqDqRu1UKmStO2ceD/hHft+zzaf+1/tX2c9C6CcLAlWNNBaV0N9QyOonOt3ushexy2Y36A1TvAMKyYDWRTI/nl5LTDoazH4LQtTMeZLeiYZ2AZ4Fo2llPI3Z14d3Kp9vbC3d+kD6ceAy2retrwvqX2Vrb9z9AWGdvDIh04BZ3wE6x+uVfhWg87HfBsZQbqNiw7bg9T2M6m/6w4AZu2gHJwMJZ/d1u4SJBzWdrDUMjp28TUzk4ubCiegdVVt6whUlTInlx+dACXuU2yAK1k1eXx4EBEhRwkXCY3W9QtmSCz94OtwGbhWj8gV67b6hiU4TMedeHcFnu2buY20OHyDOXRGG7c6LrrxnmAJaObPQXsoWu5SgfJDrLIcL0wgCKK24KALAtcN2LuB+97607tdWvjLn7h1MuG1vUj1e2nTNLjAXZw7N38WyJeaMVC49NPN3zYwCEHy6Z0bo7AeHh0HsoxCFNzVEQudkTrqSu5eais+TBSV7LosToSKZt8ToCj6mDD8FduHoovWKu9nTZ7KvdiKEyFnVeqb+4wVtCf77LmJZqDw/ycwqCPjUI0FVkkAkwiwCQCTAojYC4XGXxSWdXTma/PDh5TkJW0XA42TZkl2UvaJ59N2/YCjuxpB2IxxIcNxYFX3sGf25uxd08Ddra2IRYDjj1mGB54ZBMad7Tgmy8/QOmM87TP69/fe9eNmFo6EQAQjyuYXlaCouJZ2roLZo/GskXjcc0DO3C48ygB9kP9Pf/i+zseBgAMLToRJ9+/Eru3N6OnpwcXX7ECADBpQhE21qzFgguqM27rwUc3a6+rr1yEpq+M17tnlubjvS9+woySkfh0x6EQ5mDB5y137e8A+npTlu/5bj9GF45i3k7hCaOwZNG52LD5FW3ZkBwFuTlxfNx4EOWl+eEusvQzObiNR2ehvLLJ+PHZLSnLz5wzAw2Nzczbuf+e5XjsyefR1dWtLTtt4kh81fY7fvqlC4X5uUjEg/lZk5RxaJuZHNKH6FgygfGP34NYMoFhE4rw187d+HN7M5LJJN58dQOSyTiKi07EvIVXM23vrDPKoShxfF7faFg+a2oBisYcizllo5B/XA6mjB+BnXt+pxzMu4ukz8G5J43DKevXAIAhBy+79lIsrjoHm597HX39fYjHFfT29iERj+Pf3v9D+pAhObhr9fWovuFuY3hTYhhz/FDc8sTXA26eNBIzJ+c7A8xxflZkBjp6O//C0QO/pCz/ouFLnDqtBADQ0tqGuafPGAjdc8vRsqtNW+/mG65A7bZPcODgr4bPTz55OPb//Pf/lXf7H5g+aQRV0X6GaPQNXAbt2Phyyjrt+ztQMrEYiqLgvgc34rGHVmP59UsBAHeuXa+tt+y6S7CztQ3zz56jLbvm6pswa0oBWr87rC3752gfDnf2YFzhMHQcOkKAear1omstl5dOOUsL+V1d3Zg7/7IB2D90YPHlKyw/UzxlvkXP4Qhe3NaesvjuTa3hdjCPOdEke1VMH5dau0QlB5McAjbPx+KqKExh5XmMpvuFhXFwmOdhiXTMzIDpQcziyAkLe8Bh/f2MMIiBDRVZUSyySASYJIl8Hckqm3mM9rp9WzWX72jHLA+3xjBqdVV2x9Gy42+xALOW+FRtiyXLq9ciPh5Gld2kO79/yrCl9lbPuzlu+svmnzmUDjDJGWCFZSWSnHBJJBKJJLT+A8FJ8ZLx7hGOAAAAAElFTkSuQmCC",
    "EVANGELINE STRANGE":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAYAAADHCaiQAAAJkUlEQVR42u2dT2gVRxzHZx9ReyghJgeJeqnBQ6L0UBspXowHI1aag1g8JCDWQ1GRNgbpwaBV9CBtqoVW6UGDkByk4iFgi+kh6aGtGG0vJu8gthcxeDBKKFgR+npo9jnZzOz82fnzm9nfF4Tne8m+N/PZ7+/PzO4LISgUCoVCoVAoFAqFQqFQKJha1bK2hrPwWkmZgT55+ihBwOjSoE+IJAagQ+82aR134O7z6CEnZYNq6iQIBXSCQOOGnECG6xOqLGjokMEBhgY1dDdXEK6aeJ8Rav9dISgtyCzQECEjYMNuXtWytgYJtFfAoYXnEEM2OjjykI2AIw/Z3gBDDs8Dd59rLWNCDNlJWQGrADS11u2jV44asK4LbUH2AbghdLhFIM6MnuW+1tF7nPk+oVX7DSRgycDNgyj6vSzkEEE3xABXF6Iu5JBAO6+iQ1zcGOrtcpLnsQ/2OKkpZFa0KNJWIWBgTuaFbNPVd5CATYRn2innP+r2AjkvZMuOHx0ccF7GEG0g97py78zoWTIwOhksZGeAY9gaDFEVdC8CRiFgu+EZ3YsORoUKGN2LDkb5BkxvdKus2YbgXroXhrgejQ5GB2PuRcCo/DDuceWugu4VK289usiaQFSAdQstVGQOxtyLORiFgFEgAZvMzdsPn3PyO9Dl9LroJ08fJTaqSJNgWMf66dvPlE5SSBc0NPh0q+pEfHnj9pLn1jQ1Wv+s2w+fI2uaGslXN39f9PzRXe+gg3XCc94dBSypOEznOKIIMdTbtahPhuTiYG5d+XTkZ+5r7ftPSx2jOnyi0O9ndfT73+qPE6ChugLNvTEJwriwTYpczkM0XUnrhrELfVtJ/8gk9/WZ4ZNLwu8y8i95e//nzJ9fRgh5tXCuV4dPkI79p/j59sMtzBANtaq27uCRHRtrZQzPspBF8xOEg1mDiBns7s42cmPq4VL31yE3OdtR8lZFs87oX5KW+sSkrRJvw+F8X1f9cf+VceFN4K9IhRzp6iCEEHJo357cKpoO8bRUWjcobRLIIkv1Fk0UVtEI2EeBJdLM6FnSf2U8uPzrep5A5mDVAoXWklWt5SukV6Oy+Ter3OMsXyHVGmGIlmiXQs/DULoEUDmY5dyQwrROeI62TVLVhb6t3Ndk2qSLV69zX+NtQmQjSu7XKRm66rIUVXTWCUVdnMIV5V/tcAwULvg2KdQ8LCoSSw0Y0uTIhOfUvRDzr1XAIzs21jZ1rjZ2vJCKrcmDHWB6YesO3tS5muiANuUIm/k3L/dOHuwgJk9w8CE6Bc0adN+t+0nIeZg+GbMpJm/cwQO+N/WY3Jt6LOVq+t4lXh4uEqYvXr2e2yqZdG/XpRnSdWnGWDQD3wfTkOkBpo+rnatr7WfGrXzdPR2aaciyIVvU/+ap/cx4kuZW1rizcxNFFc1zdXWwu5YtTlh5uIiLD+3bUwebwtZxNe1e2VpBJZpF0SalA+adwXSYzubhohV1CtrWwkeRcUfZB7efGU9EIdpWsaUKeWB0krssSp+UMn9hxQVoUAsdLMh0CKQhh7hXLFOjBAHYdNPOy3O2IWcLrNS96YlmevXKxmIHuKVKUbvEyscoz21SnvIWOVLIuzvbFl3p0dF7fBFY+vGp05eNfK6TJw5I5968/Nt3635i+9rnoBycN3m8fGxbNFxb4TlaB/PCdPZGcZaTZZxXNP+y4Oa5F5rAOlimzbDtYh7cvLXnUgEuukKThew6VOvAffL0UVId7K6VxsGml+JcQU7bIVW46ePqYHcNAmjjgHkVo+62GStUsyDb6IFpsCpwaVUHu2sq4zZdcYPZLtSFbMPFPNfKwuUtvfrYLkxcOViUl2W2C1lfwSRzJ4SuWBEi+16yf9WbF65ZBhCtDYAGXBS0K8gm4dLzwhs3DdokYG998L2px/WBqBQjeT2yi8UWE+M21WV4Acw6+0SuTl0rC9rWN+apwFVxr+gkrw5210y6FkSILhqKeKEaKlxX8+K8D3Yp03nYlnOjrqJNnK0+/tByEcgu5gRckWUKqOr3Wtr4PJBdbTxEmzr7VrWsraX/RD/ratO/sbm18Gd16V5QDhZNTnZy5+dmnUGmI4Toc0BzdwUCWB7cxubW+j/WpLpybvo+WZh5nxFKvQBqu5CeLN6EQVb6uScPdoD5/NZDdAo579LQEGGKNLZ3JSFkJem59owQ8iJewCw307CH3m0ip/4k0SoFLTrJgwzRvu7H8a2ea88WnOt/3NYqvLyNf96kyMp1kUVX0qrp5OS6F7njtrWL5K2K5rl6bO/KhXAGD66okoYczbxuF+pW2yHL9bitOFi19+PlLNnFB5ch2mY0s9EzV3zDpfOUDGQ6B7qCnLeSJTMuFVebhtzgG26RRYX5udn65NvIyVmwuvlXZx5NLXFWbMG1/W2r83OzVt3sGm52vkyZpWLLuarthO4E2oCsG5KLjIf1PiYgWymybE9Kevz0501CZsFlvY/tkxVsm7RoUtY1FQ69Ou+rk5dNuNZkbRHsQodoIUFFD6YnlkyGjptF+70PpieC7butANY5A388/4WVFCGCbMu5qn83yVYRF/xVlSwXy0IWwQ3dvVZy8B9XD9cfv5xPlJ1p0kW8vGw73/5/TPk94IG7z8kn72+hnnmLfP3Dr+hgkYtFbs6DG4N7rThYVjv7j3HDpc3qNHWw7Uo5Xbigi0eTdQYowFmYpoCt37Ct7rIH0xNk/YZtueAam1vJe0e+EcLNuld03CLzYBt6JUS4MWln/zGre9tR3ZskysWy7UoMudcYYHq9tLG5lbR9MFh/bUWj2lJqTFdXqozlu9Gbi/4/fPsv5vwG62CTBZYJF0MdW+lDdFHFFp4RcAkUNOC0VVIJ03nPs9xrqkVCwCgEXLTYmp+bJZc39zCfjy33ggGse8dASK2Sz0o66hAt0zLF7N7S5mBWmEbAgbs4zb9lcq9xwGVxRekd/HL+9UX5quvRpnrhrItVnnfZA2fXoU1dyVH6Pvjy5h7hiYEODqRFWr9h25L8W5ZWCVey0MEYphEwCqysXXRHV9I+5TP/yujj3l1LahJ0sEarpBqmQ98mNAI4ez1WkSozZhW5WzI7z8E42FXb8GB6ghy4MwYCtI9WyTjg0P5g84E7Y2DWo23MnTHAkNehIbnY9VyWpk1iQYbkXuyDUQhYxcVlcC8hBb9tllW+5xUKb7z5EC21oH/+bsuttLNfxqL7xWjGV7JYrUBolTU62EADbjMMF5XtDQj6hJftjXUdHB3gWKULuOLjTVE4zygUCoUi/wERMHEDVx8ydwAAAABJRU5ErkJggg==",
    "GIDEON HARK":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAYAAADHCaiQAAAHD0lEQVR42u2dzWtVRxjG33t6cSnSLFIwi0JwUbEuLIESELTFLm5rg4Eu+gEp3SmEEFOQQKEUCkGoihRclga0XRQiqdZFJTUQkII0Cyu6KNl1YRf1Pyjpop0492TOyTln3vl4Z55npYmej/md5/2YmXsuEQRBEARBEARBEARBEBSnRkfGtjEKz9XLGehff//ZA2C4VPQD0UsB6OljL3Y67q3NZ8lD7uUGleshkAK6B6BpQ+7FDDck1KagY4ccHeDYoEp3cwG47VR1jbH23wVBnSCbQMcIGYCZ3Tw6MrYdE+iggKWFZ4khGw5OPGQDcOIhOxjgmMPzrc1nnaYxYwzZvVwBtwHINdcdoldOGnBXF7qCHAJwXzpcG4irSzOVv5taXDaeR1q135MMuAncOoh7qQy5i6NDO1gsYH3gbCDaQG5y/aEBF1Ld61OXPjzhJc+jDw44qAqyKVrYtFUAHJmT9wrZXNW3SMDcuffKJ28FgVwXspvePxwsOC8jRDPkXl/uXV2aoYUb62IhewOcwtKgRBVwLwBDAOw2PMO9cDAkFTDca6c+hsDNwxhLp+DFwfoqSps5Wwnujb0XLkI96bGvwnC6GTkYuRdVtBSZcm/IfFzAvXurbj7aZk4gKcCm7Sqp5mHl2Bjur4B7kYO95CkoMQfHFMZSvr+oQjTnYJy7eNPL/4ld/dBPuZr0sAnbnGBMx7p24YzY1OMNsGoPbAbhq5Vfd/3s4IH9zq/93MWbdPDAfrr80+bQz8+/fQwObuNive9ssz21qcO6HqdrhDDdW3aA2+rT6deH/j7/zc/Oz3ntwhmaWlweWlgouxlVNEOOKsNVvXLbzegckhCevTm4yWsK24ax+evrRET09Mltmr++TlOff/88xH/xvtX1qmM9fXKbXnrlnf9+uG8fLfxwny69N9kpTKNN6qgdAMKOnR1gXy3G3XsP6e69h2zHU4sQsc7OOQfM0R5JV/nefa4oRVtFq1apasHhykcnhirpJh8CV849dfJo/bkrcniIYi7JHCxxIAEYSg9w2/xb/nerSzNeJjJSKiKzdXDT/AsHIw+LaZFEODiWMF2ei5YSpp0BRv8LB3tzca75N0rAuuPRD6OKFpN/yw+wr+lKMYBT6onhYAH9r4QWSQRg5OGMHGwTprnXgaUo+Vc46KFZh9w0ZHMWWHCwoVXidPGpk0d3wCrYXVzN9VFShOiKPGxbUSvQOUx8iMnBroqttpAXbqw7/QqB7ABPT4wbIYfsi9V1dG2RfE52iHCwDpkzVLctsKS5V+REhykfQwLbJPWJgJUHWzQ9MU7TE+O08mBrB7IOVv/zd99usJz/g4+Pi869ohyswFblY9fS4UqbWRMz0WFychPn2eZfyXBF5mAfrVMKzhUJ2HeoroMrZSuSOAf7gqw+OqMfu6pdA2APkF2Gf5X7EaI1cXzTZl0YLBdanC6W7lqvVbTtK5L0B6Y8tacqa70/5pR0uOJCtCkqKMjcMh2zrj1DH8wIucrJPvI+d2SCgx3ldxu4CNEBK2spx/Xl/ugBt1k75YZhOh539HC9Jixy013doLgOpyG+5DmbED06MrZdHmCsB2eQg31BXhvM7qqk0SY5GuA373ztDbI+gaKuoXx+OLijlEtMcH05V51HCtQk2yQIgAFYQu6FEgIcc5WqHrrYK2mE6Ej6ewAOVEFLr6T7MT2VVeEutkEtX0/VdbdZUBgdGdt2sUrWjwWu0uO5y7W/P3z1/M7kg08Xl3eLNL3OtuPGDbmICa7toPs4j+uKnnv8+hLh6tOFavBduNk12KpvZOF0cuEDrqtv/9IHndvNPl3r0iyFq4sxDYoUyCHgms7DAblwfbGrSzND4dOFmzkhh3Sui/P1XV1k1XKeGkDuXYm2eTl0SNbPzdkWOp3oMA2w7uhY3BwLXBdyArjJE+gybLeBHAtcV5M5QXd0uPzsrR7qqiZFXMONYSGCHfDLZ0dp6+yXRET06NEfjUG7gmzKyz5d26QOmFpcprnBJP1IvxER0dxgkq7euR9/Do5FVSE7h3XmbJYLFUzlqFw2EfQpI60NZok28tohggX/CORyVQyA4eB66fOla4NZGj/92c7vjhw5hBFuoF82hruNd+k14/iKdXDK38sQ+t4QohGiIQCGABgCYChFwKrKTHF2Sd1TyEoaDoaDIQCG8gAs8RUHANxB+k4OzEfXqzwPzbWTAyEaDkaLlEKrBAfDwRAAQ9HK2aa7pnuic9cbxw/tqkngYMgP4PJ+LJsqM2V1uUf9/9jsywrm4JT3YcV0z+yA8YLuuMaODTDmofkk5gPgEPpgCIAhG1m9bMtUvtcVCq8efgEj/r9+f/xPbaVdfhlL1xejsc9kmVoBVNYJOdhWLl7y6UI216k/8E17464Ojg4wxAu4CHFSCOMMQRAE0b+vA6XcgLEh5AAAAABJRU5ErkJggg==",
    "SIMON TEMPLE":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAYAAADHCaiQAAAHQUlEQVR42u2dzWsdVRjGzx2GLktrFxHahU1wUaGbloJ0FYlXSqwWA11FQYwgXYSSGxddiAtx0YW5pWQlGBFsV4VIJYZiGsyqCKXZCGYhaTcu6kL9E+Kinsu5J/NxZs7X+555Hgjk686dOb953o8zZ+YKAUEQBEEQBEEQBEEQBEEQBEEQBEEQxFMTJ04dTJw4dYCRKFaPM1jbbfz195+91AHn3OGenTxus6mD1E+OHmfXWsJtpd+e/ssKcg9g20PmADgHWLv9ow65xwEuNbCcQnVGve2hCJfyfrEJ0VwGkHqozgTk5CSkOtkCwIlHGlKApQs4heeqqh+AEaoBGKEagEv7U4Rqphcb6uD6hlzm1rOTx0mcYMkB1gd1a7jgbNv9wZpYmZ8WQgixfHdn9H51IZlKb0wGcNsKWoXrEmyRVuanR5C5KEvFub7hUsz1SQMOBXdruDDmWhmuuUDOOIKVA3vro7ei7AMnyBlX18aCWwSZcrtEArDJQFCCyykfZxxcSxUuh1BNqg/WWyTKri1qnShCzqm6VhVVuGiTLMKxbH0AN9Ec3B+ssYJb1ovHrqSjA1YHYO7CVBKuoXQcuB6MEA0BsCOtP96vzGcx8yu3q0hwMBwMATAqaKNKOmarBAfDwTz14Rf3gryGuvKuwmyyre8+v1r5mpX5adEfrAGwrb5a//XQ704eOxrkBDp57KgY/rQ79vvB2+fg4BCqc5jtdjiH7miA21bQn869Pvbz0rc/BzmB1PXRQohDbi6rpOXkTax10qyKLB2uEC8uJ8bIfxzCM+sQvXRnRwghxPO9DbF0Z0f0b3w/+tvWzQ+sti239XxvQ7x85vKLXx45IpbvPRIrVy+iTQqpEQBm2wZgT7r/YFfcf7DbmeONBlgtOGQhAiWeg9Wqc2u4ULls59b702OVtMklRuncK5eqC6SyHN60mFNP3Fh3GpIM0VRnhRCiIQBukoe3hgtBJjJcpxkAjjBApvnXlSjkX9IhGnk4EcBcwrQ+F80hPKPIgoNp5GFbF/vOv5SX1JJ2MNc8TKXAIgOY+rRlVf6V7qW6KpRNDubYEwNwgIrUZ/7lcDsLeQdzyMPqyUgp/5ICbJKHbcK06+vAXG5GS+pps0VSQ7MK2TRkm0xwIEQ7zMM2Lr5y6dwIrITdxtWqe6nfU0UKcFmY1vOwbUUtQYe68ADAEYutppCX7+6Urh6hVmCxAKyGQBUy+uKEHFyW53xD1gss6V55onG4p5kc4Lp2qSgfQ4zbpPXH+2LuwtTYisv+YG0MrPr9N1//4uR9P/7kDePcSzX/sgnRcvDK8rFvqXA5hWchmHx+sJ6LQzxuSebfIrg6YD2VUHIw6U+v1iHrgCXkG6s/OH/vJ8/+GTuJTOECsAfI50+/5AUwd7gsARdB9gH45uJ7h/I8N7gsAJtA9uXgsj6cC1w2gKsg6/nYVYGVAlxWgE0hu1RRK0S5YmbbB1cNppwIAdwEHGySk31PtnADzPLOhtADyxUuW8CmELoONynAPiBzh5tUDk45RXRyokPtfWOvnaYMPKMMVX7V/W+oi/7bs4vW+9pZB9cNjj64M5urweDKCFEEWO4HVXf3OEGNAdcEsinsGMBzSmCrBo+DyqJM0bGHAp3HBssdalvgoZ4fnQNseOASdAg35wCbNujMF1gd7vbsIuBqoVofDx+tVs+3a9WzVU5K2ICOUUE3qaRN91/fjl6QuXJzzzfYsmqyTU8ZY3KjCLDLqto36F4osEUrFIsG4Pfrw8r3e+32IApkHa7JftqOhQvQmQ3YpnD175s41oWjXLxPm/BcNRby55nN1dLwbZOfc1vHmoLVw6sctJnN1caDpuZ1uR0fbrYFazseerXdpn/ObB3bFK5LJ6vv7drNoeCaulndhyZuzlyBVatbUzdRhewCbtuCsGpM2oDOmhZQVcVAmzDpIrS6hBwTromby/KzdYguAtvGtT4hy33sD9Yag1Zf42pSxva46tzsrYq2da3PvraNm1271qXq3OwUsEvX+lQTyJThujBAFtNtsSFzgWsj4z74lWsTYv/al0IIIZ7+8cz7TJFLyHq/HAqs/iwRF7o+e1H8KJ6Mvr+9+cjPTBYnlbm5C1e3OvOhHBKmdFRXLl3mokPanl0U4mG3Fh3gY3UYqU0+B+CuOlid/tqeXRRT73w2+tvkq6cxchG08XBv7Od3xflCXuQcnPLnFMY+NoRoFFkQAEMADAEwlCJgF4vJqUpdgAAHQwAMATDUBrDtHQgQEwerKzkwHx1W+jx03UoOhGg4GC1SCq0SHAwHQwAMkVXjRXc+1kRD9br85plDtQscDBUD1tdjhagyU5bPY9TvFybj4JTXYVE6ZmPA+CBmOmrCohYw5qHpyoQNiiz0wRAAQ2TVq2uTXBZZU1MHGPH/tb9v9xRJ9UKNmov1h6TlTTeIajtRB4dSk4eRxpTNftaZwKZf1h1MDjBkJx1wZvJPEE+4EARBEGn9B82GbdccE8GaAAAAAElFTkSuQmCC",
    "THE GATEKEEPER":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAYAAADHCaiQAAAHzElEQVR42u2dv2scRxTHZ1dyZ7ggkxhCCiFVUaHOkLvKhWLyg0CwVATcBJE+GLUu0wqTf8C4SCCFFJIiKRwXabIKBFK4UKqIFCYgB4kY3AVzabzHaLU/Zmbfe/PezHtgfOLu9sd85vud92Z354zR0NDQ0GAaheSDv37trTn1Pk/PnhYKOEGwUiEXCjZtyIXCTRt0IRnsvFiia6j5S5GQCwULA5or5EIS2NhwJUIuFGzall1wh8sNrDTIhYJN27ILBZs25ELhpm3ZJYeGmRdL4uEOddBYEzVFbPWmAJazZZdce3yqaqZWcmk0okCmAq2AEx+XycaD5smkbM+cxmVVMEAJxDnnWM690X33NxbSvFgiPW4SBWOMNdRwMZWMORZHseixKogFV2Isp3IiR9Uh2rans21wq07GoqHtp029mHCluwi5RY/p+TEadTrb7uxAEiCLL5Mo1NsHWQEnYM37d252Qg5VMVUmjQoYavaqrxGbCRA2ZGlWLdaij6pDMrg2ZGlJF3vAXQ03nW2b+7u3yI9n/87NXtDZ1MEQY0oX3Bhg20Dvff0z+/qYTMG+J84F7lF1eAkkVClHkWiJGoM5KNdlTOY0HqNY9NieGNpA1ElXl1VnZ9E+9hxqzdhwfSFyUXESF/yplMtZqeRZdMysuaoOwI5pNtthW5dHUXDo7FUI3LsPHqHCbdsetIqxM2mxFk0BNwWrZgHYV73UcNu2LQUyKGCK+3xjKZfKHUQpGHraLqYtU4zHWZdJseFKHY9ZAm5eWOcEF2O/mJl0qcpNezwuFS4MZI6THGwANy2qq7GkZrKqYKG2KKHDgQJuPgaZwyMmXZB9S0SsREsfH1WLjhf2VKXrVR0NVbAC1nAP7s6igFXBPFUTQznY+8XIpMU+AH68smY2XjU2dj1aQz1eWTMb5yei2kkk4Ko6MBuzHXO8smaMMQvQkLBtpS72c34ibjYtiSUcagBjYbdBlR5sALctL3T3wSNzf/fW4qLDbLYzCK0N9tB3bAtOLcQquGnTfbC7QPuAlWjPKFk015+XaYPDDVjTwSDacpnioEPvzRp7M3md8faBrJ0gxKIlTJ+KTrL6bNrHUuvPQWxLJzoIIhRIVR2Iq3PFA/ZZSWfj/GS02mrIqYAWZ9HNUskeQ6Fs1LZsjslYchbtomIMCDHBQlUjrAG7ZtBjZqy4QMa6vSnby4W53CFSZgm2uJJNB2EFmHSNqeJKFipmr2DIJwag1NuM2zfWFTBkJg2mvAxUjAKY4w3wWOo1xphvf/tz1FCDcZEh+yw6FxWLADx2HMZUrwJmmGzlpGL2gMdmqDmrlxTwmERrdBky/2/4n0d2bn+Oc4lkDPHVpBgLZuf+0DiagrtS/WL+0kvNdQnSVEoqYyZmiYRu0adnTwsI0F2QNZiMwT6guyy8OZkQK6Q5B/ktrn0PVNVwu5R9+8b6JdBVdWC23v300md/PfrOGGPMO9OPQd57/NNDZ7hjFkAXZdHQtt2mYipFSR3zo9XBfaA1EproSBF0aM2P0Q5sZrL6To57Bwg9PoqrbCW3hqobq35t/x37+NrKNO6dT5w1ui5r8OTJY2OMMS9e/HvpvatXXxt8b3NzazCDt+GG/FYFdgbNTsGQdri5udUKsAbb954LXA72myTgLsht9hmyaErz811wm8fA1arFZq9tVl1DbgPictHBtTN0wfS1abVoz+ibsx6CNxaur01TwBWr4DHrR7Up2dfG+2C4qlgBOwINWQXAhgwxBRmSTWcP2FWl9f3SIZB94U4mq+b587+8vqOAHYFOJqsX/q4b2vUBcZcO0LWt+rvNY7CPwxdy8oBdFNrWoCFwXSAPbasP8hDsmIBLTnAnk9UL/6CjC6JvR+nrkBjHLQpwG1zKhqlhNv9HnWxoqJVKveSAu+BSBzZcTiouc4ObW5QKlyb6ZrUwf5a3lAY3NIOGsnXXOphLBy4xwXb1TN/JghwCS8Ul5cHaqhsLmfrHICn2hwG5pIY7FrJtfVSQ7f2MsV6XpzmgIRdUPbA5ZkI0mt1BMMZk6GPs6rBtn2G30l1fMtXW+BB2jalmCrh922f145RdcIdOkCtkSrj157AgoyRZ9sEOWSc3yDGHDozSqsSC6wMLCnK97+ls2xu0/R2ouXFXuPY5Q0NGnejw6b2QV3R81QyVJYe0D/aEDQrg2BMZPpBjwaVqs2QXQnOBTAWXelrVDvBFWH7/6rPF62cByQ1kQ9v5QL395k16GGDrCmI623aG+/kHM+uvN82XP1Y8AXNVc22BMcfbGJHNWpXNSZdcLldmtRjpZLJq3nt/L6tr0braLIPAtG8FrAruD3u+dDJZNesf3Vu898bZH8GlTUpl2lB888X+hb8f/vJ3a/uKVTD1xfuczk0tWi1aQwFrKGANBayRImCMiwzcSqWYmbQqWBWsoYA18gCszxxlouBn195evPadj84tmvPQUHdyqEWrgrVESqFUUgWrgjUUsAbbQLtt1s6kNbrjk3t7l3ISVbAGDeDm/VhjssyUI+Qc7e+MuS8rmoJTvg+L0zmDA475oJX0wGg7MMA6Dw0XkG2pSZYmWRoKWINtkD4ffP2fHxavT77fzbPFX7XB6esfygTcVgpoZh0vRi2Xh7nOcS7lkGttHPwbxQpYRoQCLmPsVEPbWUNDQ0PD/A80w3fpPI0MdQAAAABJRU5ErkJggg==",
    "WHISKEY SIXX":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAGkUlEQVR42u2db0xVZRzHn3s4AjohF7r+DBeEhaCw8AW36XDWojZzyWJDmmuMfJHpGm6wWr6g1hblFi94QfjGlSWL2FrThtNZ4ka1mZt/Qwo1pbGGELr5r4lyby9Onc4O5zz3/H9+55zvd2xcnudynud87vd8z/M8595zExOHNjPIf0lAEIxk5deyxiGw8EkX+2rgaEQHQEMADdAQQAN0RMfRkCcqLCqDoxEdiA46+m3gpYzPKX3xgPB+jl8ZMSquIQ3aClyz51OATt3RdvnyN0KHuPegOWde84PLM8SG26SAW46Mi4njlqONmA5u70FzwkEgZW2jQljLkTcyEWsHN2EpLCpTfsRSFvViBz0z/L77iYgNJSmCJkU5YNZSnCkHyVqK3kFKs3tYvYtQRhO3czCdlEA5mK4iOiIRHSGys98dhqPD7+jQ2dnXbsPRIXd0SO3sX+fh6AhNWCCADjnoUAe0T7sARyM6ABoCaLry5e0GnCv56bs31cdHulqD3+Halk71cSInL/qOFkJZYLuIjhBGh8Wx55PP9YqylWrqx1ZMuMxAOBqjDoCOyekIjgZoCKABGgJogAZoCKABGgJogAZoKAqgmzr6I9+ieNDKPjd19Aez82pDoliTiA6/d16gkVXJRMgqJaeOf62WFJavUx8f/PAN/gbXv9OjPBg/f0y7hSV5BYatH+tdGwvQe3c2GOKuStZrWbuUIWWlacYmYhQd/+2znnVVst7lls02YthilB2taurmtKH1qpL1S/IKlFq7iDkNxX0cbUbB8Ni3mxUUKIt3tO4sNze1LbI2e5rArCA9M9y7s8EQDX98ZlhrtimAzmBDw6mN2XyHFGLSax2GfrRYQpAyI76oZBcZTcQhAK11qBlEtZYyZRaWZVI+ROKIwwRaUf/+Qc6fAO0lZRWu7k+A9kwNG59REat81UKA9pi1lmyIKLMwXjNU+IaLshjQ2g+guYwRgIb0wjcLORT/qwwUae9ZLsbR7tMjdK0jOqIeHbUtncI/C+5G1r/KgHRGt+760vH/dr79CkYdgrNS4LlBgKMTOXnam0mEyJUhPhkGaTGxQx0xoIO8I8lcLS2tjpGjVdbBGE1tRQhlKuNov1lrtz9+ZcTuyCz0oLUB4h9rUTdREg9a+SKnYFgToUwiOvxjTYcylYz2gzUpymJAG56OvGVNjTKttQ7tjFEh5WDVSfciEaHMqC0q6WbntnDPPQ7oUBYD+v7MDU7t0a42HbKMuA2j5khX67M7Po416IxSmBritv7v1OQlaN19D/nOdYbbK8Qltft4ULLzw+FoK4hTs/dtseMQN+Nr1oSUJWfsv+esZbKI/QsEpQN83MqOeIhbpo/YJwWMWw6G8lzEe8qTfqM0a2LL+ePB45YjidjKCxAwbjlWiAXilmOI2ApuPnEHwxLZW8ohQszHndHgdq0txxyxYYet54l13DIQu49vK7hdjTqih9j92dI5aEM7+4f4Us9gJHHLXnUl2jI8W9oaishA7C1uS6B1Hxcwe6MJqSULgUslttJDcjk3gbwBDXk1m5OtZAUCWrfjDmLatqMR0M5QSAhoZHSkYtoh6NgGtOPdtwcaAe0YiISARkZHKqadgPYwoBc9XrimfWvN+9vWvLt1/uJFjLENX3Qwxh56annyrWblOflLH163a0dCkjjl9GPaRi/9COhV2xtPdvcNtX9y+fBPFU3/fzfw1dO/SnLW4vISxlhFc93ZPd+kUylOOf2YlsQGdM4DC6V5MmNs4sTwpYM/aKvOfXZgxasbHn268s7UtWujYxnLkdE8DfcOrP3gzVXbNxWUFU+P/K6tuvXn5PULY5XNdcP7BqyUE49pye9s4uuPwRPftXw0PXK54rW6sk0v6Grl+bnpVErOzbZYTjmmJW+TyF5u5C98sLTo3q2/x47+/ON7u4ufX62tLVhePG9B7qnd/ZVbXrZSTjymJYEBnWbp6rYmZbCRnbfgzl/X1apEllTRvPGXz7+dPDOanp19pHolv5y+RL7jf+bG7dM9/cm2ptmZe+lU+mT3V2pVyfqaqbMXbl+dZoyd+3T/6vbXJ8+Mzt6dMSunDzoxcWgzY2xZ4xDf0crREfMlDkMpa9OGl7WUa7UX+2oMosPimwsgu4gwBcdaR2xBI6DtYtHmsISADiamER3I6HiCRkC7jGkJAR1MTCM6kNExBI2Ado9IQkAHE9OIDmR03EAjoD2JacnZzB2yG9OIDmR0tPTvNUMIjo6I/gFhEFxvDQvYawAAAABJRU5ErkJggg==",
    "MAULER Y":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAFGklEQVR42u2du04UURyHd8cTIcAuFBZCiGKyxODaUVCRWAA1pQm9iS9BwUuY+ASWlCQ0JlY8AGh0CzSE3cJid4CNklUsJoyTuZ5z5tzP7x8SGJidy7e//c5lZtnm4GivgZJfARCoKRJ967z+JGqLyytr5StcnH/2CnHvw+Z/0ALLN45QB0ADNAqgARoF0AAN0CiABmgUQJtURPYOJr9C0xFMt5FoqMOhUvOaI2rOoT0/ZyDicHSNREMdKIA2WdNeg1bZcgQKYmJmS2jrgCV78fv8y4ld9pA6cvHd0cpebWgMbVNH6nYOGwUt1R5ItKIoADQGLACNIaIpoK1rCRUcJxINdbhlD4BWZA+AtlYdDkzaybAHEq3IHgCNXgdAuy1oSZpGohVpGqDhaLfsAdCK7BHIiADuL0CitdmD6DqHmYW2lv2Oh9Xs2vNzwm80RaKhDoAu1ND9TREqb/C2RdNItKJOHkA77WhdXQ76Xcf2E3WTmGDQTmoa6gBoFEBrETRA25xotIdINEC7LmiARqKdKykT/2S6HU16haPr8tmZ4c9RcvHi7GP88/KLV/HPC4/my/cYb6doC5TbcSrRGic6Kg9AkqChDsvVwV3ZF7v6LVimDgxbzEq0qNZJyHbkCRqORj8aoFHGgbarPZQqaOO6dwZ1NEs/tofjs2agDkcdXWf8vdtZLFk0fBrAGnVEWHc7i4e9fnZRuKCFfxCVXND003iVddjrx3CTv9RoaqbnwyZHH/b6SbKyKfvej4742kXZ1u5dfcqnJ8fPnm9U9qAFmlo66JSmx8NwZqF9enKs96mKKbusjvEwVH+e/jqannV3Y1vsmlqe5sDw12/EjoYg5Zqpncqe4jCl11HOOkmtnCD9mi6ro3war4j11vrO4qSZ/Npa36FZM2Kdi1tj22BEPzp7/kVMmSrFWm8LbMqAJUmhu7HdJ3e5X9mcZlem794oE7RZI8MISmXuKHUcvxWZcrN+DcEjHJVv167sYKS2YEK3XRFo1stalKz5HotE1+U1Hob0j1Ip6Ibhs3dM4MwMsh2g6QkaTrmhcpo0OY3H+thwdP346VLRXwffL82PizUT/7k0B98va1JWI+iGXVdYUlitCLIGddDE5+73VXLxXbeTu9r+1c1Ba7bxcjX7p7enveRic6rlI+jKak61kqwjalncB63ZSsRGUZYFOnWV/vwrw8fAve+uppAV4S5BHK3/5uwbA4iHbYsTzYQ4ZYxc3PQPZ63JbSgVNzGNcjluGYjV4Ca6EP/9M2FiV0K8iG/RLoIHpBK3cNaCQUeJEIJYeFpTB1COW3i0ifmIJZVi3EQN5SzipZUnslEW7eLy/Id63MRJxDRPgGLcxCvEGnETDxHT4C4nztEtIWIpW4S4HHdlwFmjTTxHnHvA9D6hx02AuL6+aXDX6nW4h7h+a8kPOjfO8hDvX904iZuIOhS3K7e1ZOqKECAWi7uoeK4ZGjVloXeqRBhomqkilKxEozhyyQ/aN0HXPHFm0BA0H4oAgoajndI0J2hvBc19+mygIWhuIAEEDUc7pWke0J4Lmg8CA2gIug6WAIKGo53SNDNoCJoPBS1oCLomnACChqM9Bg1B0wOZ3IbLK2vx23kCGm9A0PU1DXUoKvxHdIl1/x83N9kSDUFzaDpfHRC0PE3D0ehH+wkagq6p6QCCVqNpqAOO9hA0BF0fUQBBq9E01AFH+wYaghai6YBv5I5i1TTUAUe7Vc3B0R4oINHu1D/U8rxf7ez9jgAAAABJRU5ErkJggg==",
    "NIKKI POTEET":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAE8klEQVR42u2dP2gUQRjF58bFVLGyTJHiIEZSBBFSBQSt7CwkwYCgINZqagvrqJ0gQsQUkmBhJykshFSChCBBDaSwSJE6Vgmb02Jlsuzuzc3Ozsw3f95rcpc/u9/89t2bbya5Te9wc4lB9sWBwI2y4kN/cYsxNjE5XTw9+P0zZSiCQ1naTPbX5+Fo546GjJhXFXTiiYHJEKAhgAZogIYAGqChuBYsvz7dGvk9l25+BGhbcId9v4fQs9D5yg/iD/EsMsSNx/QBNz3oicnpz68uObiEtLiz+FzsJ26eCGXak5I5mmq0hNbmqVGmKoOnSdl9MTxZyo5L4ilTdlkYT5yys/KwexdRRntuZzdFclB2UyqiI4roCMjOtguGo8N3dHB2tlo2HB24owO1s73i4eiIFiwQQAcOOuiAtjQEOBrRAdAQQPsrK39uIPlN/t/jP+Lx3saK+wFPLSyLx72x8fgdTUKZ8LyIjgCjQ7H3nLq+RmWrM1Nf/N4xA+FodB0Anch0BEcDNATQAA0BNEADNATQAA0BNEADNATQAA0BNKGIbyMxc+9p+enBjy/i8cTla+Lx7ttniscZdgTF48DRiA4oiOioqP5id3+EhmOauFE8HJ2Go03NToSzXJDR4aeM3Cge0YGuA6AhgAZogA6o1pXX7yVPAdokZQG38hSgjWn54R2BWPAVnwRow6zLZAOiHORkWPANizIN6PIb0DrGCEBDVZ1tKjX+W0oh/Ae+IB3dPT2COzuiw3l0OA6HqYVl8veC04D2SrcfvdD+2Q8vHyOjic1FODcQOLo3Nl6+mURArlTRsOaNeDJ0aTHaVocGtMs7knhydk4+WjdGE2ehusZedB22Wz2XodHUJc8TZ3TZXPZYUN1Eya/J0DZrTyh7sQS3x9ofysyTvQ4brL2izPzZVDLL2jfKzKu9jvKKsSCl0YpULpInlJlvm0qV1Xkr3PXXAQnlyhJcdHtZ5csONkvzkyPJV/c3nleQjcTdGDV7Gyv9xSf+eMjHbdKCaSNu9R/3TSZBV+57KHeuHm5TiPs33smgnL9gdGXIGGO9w80lxlh/cct2OHx7M8O81NUHu2ZZV8Nwfd58dAxzsbeUi9rqrIuBKOKW/wGB4T46PzkKkbK8QsmgaBYskmr8pzyyTiO4M3uII5MkTEb1xN22SUde58FpHoqdhakHp3nHUZuMDhXEg9N8e3U2ONtur84WxcuJa7DmZrNClBgiZcG6MhYj1uamjFwuK1zK9fpN4eZmEUdAuXEU3XF3au/qp4+DshjLztqcOu6u7V3jtaqfb2dtbpAfR9bSDfLjgvXs3a+VsfNzmWHQI1W57FGqjrvRkZIle2YKcXx2FuPi2Zg6bpMZXc+NWClLRtc2rHn3FXbclE2NkZNXEBNriS/1QUfZZqiw1pv8W4MW2ZQa5fqoW8U013shxLQwcZOWePubYQ1zpw7olO2sTaAd6EB3me2xVo9p3uolAMraNNotwa/c30lnf0MuyUK8cdNDJ6NBWQNCC9DaW7GRd3tqWHjbDhrSE/poR910a9AIaD0UqqAR0B3hcAQ0Mjph0AhodSCVYOAquYGA7h7TiA5kdLKgEdBdYpojoN3ENKIDGZ0maAR0x5jmCGg3MY3oQEYnCBoB3R0RR0C7iWlEBzI6NdAIaCMxzfVW7lDbmEZ0IKPj0v+bV0FwdCT6B9ozpfuVE5eoAAAAAElFTkSuQmCC",
    "JOHNNY PUTRID":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAErUlEQVR42u2dP2hTQRzHk/O0UkhrNwsOHYrgIHbTxSWD2LU6FLtVcHB1cLBucXBwdRDMKB3UtcHBxaXdFIdCKZKhkG5pKgiWWh0ePkJe3uXe/b/7fX8ItjbvvbuP33zuz0uT+mFnrYayXwwI3BTP/lpc/QIWlmp/8zYSDXUANAqgARoF0AAN0CiABmjU/yV44HV5enIgDn+dpQP6ysK1kX856O56hFv2+ACh8xjDK3+ScIjzxBCPPWcIuKuBtiQKG4hDw83TS3GYuBkRyn4vajLRxQmJwDm+eusx2oQy5bcZjCZl940xpg6ZCUlQlPMmuXEIo5ll9w1jxCk7ax527xIaDAOPs5tGMlB201SoIwl1RBRn2w3mE9fQ9rb2kWiicbbabDja+RLcrCIijbO9dTkSndCCBQXQkYOOWtCWuoBEQx0AjQLoGBYsBksw2//7+2f+9VZr3X2Hlzfa+df1qUb6ifZC2eN1oY4I1SE195ye7fUHvmKVh3r91QdNByLRmHUANJHhCIkGaBRAAzQKoAGa0Mpw7Ktn8NIZJBqgUWJ1wBJIdFqJdlz3X2yqHfj+2aqR88xcPI9EI9Gm6/u7W/IPvv5g2/Z5kgXt0jkYDDHrQFFWh6lZBxINdaAAGqBRYQyGptYOvtYgSDQSXTJLc38eydfeIdFIdLqleVs1pkR//PxV8C0GQ5OUc7gj30IdxmqluVSEu9JcctYAzduqMaljpbk0TNYlZYqzjoxvXJT9gB7+BTQd1gCNAmhqoPXtEd3VkejUQfsKta/rBrpgefq6o3zsy8d3kWjP4fI4NnhIdH2qkb+ZRHFfuP3knsFUjpx/fm621x/IHz68Y0doCY7BUCXUHvvs5erMb2+LT2SDN5mKp+r1B5UoH3R38z8JzqONsHZ/VzBc0IJwaWIqO9yjsjzPo+tTjV5/MD83WwYrm4QYCTLpj9kTsx4GJyY+8Rng/bMjg1gZilnryyT0T+h0+XvLMqzjpRzWrCNjnSTlWmibSjlr/WhXnTL7BG3JEqcnx4Kffmo9XN5o6+DOjt1qrd95/rb0QdOXSCc6q+xtxHLcWYmhDz8yzHchMwl6RIji5MrjLqIUHyK1tj46Evx04epN409o7l4OWZ39OZXHXRNuJZfxLbsEOzeh1929nYx1uKANIlZOq2QDxLi7ezu1Wo1fmAkOtD3ElkoGd9YpI7i5G8pFxG8Wb9hGWXaJR/vf3OPmSSKW+Q9wjJuTQuwRNyeIWAa3mPjpyXFV1tws5YgQi3FPDHjVaHPiiMc2WN4n8rg5EOvrWwa31qwjPcT6o6U66LFxtof4R3s7SdzcVFPSrrGjZaWpCAdis7jLSuVWVlBbFn63SoyB1txTRmklGqWQS3XQ1ASt2fHKoCFoNRQMgoajk9K0ImiyglbufjXQELQyEAZBw9FJaVoFNHFBq0GoABqC1sHCIGg4OilNVwYNQauhkAUNQWvCYRA0HE0YNAQtD2REDEzGGxC0vqahDjiaLGgIWkfTDIJ2o2moA46mCRqC1tQ0g6DdaBrqgKMJgoag9RExCNqNpqEOOJoaaAjaiKaZ2sodVVXTUAccnVbVDztroIBEp1P/AAoXVmrtLj0lAAAAAElFTkSuQmCC",
    TNT: "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEuUlEQVR42u2dvWsUQRiH78bBHEJUUqmckkIIsRYbCQiWahobITYixMI/4VJ6jaVgYWoLLWwShTRCQOysFcFCJOghGEwEUYnRYmGz7N7Ozfc7H7+XQO7ysTP75JdnZuc2k+5oY6mDcl8MCPwUL96dvfEqhN70Z+erT7c+vksA8YcnCwegA6k0yEIdAA3QKMuDIao2DlsfOZBoqAPqSLJczyyRaKgD6vBfM73Jgdj+tQ/QruC2ff2RE3OhXdbz2PmOrZ+j903icPQBYiuUa8StHzPiRLtmURyfVuI8bcT+cbctqbNMKNM2SpZoWm+SmITnRrnaDRes22aTLE/K/jvDsqXsuUssZ8o+O8Yyp+yte1i9S8jRgcfZTycZKPvpKtSRhDoiirPrDiPR8Sc6ujg77TYSHXmiI42zu84j0QldsKA6JuvRgtsvO5XXoVEOE50AZeuahjqCV4fgDqCopxwYDAEa5VQdghK8uvzv94/y8dpw2f8JLw5Wy8fdqen0E01CmbBdqCNCdUhNNnrHvu3sUMWqDPWt+08NHYhEY9YB0JkMR0g0QKMAGqBRAA3QAI0CaIBGATRAAzQKoAEaBdCERbyNxPXh4+rTrbeb5eP+uUvl42eDm5LHaTuC5HEIQJf3MCa81TDUAXU4ruYvu/8jmHag5W7mVtAwRlKJtjU6EY5yUaojgRpnggUMhph1ADQKoAEaFRfo9ZdvBE8B2iblEm7tKUBbq2uXz5eIS77lBwHaMusq2YgoRzkYFnzjokwDuvoHaIYaAWgUQGcF2twe0bWORKcOmirUVO0GuvC/8vC59vfeu3sViSYOF+HYQJDo7tR0dTOJiFIZ8WDoM2K0Ux0a0D53JAmkdUZ+tn6CVrZC9TMOYh7tmjWtNOind9VRcXGw6mjXA5NNlCz+s3DiRFfP3EXuqsc8PXehPztfvOWoDnesa5TzVYdTh1ihbPFOz1Auwe2yrnm5ycv/pp4BrXXUWHe0NgWqyYd2wh4o6ObVuRLupt/DoUwDeu/PruCzL4Z3asgm4h47hK4Nl6+sPGptpnc860SXjJr45CckYe5CZhN0bd9DcXL1cNtC/HX3uwjK4aNxJFoG8f7fPSV2AuJtfNuaYIf4xP5bZ82DRexOCEUHxLiLE7GIm4eP2FF5xs39UG4iPnXyjGuUbU18/vLJP26eJGKZH4Bn3DwrxIS4eYaIZXCLiWtMS7hdyhEhFuOeGHDVaPPMEY/tsLxP5HFzIDbXtwxuo1lHeojNR0t90GPj7A7x7QfrSeLmtrqSdo0dLZWmIhyI7eJuK52XzoJasqBdKrEG2nBNGWXT0X7q9Uxf8NmL21shdFKgaf1X3XMTtOGJK4OmErQgs1RxVkLBIGg/Ff2fvwVi54np1ARNIuhwmGqcvhro0GbQ5OjlgTAIGo6OwMjyGdUBHcgMmha6KgQF0FjiMMHCohN0EeQoHJLUPDoWTSuDDkHQgcRZCYUsaAjaEA7DDBqOzhh0tmvQGkBqYmAy3oCgzTUNdcDR2YKGoE00zSBoP5qGOuDoPEFD0IaaZhC0H01DHXB0hqAhaHNEDIL2o2moA47ODTQEbUXTTO/KHaWqaagDjk6ruqONJVBAotOp/1aaMpRnm/dZAAAAAElFTkSuQmCC",
    "AL STRAYA":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAFTUlEQVR42u2dPWgUQRiG78bBNMbC4mwCWtgodtoKghALFWwCgnaCooWVYGwUrSJYWSgKdhZCmoAKGhAEK0E7URALhRQmRQq1UZJosXFYd29nZ2dnvm9+3q/JJbnbmX32vWdnd+duh9+enx6g/JcAApqSxY89p16Dhaf6/PgQEg11ADQKoAEaBdAADdAogAZo1L9D8MDrwv4drc+5934VoH3BbXp+gNBl7Hz1C7n3fnVq997Kf5e+fMwatBPE45a5/OTnTiTaF+Jyndi2PBgMeHHLtBHXcXPpW2RCmbdRtkRzrW25deJoi9woc3VD5klZdcZJrusjSOZEB0WZuEsiZ8qUHZOZU3bikLZDTUw3SGzUEXicaTopQJmmq1BHEuqIKM6+O4xEx5/o6OLstdtIdOSJjjTO/jqPRCd0wIIC6MhBRy1oT6uAREMdAI0C6HDLyxWW4mqFumRZvgDx59cP9Xhx7hz9Ck/PPlCPhxOT6SeahTJjux6vGbJM2oSj//MGV6wqrZc9hp0hEo0KE3Qg3uCyBxINdQB0H28EWDR9o050CIJm6QnUAdAAjQLovEEHdajCddiCREMdAI0CaIAGaCCgKeavkTh281H516UPr9TjqX2H1eNn184YLqdpCYbLQaKhDhSBOsZ+qr/PLIP6m51+CbEm2uQrFpBo7+Vq78S4l6MAjblIAakDG4Nu1KEmbZZncoZQqj8E00oxvMM4GqBRiYOeX3yr+RWgx+9/7CgruJVfKXsSNOj+u/WZ6YMKseKr/sjbt9TUMTN9sEzWCWU4uiXacVEmBe3wsKU/ZcpDFQzvoA6ADscecXkDic5AHVyh5mqX+grLcGLSZOrm5TtPrZu4fel4OMcpQaiDPlyM+4Zhcad74vuCq1BfPLCr8q+TM0cdNrQw/6Lyl7vvvhLHubgvuKk6nM8swM6QdJyXT+uCd22LN7L+ze7WG1zb2FQdlJZYmH/R39QON1j0ow5NuHpiano5o7KYZyoNJybvvvtaH3soWF2jrdlCvLft5L+foYZ1GZyeeOs7gP3mqEHcOFLPur9MQrgFbSgnlQrWPpYcyI1+Azp754N1OLdTDusuyoq1XiMmxThkZgO99vu7+ZNfzp2fnn3QB3fx2sW5c0eu3u8AYuv2iEF3Qqyq+Cy8wl2UHnr5mXYf7S+66g+3DI1yHXcdpf4l/fvsA7fkQryxvmaOe6A9ldzEt6kJsUW29t85axksYudprXRAj9t5tGX4iD0VMW5JQ7mOeDQa+UbZ1MTKygo9bpkkYpMNQIxbZoWYEbfMELEJbj1xi2GJdEs5IsR63K0B7xptmTnisR0294k5bgnE/fVtgrvXadKN9bUK5dFopCg/vHU9dtyVxNTX17zaZyqNjXNrihXls1duDOKvir7Hprsp0cVMJeFjy5ezHHuum9axq2CFj+YrKU6DtSFul6BNPJUqa+vzNqLnsUnOrL0nGqwtcmkP2tBW6bG203Rn0BYDyVRz3QmF8CRo+JrU0RmybkqnJWg7TyXD2mL1u4Huf9GvzDqBo3NzIIJA0GkfnQfn6DrZNM43GWbUBrSdoBOj3BVCB9B9BJ1wlg2xCAJBZ2IMZkfnSbme1M6gO7kpbcqdUJiCthB0Plk2gSM8CRpepnA0KPcFbXEOOm3KGiAVMQgTb1ifg84ny62INicnqO89+fLpjau2YQy2cx0A7fEUR/JlqOlNdRTfe+JK0HnWxvqaZko11AFH5wkagu6paeF8BJ25pqEOOBqgIWiHBxkCgqbRNNQBR+cGGoJ2omlhMSREWWga6oCj06rNT86ikOhE6i9M96kn372rMwAAAABJRU5ErkJggg==",
    "TRUCKER MARK TAYLOR":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAE10lEQVR42u2cP2sUQRiH58bBVBEsbCRCCkHOWgIRFYt8BYMQqzRGtBDB2FnYGUEsFCKIlYLoF0ghKBoMBmsDYpFCJGAhmCoSjcXButnb3ZudP++8M/N7CeQuWXbfffK7Z2fm9tLbWpkTKP8lgYCm1ODb8YvvwcJTfX1xFomGOgAaBdAAjQJo6uFdMjUx2R88+La54W/nwzXycKplFz56hTpQUEeX8voqtNm5isIS/SOjt9n4gUR7g9u0PUPoKna+7TvhQ1wlhrh2n11xD4/B7NWqUkVsjzupRPtGzAe3yoRy+aAjWfsYg6l8EIeNtsyNcqg2ZJ6U6ZuR2VImbknmTJmyMZk5ZbL2sEyakDqYx5mmSQnKNK1CHUmoI6I4+24YiY4/0dHF2WvbSHTkiY40zv6aR6ITmrCgADpy0FEL2tMpINFQB0CjAJpvebndoOWd/L2d7eLx2vIi/QlPLywVj3tj4+knOgjlgMeFOlIEXXgjVKwqRy97DIlGolE8QTPxRih7INFQB0DbeINh0fRGnWgOgg7SCdRBVLZrHS0f+Bf42D4SDdBQh4UcWE1VKtfDwarp3s627yVTJBrqAGgUQAM0QANBHMM7yzp34+G+weLnt//nnCfPF4/f3b+muZ+mPWjuB4mGOlBRqKNSwy92+j0g0Ui0Rbm6OgW8yiHRAA3QnqpYgSzfycmhin4IbitFoqEOgEYlDvrpy9ctTwG6/vpjRrmAW3lK2Qlr0PaX9fnZmQJxwbf4YdjeUlPH/OxMmawTynD0iGjHRZkUtMNpiz1lyqkKhndQR4q1b5m06dZQVzeF9sbGB7eHTS8sBbw9jN4bSHQG6gi1khfquMqHInTs0V6X7zwzPsTj25d0Njt2YorsrAOrgz5cARfEA7xnqBNqzVQaVxHnlEFXIkY2/CjHmf7DNWHUQTmuYnJ0GfxsabwZZOzMbhztmzWHN4Ulk5ewPxah/okSr0T7Zs2EMgt1+GPNhzIXR/tgzYqy4LOo5JY1N8qC1f3R5RnjgJTBXKbyR2JCWXC7Eb0yO++Ee/h1wIcyEejd37/0N15fvlVBNhJ3rWrWlhenrtztAOLgoYhBd0JcZjSMT1/cZosng1b94VbcKLfj9oGYBrcKhfjvn91O7FqIN/FtOoQ8oEb275y1YovYeVorDbTjdh5txR+xpyLGrWgoDyN+MHXaN8qmQ1xf/0CPWyWJWOcPQIxbZYU4IG6VIWId3O3EDYYlyi3liBC34x4Z8K7RVpkjrm1Y3yf6uJVDxJ9ePRJCnLpwVQfxmZtzQojVe8+1GBw+KoQQP78737i2ja761sFtNeqoHRdHF2S3V0tz0LVx9ieK1SdvGnNX9yvLjclwK4dqS7hqr5adhiIKiN3ibiqT9wxZLVmEXSpxBtpyTRlllWiUQS7NQecmaMsT7wwagjZDISFoODopTRuCzlbQOqc/MdkvvgxBQ9DGQCQETVMKCJzX5pePw4seJo7OXNBmEDqAhqBtsEgIGuPopEbTnUFD0GYodEFD0JZwJAQNR2cMGoLWB1IRg9TxBgRtr2moA47OFjQEbaNpCUHTaBrqgKPzBA1BW2paQtA0moY64OgMQUPQ9ogkBE2jaagDjs4NNATtRNPSbOaO6qppqAOOTqt6WytzoIBEp1P/ANwCVkJW1TxCAAAAAElFTkSuQmCC",
    "TARAS JONES":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEUklEQVR42u2cPWsUQRyHc+NgihALOyGIhYVJYSsIoq3fQIgg0UbBxjrBQmJtY2Fj0ljkG5hSEQI2ghbRwiIGIakVi0h8KQ6Xc+92b3Ze/7Pz/BrvNNmZfe53z+zunTs43F6eIeGjQBAnevjH+RtvYBEon7eu0GjUAWgCaEATQAMa0ATQgCb/TsGF5+KZuak/8+HgB6BDwW36eYHQG0EvnFscffp176NMvu0bkUNc51th821KwK37ilga7kbQcVwRGrEc3H4abSf0mJRHB03CWvfSFQKrrUqjnGoafhptLnQhlONrRBXY5dqUagtM9qAFUh7m9NF+f0CLpRxtet6OOqo3YLST9byiqHOcSSoox5mqN3VgjJSNzqjOoSfMR1n5Nzq7OgedNo3OvNGZ1jnc5Gl0j05YCKAzB521oAPtAo1GHYAmgJabIF83aPnE88/R9+rxzsZq/B2+fPtx9XgwO9//RiehnHBc1JGhOsyOPefe7x2mqlVV6nuPnjs60BJ0y3cb+OgEdQBa5HIkwtH4AXWkzMK5RV/fzAM0jeY4upx4XLpoNOoANAE0oAENAkADmgAa0JyCJ83V+0/+O+XdfVU9Xli6Vj1+/fSB4XaatmC4HRqNOkgW6qhl/M0efws0mkY7xNfqlHCVo9GABjQBNKAJoAFtmc0XL1ueAton5Qpu7SmgvWXl5vUKccW3+ktAe2Y9SjYjylkuhkO+eVFOA3r0P6A5agTQBNBFgXa3R3aj0+i+g05V6lTjCv3G/921Tevffba+QqMTlyvh2pCg0YPZ+dGbSWTUyowXw5gVS3uokwZ0zDuSCBldJd/bOEWrRkn1Gos4jg7NOq000oMeLVc4FqluoiSr0aFZC6EsQh3hWMuhLMXRIViLojwj56KSX9bSKM+IutYxesY4JGVxU6DaiySE8oy0i0q1s/NOuMffB3IopwF9/PNby7++3VirIZuKe6JqdjZWL91Zbx5nruhGV4zG8ZmLW+ZdyHyCrt33sL25drh9IX735aANyslTeTTaBPHvX8ed2LUQb+LbNIQ6oafO3ztrLRZxOCEMJ9COe7gjHnFr+YgDJTJuHYfyOOKlsxdCo2waYnf/U3zcupeITV6AyLh1UYgT4tYFIjbB3U7c4rBE+6WcEeJ23FML3rXaunDEEyds7hNz3BrE7vo2we101NE/xO6rpT3oiXUOh/jWw61e4ta+ptLvTFwtOx2KaBD7xd0Um88MRV2ySHupxBtox2vKxKnRxKKX9qBLE7TjjncGjaDtUCgEjaN7pWlL0MUK2nr3u4FG0NZAFILG0b3StA3owgVtB6EDaATtgkUhaBzdK013Bo2g7VCYgkbQjnAUgsbRBYNG0OZAamJQJt5A0O6aRh04uljQCNpF0wpBx9E06sDRZYJG0I6aVgg6jqZRB44uEDSCdkekEHQcTaMOHF0aaATtRdPK7syddNU06sDR/crgcHsZCjS6P/kLfVYDxIDI65oAAAAASUVORK5CYII=",
    "HARVEY FALCO":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAG0UlEQVR42u2dfUxVZRzHHw4PLzIvCYt0TCQNVCTM+UZZOhutfNvctIhSMWuWMlrOqEmzVdbK6cZyw2KriJWV6ZbpRFkNY4AIgjPSzCFTgUIzWhmm6L1c+uPY8Xpfzz0vz/Pcc76/fzj37nDO73743s95nuceIOpizTKCMr8kIGBTVP6SUdAAFiZV587ZSDTUAdAogAZoFEADNECjABqgUf9PwQWvBffdEXKfA+2XAdosuIH2FxA6jXS+wQ8iDnFqMcR+jykCbmpVxKLhptZGLA5uySaU+Z6UW6J5vVqO0ZbsRplXG5I9KbNvRrItZcYtSXamzLIxyeaUmbWH1TsLOVrwOLNpUgJlNq1CHZZQRwTF2eyGtU/BR9+d5ff5X8//gvwyTXTExdnUtuFoRqVdHcEVEaFxVpo3fG0PibbQhAUF0BEOOqIFbdJLQKKhDoBGAbQVJyxBKshof+h6v7J9rGoj+xc87Zl3lO2oOAcJvGhDyGUrJJoLZY7npXhTs1luZJpoxRu8YuV1dk+P4WKIUQdKTNCCeIOXPZBoqAOg9XhDwGLTG+txtAiCVjrxnCUaVYHmmVAHHG2twhScwYQefyXMYuoQaqrCa9qCRONiCNAogAZogAYCW0xY7i8qu220f6ru1qLBpLnKdvMH61UeJ9ARVB4HiYY6UBGhDq/yfbOzPwISjUTrKKOuThyvckg0QAO0SSXftEluv5NThFL6UTpEopFoFEADtMaq+OxAkIcA7f/6o42yAtfrIctOhAat/7K+pnCBgljhqzzJtzerqWNN4QJPsoZQhqNDRDuyKDMFbeC0RT9lllMVDO+gDoAWxx6R5Q0k2gbq4BVqXudl/QlLVJxDza2bq16r1HyKT999Vpx5ihDqYB8ujtcGDp8Zqgm1ylQKPu0W6GLIMmJ8hzp8QLMPFPezS9xfLZugcRk7CzeONpu1CB8KS4K8hc1j4ftHlOyYaLNZC0JZCHWYx1ocyqI42gzWQlEm4iwqGctaNMpEqPujPWeMMikNv2nr9UMShDIR7UZ0r9l5WLh93wdpE2aK8y80WIB23fhH/c4/Vr3uhSwkbr+qOVa1ccqqt8MAEZsYwaDDQuzJyBefenFr+9V+uVXzcFPRKAfHbQZiNrgpL8TuQVdY7IIQD8Q30CmkaBqyf8NZU2ERG55WrwaC4zY82lR8xCYVY9yUDWVfxH3dbX737K2rNgploFPcOWY6e9xUHMTMSm6AMW5qK8QccVMbIlaDOzhxDcMSaizlCEIcHHfIgIcbbWpzxH4bVu8T9bgpEOvXtxrcukYd1kOs/2qpHbTfOJuHOHXuQkvipka1Yu3ye7UMayhCgdhY3IFKy2eGQi1Z8F0qMQy0zjVllK5EozTkUjtouwla5wsPGzQErQ2FBEGzKQ73dcx5bG32xLHy9uwHpzyd/yghZG91/db3v9i3a2tyUiIhJG9hcW11ued3fbu//pu9PyQkxA8bFr9h/YqRdyUTQvYfbNy151AMjXa6Bp9c8sjCebNE0LTf0bRG0HoEHUOjP9z2qteTDU3t+Uvympp/WjT/Id9vOdp26rvalo/KS+PiYptaTmzaXLm9rKS59eS+6obtZSWO4Qn9V66+vGFbSsqImdMmsdF0uKNpyTwrqa+BgRsD164vXjSn8Ui73x12fF1TtHppXFwsIWRWbs7o1BSXa3DHVzUvrs13DE8ghDiGJxSveeLzLw8Kq2lJBEE3t558IDcnPW1U78U/nU4/rZ891zs+c4zysLRkJaXR57ovTPB4cuL49LNdvXD0rXK6Bte+tEXe3lBSmJ42qv7w8Y4zPbV1bX19fx9v75g53fvt73a7Qx52aGgoikQJMpr21TTVZig9fXg52u12d/f8vuOTN+VoNx5p9wU9Jm3kmc7u7KxxMtBNmyvfKH1uXHrq6Y6uyfdmyPucPtM9bmwqy9F0WJqWzPBRWNV+ojPznjR5e0rO+JbWn333Wbr44YqP99xwuggh3x86KutlecG88ordV/69Rgjpv3J1e8XuFU/NF3Y0TbkLuv7w8elTb/5ruvj42KQkx/muC07X4PPF78lPTs7JLH7h8Z7fLq1c/daIEY7kpMRX1i0nhOTOyL70x19F67bExFCnazB/Sd6MqVnCOjrqYs0yQkhGQUNI0MqPzraTb69S1OH3QwBF0507Nf1TMlDWhkIy1kRY9AgDNJY4zCisRwsJGoJWD8RLDJIab0DQ+jUNdcDRtgUNQevRtARBs9E01AFH2xM0BK1T0xIEzUbTUAccbUPQELR+RBIEzUbTUAccbTfQELQhmpa0zdxR4Woa6oCjrVU3b6BBIdEWqf8ALaFBL1DQGasAAAAASUVORK5CYII=",
    DOOMSLAYER:
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEr0lEQVR42u2dvWoUURTHd68XA8L6BCksLDQvEAiIFnkEIUJsgkVS2NjEwiKksDCNjYWp0lgY8AEipFCEQF4gilikSJHagKDEj2LlMszOzt7Pc869938aZ8Myc+bnf3/33pnZZHh+sDpApS8FBDSlx//cfPAJLPxq/sbtzp+fnX4eb3x7eweJJk80yrtMcuFoDIYAjQJoDIZSZ1qWgxUSjUTXtxgJ+XAUBVqIJTID3UzTo8XhzPdv759AHT5lA7dZWysL0aFH/IiIA93kFb4TOTHXhSHu3KcE3LpUxNJw67IRy8GtKqHMe1C2RHOdLWO0VW2UudpQdVKmb0ZVS5m4JVUzZcrGVOWUydqLOetoXgaSfCGt2Hm08DjTNKlAmabVmOqALtgSnVGcUzeMm7P5Jzq7OCdtG4nOPNGZxjld80h0QQsWFEBnDjprQSc6BSQa6gBoFEDLrSSPG/Tcyf/788JsH+1u0p/w0vqO2R7OjcpPNAtlxuNCHSWCNt7gilXr6E2PIdFINEomaCHe4LIHEg11AHSINwQWTW//V4Zk36KWIGjTSXOVCHVAHSgPdeBpLiQaoPNcqnAtW5BoqAOgUQAN0AANBKQLFq66++RV8+XZyQezPb9wz2x/fPnYcj/T9mC5HyQa6kBloY5WTX7Y6feARCPRARVrdGIc5ZBogAboRGUe2qS8R2dTph+Cx0qRaKgDoFGFg97bP+x5CdDd448fZQO39ZKyE9Ggw4f1tZVlg9jwNT/k7a00daytLDfJRqEsdAke8a84hODe2z/MizJpoiMuW8IpUy5VML0TrA48opdHooVc9KD3BtRRwcqQK9Rcx6W+wzKcG9k8urmx/cb7EK+3HspZp4hQB324GMcGhnuGNqG2TKXwZXcQ6LiLw6X1HbKn03mnOjzqoA8U+9EV+9nSBI1l7hykjhSLw9QCkXBTWAn5CKdjwfVLlGStDFOzFkJ5IOEhx+ZsL65Dwil3fkXez58irnWkyLWcLAsCHZ21NMoDUc9Htxwy8Pqmbes/KZBysX9FubU6d8I9+TkQkmU60Je/vtu/+Xj3aQvZTNydqjna3VzceOEA4ur1jEE7IW4ymsRnL26/ecu41XS4tTTK/bhTIKbBrbkQ//l96cSuh/g0vtMOoa7omf1HZ63FIo6e1lYD/bijR1vLR5yoiHFrGsqTiL/cf975zovBj1gopx3i1rtn9Li1HMRkNW6AGLeuCjEjbgfQ5lLW6dfjrBHb4O4n7jEtcU50P+WMEPfjnhlw12jryhF3NmzvE3vcVqD7dVwA4kB92+AOmnWUhzh8tPQH3RnndIhH768ViVvHaqXs6hwtnaYiGojj4p5WPvcMRV2y4L1UEg104DVlVFCiUR659Addm6ADT9wZNATth0JB0HB0UZr2BF2toL1P3w00BO0NREHQcHRRmvYBXbmg/SA4gIagQ7AoCBqOLkrTzqAhaD8UtqAh6EA4CoKGoysGDUHbA2mJQdl4A4IO1zTUAUdXCxqCDtG0gqBpNA11wNF1goagAzWtIGgaTUMdcHSFoCHocEQKgqbRNNQBR9cGGoKOomnlt3JHuWoa6oCjy6rh+cEqKCDR5dQ/ySN6V34ZvF8AAAAASUVORK5CYII=",
    "DRAKO SAVAGE":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEn0lEQVR42u2cvWoUURTHJ9dDDIIBMVpFENkiFsIigdikEQx5AItAegWfIGit+AQp8gQp8gAhAZtUgSALFqYIQTBF0IigIFHiR7ES19mZ2blf55577/80yX7N3Pntf3977t3dGTveXC5Q/ksBAU9R/09naQcsPNXB+jwSDXWkqg6emr55u/L6o3dvtbaz39ua6S4AtK/a720N/x8LcYqLb8OtwomzgtZSRDPf6IhTXPmNlzglw1c4cUqPr0zilCpcacQpB74SiFNWfAMSpzz58hOnzPmyESfw5SFO4MtDHMukTAXQMYCOblEYiY6gLFMF0Eg0QKMAOl3QaDyQaEEtB0Aj0QCNAmjR5WA9eqa7kMl6aUPVfa0QiYY6Uuzt/qmjMvm636bNuRpZ4Rv/UEeyXYelJdB4INEADdAo570dQCPRAO37JQbQKIAG6NirM3PP8cywfWH5CYnOBnSSjcfZ6Zcw6oAloA6AjrloYhKgo+ntADpadWDFA4kOKehCwolR7ty933yHN69fcW4HiYY6UABt09s5FLQX0Gg8kOigDUzwEbhqBsI2FUh0+A4aoJFoAS1HHKDReCDRYQQN0Eg0QKMAOkvQ8TYenkaOREMdAI0y6c19y+78u2tHB3tFUXTnHhhv8GH3Vumajd6h8dZ6u9vn/093Zv1NVeJL9EbvcJCsDWWooxXu6CjH6mi3lBm8wQH6fPT94xk0Y8DiH4YKcpBhcQfZu8rqaAM+xyqfZFXujkfQRfBPwXu72zadtcAnte50YRygaWKyP22Z7sz2py3DCEq4b0xcMt7d+9NvEjQltL3zxCL4G68UddRpZDiVPp48H4Ku+tWavLOEOQygkCCLnhnaM5JGmQ90aX7olZRAyqLXOgx4aZmHrYOWDloXnMwgxwG6PUHhlFnbu8Fpi8HDp65eqbvp5NNns20i0dU0K6+svN7gXRqga7FaIk55ZjgyPr+/fx28uLv2tPJuiyurmy+fVN409+jF4MWxi5eFgB473lwuiqKztCNkQCXWDbibEcuhfLA+z5Tosx8aZ8vZW3tWQta/2IB7GHH//rOPn2u82sZjXo/WQlyKcCXu9g83G6o/3CSNcjNuH4h5cFMoxL9+nmmxayBex7duF+oCjRy/c9YkFrHztJYG0IzbebRJPmJPxYybeCgPI74+dc03yrpdfDj5yI+bkkTc5glgxk1ZIQ6ImzJE3AZ3M3GDtoTcUo4IcTPukQHXjTZljrhywO190h43AbG9vtvgtuo60kNs/25pDroyzv4QL66sJombXA0l7ap8t9RqRQiI3eKuK5PPDEUtWYRdKnEG2nJNGWWVaJRBLs0dnZugBw98pKaHf2ChnWgI2gyFgqB5ioDAuaZpfPL/H1hY/LQiW0EbH74eaAjaGIiCoNFHJ9VNm4DOXNBmEDRAQ9A2WBQEDUcnpWlt0BC0GYq2oCFoSzgKgoajMwYNQbcHUhKDauMNCNpe01AHHJ0taAjaRtMKgubRNNQBR+cJGoK21LSCoHk0DXXA0RmChqDtESkImkfTUAccnRtoCNqJppXZzB2lq2moA45Oq/6eYBCFRCdSfwC2l3p1Sv/FoAAAAABJRU5ErkJggg==",
    "TRASHBAG DAN":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAFHklEQVR42u2dz0sWQRjH33cd+kUKHkMPLxShEXQSLwr9AR2Cgl6wW0JCnpSOFegxtEuBgd0MDAo8dPAY5O09BZEdCjwoeRMSsuI1Oyyu++7uuzszO/PMj/0+CLq67sx+fN7PPDO7+1rfXZ+oIfRHAAQ0wcJPl5ofwUJTfFsdPwGNiMdgYzjxne2tTagDjkakHY1QKwpkNNQB0AiABmiEtVXHWXaku4mDdh0ZDXUgXFFH+/dPrv3O95rqCTvTh4yGOjwK3teczeqIzmFn6nX+nkMrU7pPNd2HgSW6q0u6QH++uxjf3G8fGM/cdB++Ti5n7nl1ZcbbOtq/SFw9gKMrNjNsNZ8BNEImYlcPxqEO1NEAjQBogEYAtPPl3dDyZPhF4SqHDREteuhbMkVGd4S+lbxAa3edSGeafiKjMRj6ZQ+AJrIHQDurDudGQhp7IKOJ7AHQqDoA2m9Ba9I0MppI0wANR/tlD4AmskegIwVcHwmhDoftYe4GmnM9Ztr9dchjD+U3miKjoQ6A7qqh4yublDd4u6JpZDRRkQfQfjvaVMnB3bTyOz0Ug/ZS047X0c5G/OEU/veqgaNRR5sLHbfiQR3CIffWVuozGuMh1AHQvgsaoJHRmLBwjofhotfA0kT+6szFl/c6BvQvH07mBVeuR19/v/8qv8XoON2OwHkcvzLa4EJHUQf0PcwCdbisDvllhNSLnf4IjqkD0xa7MlrV6KTkOFqfNoSjUUcDNMIu0G6Nh7ofB0dGW1l1yF0uQ6jM6MHGcPihb/49/+lpzqblywC61MEFXZxyBDexabmghUFvb21GHzz7N4ZGVY2Hj649jBBHfKNvVmhmSKDsEKuLlDWqQyjxJXC7RdnV8k4tZQJBU4BOTls4nmygCPJuBGZO0ixuE60HlTpbg3/joEKZldUcjaAtGAzJWJseGyiusBTcfRAi6JwT33gzK93c+zsLtlG2qbzTxML4wEuZ0QJQjvM6Iys1/PHIBG3fhEVhAlpSsFs9MyzPyDLKdKCFL2uVIWUf5ZrVax0SvETMQynomu2LSkLKtjKRHQHNT9BuyqTlXXzaIvHrOzOrXSWw2LQ/W5xZj86kObDYLEmZRtA1txb+E1idSGQzM8PC9Dn6sx/ffDf3IL1Pq7YxsjfW6t9Ym59O//TW4xfxzfrp3iqCLoz66d4465BaGnerf6MQsVWUiUC3/wq8W87a3HQCWTfcOYjD/W8+eS4A4lSfw6CFECeMkYmb/9fluqoPN7ONcj5uHYhpcDNTiP8dtoXY5RDvxrdbE0EPK+y/ctbMWsTKszXRgXzcylOb2Y9YUxDjZjSU04h/zL7N3LNV21CFslsTFxZu0+Nm9iAmi7ADxLhZpRAbxM0qiJgHdz5xibKEqaXsEOJ83IUJLprarOKIMzvM7xN+3AyIy+ubB3epqsM/xOVHS3nQmemsD/HI3piXuJmqrvgdmaOlUCnCgFgt7m4hc83QqiULs0slykCXXFNGlMpohEReyoOumqBLnrgwaAhaDkUAQcPRXmlaEnRlBS19+mKgIWhpIAEETRP4rxVaNN24PKrA0RUXtBwEAdAQdBksDILWEZ3vcTSOOpqumhYGDUHLoeAFDUGXhBNA0DQBR1sJGoLmB5IQQ8DjDQi6vKahDji6sqAh6DKaDiBoGk1DHXB0NUFD0CU1HUDQNJqGOuDoCoKGoMsjCiBoGk1DHXB01UBD0Eo0HcjN3BGimoY64Gi/or67jn+Qjoz2KP4D2V7C22le5dgAAAAASUVORK5CYII=",
    "ELI DRIFTWOOD":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAFUUlEQVR42u2cy2oUQRSGZ9pCszARBHdZxGhIhhBI9sk7jLgRgvMMkheQbLIUn0E3bmSyzD4PkIEsvGASFy4CghCTxSjjZTEYh56+1OXUqVPV/0GQ6KS7+pu/v7r0pX1+sN1C+a8MCHhKjf96+OQwsQObX+jk/uXL53dBWvLpzdZ/0OlVKKxQB0ADNAqgARoF0AAN0CiABmgUQAct72sdo+F36Qhm5pBoqCOh4jnnFM8x3Jm9LRDxxeUVyXau174r1maRaKgDo44kNe0y9tC5mtPoRHP2HJnXmEjuCeHoNAd5TQfNdrYh0ZGrI0ZBe7UHEs0UBYDGqAOgMciTAjq6npChnUg01JGWPQCayR4AHa06Eli082EPJJrJHgCNUQdApy1oT5pGopk0DdBwdFr2AGgme2Q+IoD7C5DoYPYIdkvY8wf3g+x39+RMxx5UN5oi0VAHQNdr6N8NmeTnXQKaRqKZBnkAnbSjy4Ycj/ZfEe6lcGuao51r+1E9HEcM2kXTYy5UrGm3lo46Jom406HdWjqgp1m40KHdWjqgyyjY0SHZGrmgw4OuPn5T1rRbk55o2mmLPh05/V4xFrFxnvxYv9tj25RmTb+S87oKHzvMhFMmd0Lth30IOhhoi9OcsM8cHB82Qh3Wxzl94lt7eXB8uL625XIUpi+Z9ZLoiv7QMU2EMxHmXHOrwzFHhHPrwpZ4EnQYR/e7Pceu35Fyv9tz/76jmbBQDbNi2a8v0DrTln6311ndZDvUzupmKMrhp+B7S4s8B9/v9vaWFoOMoMPPDHOns6c5dMAUC0q0byJCKLekvVOJMNpyEHtPtPUynjsjiy14FXRL7FVwF9bSsixRHY4akYk4TKJN723UZ2dEmf8WywheMFgbbfcg+xa090QTXtYqoylZF5EluizasSAWPeqoxR0X5VakNznSUmYQNAfonKZ1nmxgKE/NmF/oXP8Jn+jdk7OwuIPsPWvU0Qb8jlXYZHFOHAoR0wpa7jv+2fIVvG/gSLSamRs/cnNxeTX9bMgYQS7ar79+s97d03t3pVEWNLzzxCJ4xytxZjip7OlU+vjyeEbQEicshAEUEmTRM0N3RtIo84E2XcZzISWQsui1DgteRubhFHRL+KKSETiZQY4DtD5B4ZRZh3eT0xbT390ZHL9YX6v4X/lxiWY9upDmzuDYkTKPoFtxLfznsEYR5DAzw9r4/PlxOfnj2+WVgg8NR6czanE42l8peADt8Yf3kz+2b802EXRttW/NTrIeU5vGvTgc1SIWRZkJ9Oinwdty9pc7OWRluCsQjz/f/Wjw4JS6ORcxaCPEOWMU4tb/dbum+sNtBnrymmPtg3Z2lKtx+0DMg1uFCvLvXyMjdhXEy/iW7SK7oWrbT85aiUVMntZcA6pxk0fbDHSFLvwh9lTMuBVPkKcRv9zYKP7okOzLKNvFs6MjftxKEGKuGjeAGbdqFOKAuFUDEevgriZuMSxRtJQjQlyNuzbgptFWDUdc2GB9n+jjVkDsrm8d3E6jjvQQu/eW9qAL4+wP8emMShK3ompK2lXYWxoNRRQQ0+IuK5trhqKWLMIulZCBdlxTRjklGmWRS3vQTRO044Ebg4ag7VBkEDQcnZSmLUE3VtDWh28GGoK2BpJB0HB0Upq2Ad1wQdtBMAANQbtgySBoODopTRuDhqDtUOiChqAd4WQQNBzdYNAQtD6QnBgyHW9A0O6ahjrg6MaChqBdNJ1B0Dyahjrg6GaChqAdNZ1B0Dyahjrg6AaChqDdEWUQNI+moQ44ummgIWgSTWd2M3eUqaahDjg6rWqfH2yDAhKdTv0F40wRrpPqj1MAAAAASUVORK5CYII=",
    COACH:
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEkklEQVR42u2cq29UQRSHd4cJVSXBl6SChBSHwTVZQ6pwCLIrMMUWXQQCQbFUr0HQIHAkpKRmk/4BODAVCEQdCShIeYhNhuU+53nOuTO/E5Jum+Xec7/+9pvH3u34/Hg2QqUvBQQ0pZdfrt8/BYtEdfZ6G4mGOgAaBdAAjTKzjtXa2Nzq/W9fPn8COyQaoKEOaAGJzjfRAuvOrau9zzn58BWgU8Fte75A6HrofLsPIoe4zgxx4zEl4Na5IpaGW+eNWA5uVQhl3pOyJZrrahmjrUqjzNWGKpMyfTOqWMrELamSKVM2pgqnTNYedu8ycrTwONM0qUCZplWoIwt1DCjOqRtGooef6MHFOWnbzZtKlXto8L643EQPNM7pmoejiapZHXAFEg3QuQg60SUg0VBHCYMhKvrCAokecqI73sn/8+O7ebyY79Nf8GT3wDwer63nrw4WysvzrrK2rPCFBdSR46zDeIMrzpWzr3oM07usB8PGjxpiA2QYiRbiDS57QB2s6oAlhppoyvFdZm/UCxYJgvZbudQnCE6vezga8+gSBkNU9AkCEp2ROkQtVbiWLc7qCBx8kWgUQJc564AokGiARvH/GYm9F/956ePi3/Tm5sQ8Pjl8ZHmctiNYHgeJhjpQg1BHdTVUe7HTHwGJRqIDKtboxDjKIdEADdCJyty06XF3YdIy/RDcVopEQx0Ajcoc9Kuj9x3fAnTz+ONH2cCtfEvZiWjQ4cP6bLpjEBu+5oe8veWmjtl0Z5VsFMpwdE+0I1Le2Nxa/ssEdMRlSzhl08O1G7eR6Kyq9HvvyN7UJ020kE0Pyi0OqKOYWQdXqLnOS+3o8dq6za2be09eep/i8OkDOesUEeqgDxfj2MAw67AJtWUqhS+7BQ2GlBHjnerwgKYPFPvZFfvV0gStPnc2WxwEGx1S5tGpWUt4U1gJeQmnY8H1R5T4Zx1tM5DJ7kH0j211UCb+6AK/OtLlWkiWBTk6BWtRlEdyNpXispZGeSRqP7ri65HXJ20rvyQhlEfSNv4rq3Mn3PXXgRzKRKAvfn6zf/Lp/HEFWS/uRtUs5vvbD585gLh8ZcCgnRCvMqrjsxe33xxx2Wo63Foa5W7cKRDT4NZciH//unBi10G8jW/bKdQl3dt/dNZaLOLoaa000I07erS1fMSJihi3pqFcR3z33jQ1yrZTvH1zRI9bZ4nY5hdAjFsXhZgRty4QsQ3ubuIe0xIdl/KAEHfj7g24a7R14YgbG7b3iT1uDcTh+rbBHTTryA9x+GjpD7oxzukQP393liVuHauVvKtxtHSaimggjou7rXzeMxS1ZcG7VRINdOCeMioo0SiPXPqDLk3QgRfuDBqC9kOhIGg4OitNe4IuVtDel+8GGoL2BqIgaDg6K037gC5c0H4QHEBD0CFYFAQNR2elaWfQELQfClvQEHQgHAVBw9EFg4ag7YFUxKBsvAFBh2sa6oCjiwUNQYdoWkHQNJqGOuDoMkFD0IGaVhA0jaahDji6QNAQdDgiBUHTaBrqgKNLAw1BR9G08lu5o1w1DXXA0XnV+Px4BgpIdD71Fy00UaCR/S1YAAAAAElFTkSuQmCC",
    "APW OFFICIAL":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEuUlEQVR42u2dz2oTURSHk+vF4qK+gF10IWJ1JShZqFAQ9A1KodsKdRv3LtybdUAfoPgEVRAK6qIquDMqLgJm0bUuRKnWxcAwTDKTO/fPOefe+zsEmpQwc+bLb76Ze2dI+scHOz1U+FJAQFO6+HNx+zVYBKpv+7eRaPJE09fa+sbC/8+mEzgaBdBQR1OlqghxoCnVL+FDhToAGuqQXGLVj0Qj0ZW6d/Py0ve8ePuZfnhlvg/pqOE2vT8o9EQS3ZVv+0LkEGcA3bQbXr1wGuhjc8ftfowVkegQiEPgjhh0aMRycDOc3s2mk+JBSdnvMSCaRHNtLWO0VW6UudpQeVKmb0ZlS5m4JZUzZcrGVOaUydrD7F1CjhYeZ5omFSjTtAp1JKGOiOIcumEkOv5ERxfnoG0j0ZEnOtI4h2seiU5owIIC6MhBRy3oQJuAREMdAI0CaLkV5HaDliv5p79/ls+PxkP6DR7sjcrn/ZXV9BPNQplxvVBHiqBLb3DFqrb2qseQaCQaJRO0EG9w2QOJhjoA2sUbAoumN+pESxA0SydQB0ADNAqg8wYtaqjCNWxBoqEOgEYBNEADNBDQFPPXSNwajqsvZ58Oy+drVzbL529Ge4bLaVqC4XKQaKgDFYU6ajW/s9MvAYlGoh3K19GJ8SjHDLr6nWvfv7xDoqGOhECXN21W7+SUUGU/BLeVhlJHbt8sD3UANECLrWfPD1teAvTi448d5RJu7SVlJ6JBux/Wd7c2S8Ql3/KfvL2lpo7drc0qWS+U4egl0Y6Lco9yrqO/slrcPjHYGzne4OFO2XGo0vLbCk3DCJzeQR1pFek0qUd7sHjD5ddYkOjU1cE1k8e1XuorLKU92uv+433rVTx9tB1onOIyJcmpDvpwMU6IM1wzNAm1YSqFD7sFHQwpI8Z7fYcHNH2g2Neu2LeWJmiUlwflnkeHZi3horASsguHY8H1JUqyEh2atRDKItQRjrUcymyg19Y3ikc41qIo9+RMKvllLY1yT9T90dURY0HKYiq19iEJocwGuml2pjY674R7fj/wQnl+DtpuaokC9MmfH+Zv/jB+WEO2FPdC1RyNh9cfPOkA4uz5iBPdCXGV0Tw+c3HbXbspWg2HW0uj3I47BOJ23L5ui9VciP/9PenEroV4E9+mVagzemn/3qOtxSL2ntZaA+24vZtEy0ccqIhxaxrK84gnH18tfOev9y99oWxaxca1O/S4tRzEZFU0QIxbZ4WYEbfOELEJ7nbiFqcl2i/liBC3414a8ILD+qWB4QSDzhzxwobNfTL9etSE2wZ08ogd9W2C2+msIz3ELrjbB+vaLs7hEJ+7cTdq3AEHLCmluNPRstOpiAZiv7ibyuaaoagpC96pEm+gHeeUUU6JRlnk0h50boJ23PDOoCFoOxQKgoajk9K0JehsBW29+d1AQ9DWQBQEDUcnpWkb0JkL2g5CB9AQtAsWBUHD0UlpujNoCNoOhSloCNoRjoKg4eiMQUPQ5kBqYlAm3oCg3TUNdcDR2YKGoF00rSBoGk1DHXB0nqAhaEdNKwiaRtNQBxydIWgI2h2RgqBpNA11wNG5gYagvWha2Y3cUV01DXXA0WlV//hgBxSQ6HTqP511j+xIy2paAAAAAElFTkSuQmCC",
    "RING ANNOUNCER":
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEiklEQVR42u2dq28VQRSHe4cJqPIXIBA14EgwiAZsFZakIQVMg0SSIiFIJAEBucFgUVRCKjBNmiCoqaioqAYFKQ/RZLvcx97ZeZw5O/Md0972Zvfs199+M7O7bUfH2+tLVPoyIJApe/ph5c5OAQdz6fKVmV8/OtzP2NXB+9Uz0NGPLctB5gWKOgBdoaOLPFtJNKApQAOaAjSgmd4prZsrywvf8/ngB6BTwZ33foXQ7dD5dm9ED3FbGOKZ2+zA3VwUS73EtaUi7oW7/ESnRqwHt62EcnunbdZiF8VsPYjzRtvURjlXG6ZOyvLNmGopC7dkaqYs2ZipnLJYe1y9K8jRyuMs06SBskyrqKMIdQwozqkbtmQtXbUfTDTEWaZtHD1wRw80znGbPzrcby7DkuiCFiwUoAcOetCCTnQIJBp1AJoCtN5Kcq2j407+359n39odb8kf8PWNZ83nowvL5Sc6C+WM+0UdJYJuvJErVhN7b3uMRDMY1lTdf1vA5UlJuUQr8UYue5BooZMA0E4V/hi1EGjJ8d2jt1grlw6VS886NAhashNuZUmbGkenVXkDmkSzMiwr4xKgVS1Vci1bSLRQMRhKLAtJNIMh6qD6T6hXSXQ1ib7x8MV/Qfj26Ww8uXqr+fzLy0eO25m3Bcft4GgGQ2qIg+H0yS6/BRJNogMq1uiUcZQj0YAGdKJqbn22n+TUUE0/Ao+VkmjUAWiqcNCvxh87XgJ69vjjR7mBO/FSshPVoMOH9c2NtQZxw7f5Yt7eSlPH5sZam2wUyjh6QbSHRVkUdMRlSzhlyaUK0zvUAWg99hiWN0h0BerIFepc+5W+wzK6sOzy6OaDx2+9d/Hm+X096xQV6pAPV8axIcM9Q5dQO6ZS+bJb0WAoGbG8U508oOUDlX3vJvvRygQty9xZ3Tw6NWsNN4WNklM4HYtcf0RJV6JTs1ZCWYU60rHWQ1mLo1OwVkV5Sc9FpbistVFeUvV8dHvFeErK4zdtJ35ISigvaXsQfWJ13gv39Hmgh7IQ6JNf393fvDd+MoFsIe6Zqtkdb12797QHiPMXBwy6F+I2o2l87uL2+9X+01bT4bbaKHfjToFYBrfNhfjP75Ne7DqIz+M7bxfmnF3Yf3TWVi3i6GmdaKAbd/RoW/2IE5UwbitDeRrxu9XbqVHO28XdnQ/yuG2RiF1+AMK4bVWIM+K2FSJ2wd1N3GNaYuNSHhDibtwLA9432rZyxDMbdveJO24L4nB9u+AOmnWUhzh8tPQHPTPO6RB/fb1XJG4bq5Wya+Zo2WsqYkEcF/e88rlnqOqSRd5LJdFAB15TpoISTXnk0h90bYIOPPDeoBG0HwqDoHF0CZoO/a8V1Qra+/D7gUbQ3kAMgk5a/Asn6dm0D+jKBe0HoQdoBB2CxSBo5tFFabo3aATth8IVNIIOhGMQNI6uGDSCdgcyIQbj4g0EHa5p1IGjqwWNoEM0bRC0jKZRB46uEzSCDtS0QdAymkYdOLpC0Ag6HJFB0DKaRh04ujbQCDqKpo3fyp3qq2nUgaPLqtHx9joUSHQ59Q+h4FC6/0uDhAAAAABJRU5ErkJggg==",
    NARRATOR:
      "iVBORw0KGgoAAAANSUhEUgAAAHgAAACgCAIAAABIaz/HAAAEuUlEQVR42u2cvWsUQRiH98bRVLEMBFIkYGFM4z8QsIzYWSnpUmqKVAH9AxRSRYiWabWyE64UrLSyiV8IBgwYrERBUOJHcTgeu3t7s/Pxvu/M/F4E7/TYnX3ud8/M7Mzd4Hi4XqHilwICmtKjv85dewYWker9o1UkGuoAaBRAp9AZoka1sLjc8b9Hh6+RaKgDBXWElQMSDXVAHdJqaW5+6ms+fP4E0LHgTnq9QOg6db7dB5FDXGeGuPWYEnDrXBFLw63zRiwHtyqEMu9J2RLNdbWM0ValUeZqhiqTMn1jVLGUiZukSqZM2TBVOGWy5uHuXZrDu9Y1t9Pfv8gHsTQ3H3XAFz3RSVAmEAjUkaY6amtuwvtASoEg0elPWJKLc9RmI9GJJzrROMdrPBKdvqNRAJ0L6KQFHekSkGioA6BRAC23omw36Lgv8+fHN/P4YLhHf8Era5vm8WBmNv9Es1BmPC/UkSNo4w2uWNXOPu4xJBqJRskBvbC4bP4I8QaXPZBoqAMTFvsyi+KU/bvDWIhg5kKdaAmCZmkJ1AHQAI0C6LJBi5qqcE1bkGioA6BRAA3QAA0ENMX8MxIXr26PPz169dQ8XrhwyTx++XjH8jiTjmB5nOigm19bi/cLcEi0Y3X/nmdVVR/fvgBoWT9e1fyw0x8hLmiIIoFE+7xJoXonxl4OwzuABuhIZZY+x3dySijTngwXZ5FoVJwB679JBkAj0Y3a3dnveArQ7f2PG2UDt/aUsiVukwwi0P7d+tb2hkFs+Jp/5G1bburY2t4YJxuEMhw9JdppUSYFHXDa4k+ZcqqC4R3UAdBy7JGWN5DoAtTBFWqu81KvGQ5mZm22bl7fuON8iof7t+XMU0Sogz5cjH0Dwyq4TagtUyl82i2oM6SMGO9Qhwc0faDYz64Zr3YkkJW1TYKvXPiPnWsbsvpushAxjo79oZawKKyEfITjseD6ESUp6miOQGI4JCBlz11z/OqIl2shWRbk6BisRVGu5NxUCstaGuVK1P7omq8rp2/a1t4kIZQraRvRa7PzXribnwM5lIlAn/z8av/iN8P7NWRTcbeq5mC4d/7yzR4gzpxNGHQvxOOMmvjsxe02Rhw1NR5uLY1yN+4YiGlway7Ev3+d9GLXQXwS30mnUKf01PYHZ63FIg6e1loDunEHj/b/k3V/XXDqBDQe4khFjFvTBLmJ+MaVW7FRTjrFgyd36XHrLBHbvAHEuLW9HDJAzIhbF5Livri7iTsMS3RYygkh7sY9NeB9o60LR9zaYHuf2OPWQOyvbxvcXqOO/BD795buoFvjHA/x7r3DLHHrUE3Ju1p7y15DEQ3EYXFPKpc1Q1G3LHhvlQQD7XlPGeWVaJRDLt1BlyZozwvvDRqCdkOhIGg4OitNO4IuVtDOl98PNATtDERB0HB0Vpp2AV24oN0g9AANQftg0RB0jGruRoKjo9Thu+e+oCFoNxS2N/4h6G44zZWtsQ1Jq+2JhqAxji4GNARtD6QmBmXjDQjavw+DOuDoYkFD0D6aVhA0jaahDji6TNAQtKemFQRNo2moA44uEDQE7Y9IQdA0moY64OjSQEPQQTSt3GbuqL6ahjrg6LxqcDxcBwUkOp/6Cx+/VuVB0UtQAAAAAElFTkSuQmCC",
  };
  function portraitData(name) {
    const key = String(name).trim().toUpperCase();
    return (
      APW_CINEMATIC_LOCAL_IMAGES[key] ||
      APW_CINEMATIC_LOCAL_IMAGES["GIDEON HARK"]
    );
  }
  function stop() {
    clearTimeout(timer);
    timer = null;
    playing = false;
  }
  function showLine() {
    const v = scenes[idx];
    $("apw46text").textContent = v.lines[Math.min(step, v.lines.length - 1)];
  }
  function tick() {
    if (!playing) return;
    const v = scenes[idx];
    if (step < v.lines.length - 1) {
      step++;
      showLine();
      timer = setTimeout(tick, 1700);
    } else {
      playing = false;
      $("apw47pause").textContent = "▶ RESUME";
    }
  }
  const APW_V50_HERO_PORTRAITS = {
    "BIRDMAN PHIL PICASSO": APW_MEDIA[211],
    "GIDEON HARK": APW_MEDIA[212],
  };
  function render() {
    stop();
    stage.style.animationPlayState = "running";
    const v = scenes[idx];
    step = 0;
    stage.className = "apw47-" + v.type;
    $("apw46title").textContent = v.title;
    $("apw47namea").textContent = v.a;
    $("apw47nameb").textContent = v.b;
    for (const [id, name] of [
      ["apw46left", v.a],
      ["apw46right", v.b],
    ]) {
      const el = $(id),
        data = portraitData(name),
        hero =
          APW_V54_CANONICAL_ART[name.toUpperCase()] ||
          APW_V50_HERO_PORTRAITS[name.toUpperCase()];
      if (hero) el.src = hero;
      else if (data) el.src = "data:image/png;base64," + data;
      el.alt = name;
      el.style.display = hero || data ? "block" : "none";
      el.style.opacity = "1";
      el.style.visibility = "visible";
    }
    showLine();
    $("apw47pause").textContent = "Ⅱ PAUSE";
    layer.classList.remove("apw46open");
    void layer.offsetWidth;
    layer.classList.add("apw46open");
    playing = true;
    timer = setTimeout(tick, reduced.matches ? 1000 : 1900);
  }
  function close() {
    stop();
    layer.classList.remove("apw46open");
  }
  btn.onclick = render;
  $("apw46close").onclick = close;
  $("apw46prev").onclick = () => {
    idx = (idx + scenes.length - 1) % scenes.length;
    render();
  };
  $("apw46next").onclick = () => {
    idx = (idx + 1) % scenes.length;
    render();
  };
  $("apw47play").onclick = render;
  $("apw47pause").onclick = () => {
    if (playing) {
      stop();
      $("apw47pause").textContent = "▶ RESUME";
      stage.style.animationPlayState = "paused";
    } else {
      playing = true;
      $("apw47pause").textContent = "Ⅱ PAUSE";
      stage.style.animationPlayState = "running";
      timer = setTimeout(tick, 1400);
    }
  };
  $("apw47skip").onclick = () => {
    stop();
    step = scenes[idx].lines.length - 1;
    showLine();
    $("apw47pause").textContent = "▶ RESUME";
  };
  layer.addEventListener("click", (e) => {
    if (e.target === layer) close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && layer.classList.contains("apw46open")) close();
  });
})();
