/* Whiskey portrait viewer */
(function () {
  const portrait = APW_MEDIA[222];
  function update() {
    const overlay = document.getElementById("apw46overlay");
    if (!overlay || !overlay.classList.contains("apw46open")) return;
    const names = Array.from(overlay.querySelectorAll("*")).filter(
      (e) =>
        e.children.length === 0 &&
        e.textContent.trim().toLowerCase() === "whiskey sixx",
    );
    if (!names.length) return;
    const imgs = [
      document.getElementById("apw46left"),
      document.getElementById("apw46right"),
    ];
    const allNames = Array.from(overlay.querySelectorAll("*")).filter(
      (e) =>
        e.children.length === 0 &&
        [
          "whiskey sixx",
          "gideon hark",
          "simon temple",
          "mauler y",
          "tnt",
          "birdman phil picasso",
          "bruza the serb",
          "evangeline strange",
        ].includes(e.textContent.trim().toLowerCase()),
    );
    allNames.slice(0, 2).forEach((el, i) => {
      if (el.textContent.trim().toLowerCase() === "whiskey sixx" && imgs[i]) {
        imgs[i].src = portrait;
        imgs[i].style.opacity = "1";
        imgs[i].style.visibility = "visible";
      }
    });
  }
  const viewer = document.getElementById("apw55viewer");
  document.getElementById("apw55preview").src = portrait;
  document.getElementById("apw55open").onclick = () =>
    viewer.classList.add("open");
  document.getElementById("apw55close").onclick = () =>
    viewer.classList.remove("open");
  setInterval(update, 400);
  update();
})();

/* ---- Module 35 ---- */

/* Venue selection and backdrop */
(() => {
  "use strict";
  const svg = (venue) => {
    const outdoor = /outdoor|harbour/i.test(venue),
      serb = /serbian/i.test(venue),
      sports = /yagoona/i.test(venue);
    const a = outdoor
      ? "#2b1049"
      : serb
        ? "#3c132d"
        : sports
          ? "#092d50"
          : "#28103f";
    const accent = serb ? "#ff4c70" : sports ? "#21e5ff" : "#ff4ec4";
    const city = outdoor
      ? `<circle cx="700" cy="115" r="90" fill="#fb5aa4"/><path d="M0 300V240l40-22 28 14 45-42 38 38 40-20 48 18 25-60 32 60 44-30 40 25 34-18 44 22 40-50 42 48 28-18 36 12 38-27 45 29 28-18 50 32 55-15 45 32V300Z" fill="#151332"/><path d="M580 257Q695 110 820 257M605 257V211M635 257V174M665 257V150M695 257V145M725 257V155M755 257V185M790 257V226" fill="none" stroke="#ff90d1" stroke-width="5"/><path d="M250 260l30-90 32 90-32-65-30 65M310 260l26-70 24 70" fill="none" stroke="#29e9ff" stroke-width="5"/>`
      : `<path d="M0 0H960V300H0Z" fill="${a}"/><path d="M0 90H960M0 145H960M0 200H960" stroke="${accent}" stroke-width="5" opacity=".32"/><path d="M80 0V250M280 0V250M480 0V250M680 0V250M880 0V250" stroke="#77b8ff" stroke-width="9" opacity=".15"/><path d="M80 70H880" stroke="#ffdb8a" stroke-width="18" opacity=".3"/>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 540" preserveAspectRatio="none"><defs><linearGradient id="sky" x2="0" y2="1"><stop stop-color="${a}"/><stop offset="1" stop-color="#090b25"/></linearGradient><linearGradient id="mat" x2="0" y2="1"><stop stop-color="#d8d9fa"/><stop offset="1" stop-color="#6b8bd0"/></linearGradient></defs><rect width="960" height="540" fill="url(#sky)"/>${city}<path d="M0 290H960V390H0Z" fill="#17112d"/><path d="M0 300H960" stroke="#ef65b8" stroke-width="10" stroke-dasharray="14 11" opacity=".5"/><path d="M45 390H915L960 540H0Z" fill="url(#mat)" stroke="#f6a1e0" stroke-width="10"/><path d="M45 430H915M15 485H945" stroke="#f96cc4" stroke-width="7" opacity=".75"/><path d="M80 330V530M880 330V530" stroke="#44e8ff" stroke-width="12"/><path d="M80 370H880M80 420H880M80 470H880" stroke="#ff5dbf" stroke-width="8" opacity=".85"/><path d="M80 370H880M80 420H880M80 470H880" stroke="#7feaff" stroke-width="2"/><text x="480" y="520" fill="#ff58a6" opacity=".45" text-anchor="middle" font-family="Arial" font-weight="900" font-size="75">APW</text></svg>`;
  };
  const venues = {
    outdoor: ["Sydney Harbour Outdoor", "Outdoor • Sydney skyline and sunset"],
    bexley: ["Bexley Manor", "Indoor • Bexley Manor neon hall"],
    yagoona: ["Yagoona Sports", "Indoor • Yagoona Sports arena"],
    serbian: ["The Serbian Club", "Indoor • The Serbian Club"],
  };
  const select = document.getElementById("apw60venue"),
    note = document.getElementById("apw60venuenote"),
    arena = document.querySelector(".arena"),
    ring = arena?.querySelector(":scope > img:first-child");
  if (!select || !ring) return;
  function apply(value) {
    const key = Object.hasOwn(venues, value) ? value : "outdoor";
    const [name, description] = venues[key];
    select.value = key;
    note.textContent = description;
    if (arena.dataset.apw62venue !== name) {
      ring.src =
        "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg(name));
      ring.alt = name + " — clean neon wrestling ring";
      arena.style.backgroundImage = "none";
      arena.dataset.apw62venue = name;
    }
    try {
      localStorage.setItem("apw_selected_venue", key);
    } catch {}
  }
  let initial = "outdoor";
  try {
    initial = localStorage.getItem("apw_selected_venue") || initial;
  } catch {}
  apply(initial);
  select.addEventListener("change", () => apply(select.value));
  // The story overlay engine is still used in backstage scenes, but not in this ring.
  function clearRingOverlay() {
    arena.querySelectorAll(".apw36-overlay").forEach((el) => el.remove());
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", clearRingOverlay, {
      once: true,
    });
  else clearRingOverlay();
})();

/* ---- Module 36 ---- */

/* Illustrated actors */
(function () {
  const art = {
    "Gideon Hark": APW_MEDIA[223],
    "The Gatekeeper": APW_MEDIA[224],
  };
  function refresh() {
    const chosen = window.APW_CAREER?.name || "Gideon Hark";
    [
      ["gideon", chosen],
      ["gatekeeper", window.APW_OPPONENT || "The Gatekeeper"],
    ].forEach(([id, name]) => {
      const actor = document.getElementById(id);
      if (!actor) return;
      let hero = actor.querySelector(".apw61-hero");
      if (art[name]) {
        if (!hero) {
          hero = document.createElement("img");
          hero.className = "apw61-hero";
          hero.alt = name + " illustrated wrestler sprite";
          actor.appendChild(hero);
        }
        if (hero.dataset.wrestler !== name) {
          hero.src = art[name];
          hero.dataset.wrestler = name;
        }
        actor.classList.add("apw61-illustrated");
      } else {
        actor.classList.remove("apw61-illustrated");
        if (hero) hero.remove();
      }
    });
  }
  document.getElementById("restart")?.addEventListener("click", refresh);
  window.addEventListener("apw:career-changed", refresh);
  const observer = new MutationObserver(() => {
    if (!document.getElementById("gideon")?.querySelector(".apw61-hero"))
      refresh();
  });
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", () => {
      refresh();
      observer.observe(document.getElementById("fighters"), {
        childList: true,
        subtree: false,
      });
    });
  else {
    refresh();
    const f = document.getElementById("fighters");
    if (f) observer.observe(f, { childList: true, subtree: false });
  }
})();

/* ---- Module 41 ---- */

/* Illustrated frames */
(() => {
  const frames = {
    "Gideon Hark": [
      APW_MEDIA[225],
      APW_MEDIA[226],
      APW_MEDIA[227],
      APW_MEDIA[228],
      APW_MEDIA[229],
      APW_MEDIA[230],
    ],
    "The Gatekeeper": [
      APW_MEDIA[231],
      APW_MEDIA[232],
      APW_MEDIA[233],
      APW_MEDIA[234],
      APW_MEDIA[235],
      APW_MEDIA[236],
    ],
  };
  const poses = ["idle", "windup", "strike", "recoil", "finisher", "down"];
  function update() {
    for (const [id, name] of [
      ["gideon", "Gideon Hark"],
      ["gatekeeper", "The Gatekeeper"],
    ]) {
      const actor = document.getElementById(id);
      const img = actor?.querySelector(".apw61-hero");
      if (!img || img.dataset.wrestler !== name) continue;
      let pose = "idle";
      if (
        actor.classList.contains("down") ||
        actor.classList.contains("flyback")
      )
        pose = "down";
      else if (
        actor.classList.contains("finishing") ||
        actor.classList.contains("slowhit")
      )
        pose = "finisher";
      else if (actor.classList.contains("attack")) pose = "strike";
      else if (
        actor.classList.contains("grabbing") ||
        actor.classList.contains("spinning")
      )
        pose = "windup";
      else if (actor.classList.contains("hit")) pose = "recoil";
      const idx = poses.indexOf(pose);
      if (img.dataset.apw66pose !== pose) {
        img.src = frames[name][idx];
        img.dataset.apw66pose = pose;
      }
    }
  }
  function init() {
    update();
    const root = document.getElementById("fighters");
    if (root) {
      const mo = new MutationObserver(update);
      mo.observe(root, {
        attributes: true,
        attributeFilter: ["class"],
        subtree: true,
        childList: true,
      });
    }
    document.addEventListener("change", () => setTimeout(update, 0));
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init);
  else init();
})();
