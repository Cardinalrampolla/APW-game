/* Grudge presentation */
(() => {
  "use strict";
  const ring = document.getElementById("apw28Ring");
  if (!ring) return;
  ring.replaceChildren();
  const canvas = document.createElement("canvas");
  canvas.id = "apw29Canvas";
  canvas.width = 480;
  canvas.height = 220;
  canvas.setAttribute(
    "aria-label",
    "Animated 16-bit wrestling match: selected career wrestler versus Birdman Phil Picasso",
  );
  ring.append(canvas);
  const c = canvas.getContext("2d");
  c.imageSmoothingEnabled = false;
  let frame = 0,
    impact = 0,
    attackSide = 0,
    lastEnemy = 100,
    lastPlayer = 100,
    caption = "GRUDGE MATCH",
    flash = 0;
  const $ = (id) => document.getElementById(id);
  function rect(x, y, w, h, color) {
    c.fillStyle = color;
    c.fillRect(Math.round(x), Math.round(y), w, h);
  }
  function text(t, x, y, size = 12, color = "#ffe18b") {
    c.fillStyle = "#090616";
    c.font = "bold " + size + "px monospace";
    c.fillText(t, x + 2, y + 2);
    c.fillStyle = color;
    c.fillText(t, x, y);
  }
  function wrestler(x, y, side, name, action) {
    const bird = side === 1,
      temple = /Simon Temple/i.test(name),
      masked = /Mauler|Gatekeeper|Drako|Outlaw|Driftwood|Trashbag/i.test(name),
      long = /Gideon|Whiskey|Johnny|TNT|Taras|Diamond/i.test(name);
    const scale = temple ? 1.25 : 1;
    const bob = Math.sin(frame / 13 + side * 2) * 2;
    const jump = action ? Math.sin(Math.min(1, impact / 20) * Math.PI) * 12 : 0;
    c.save();
    c.translate(
      Math.round(x + (action ? (side ? -17 : 17) : 0)),
      Math.round(y + bob - jump),
    );
    c.scale((side ? -1 : 1) * scale, scale);
    rect(-24, 0, 48, 7, "#070817");
    // legs, boots and trunks
    rect(-18, -46, 14, 43, "#252431");
    rect(4, -46, 14, 43, "#252431");
    rect(-20, -12, 17, 12, "#0a0b15");
    rect(4, -12, 17, 12, "#0a0b15");
    rect(-22, -65, 44, 24, bird ? "#1b1c25" : temple ? "#b94e82" : "#a33255");
    rect(-26, -108, 52, 47, bird ? "#c58a6c" : temple ? "#dc9b82" : "#c99172");
    rect(-32, -104, 10, 37, bird ? "#b98062" : "#c99172");
    rect(22, -104, 10, 37, bird ? "#b98062" : "#c99172");
    if (action) {
      rect(22, -110, 35, 12, bird ? "#b98062" : "#c99172");
      rect(48, -112, 12, 15, "#302332");
    }
    // chest costume and signature wing tattoo
    if (bird) {
      rect(-17, -93, 12, 5, "#282333");
      rect(5, -93, 12, 5, "#282333");
      rect(-10, -85, 20, 7, "#3d3444");
      rect(-6, -75, 12, 7, "#29202a");
    } else if (temple) {
      rect(-22, -103, 44, 12, "#d7558b");
      rect(-8, -92, 16, 34, "#333342");
    } else {
      rect(-22, -104, 44, 9, "#4c253d");
      rect(-9, -78, 18, 10, "#39263a");
    }
    // head and hair
    rect(-15, -135, 30, 30, masked ? "#a42c42" : "#d69c7d");
    if (masked) {
      rect(-12, -124, 8, 5, "#fff");
      rect(4, -124, 8, 5, "#fff");
    } else {
      if (long) {
        rect(-18, -140, 36, 12, "#382a29");
        rect(-19, -132, 8, 36, "#382a29");
        rect(12, -132, 8, 36, "#382a29");
      } else if (!bird) {
        rect(-15, -139, 30, 8, "#382c2b");
      }
      rect(-10, -123, 6, 4, "#1a1720");
      rect(5, -123, 6, 4, "#1a1720");
      if (bird) {
        rect(-9, -111, 18, 6, "#2c2020");
        rect(-5, -106, 10, 6, "#2c2020");
      }
    }
    c.restore();
  }
  function tick() {
    frame++;
    c.clearRect(0, 0, 480, 220);
    for (let i = 0; i < 12; i++) {
      rect(i * 44, 0, 3, 100, "#29213d");
      rect(i * 44 + 7, 25, 24, 5, i % 2 ? "#653552" : "#38416a");
    }
    rect(0, 115, 480, 8, "#bb7191");
    rect(0, 123, 480, 97, "#42334d");
    for (let i = 0; i < 11; i++) rect(i * 50, 166, 22, 3, "#64506b");
    rect(0, 200, 480, 20, "#171527");
    text("APW  •  NO TEA PARTY!", 120, 19, 16, "#ffcf6c");
    let name = $("careerWrestler")?.value || "Gideon Hark";
    let fighting = !ring.classList.contains("hidden");
    if (fighting) {
      wrestler(145, 198, 0, name, impact > 0 && attackSide === 0);
      wrestler(
        335,
        198,
        1,
        "Birdman Phil Picasso",
        impact > 0 && attackSide === 1,
      );
      text(name.slice(0, 19).toUpperCase(), 12, 210, 10, "#f9d3e4");
      text("BIRDMAN", 390, 210, 10, "#f9d3e4");
      if (impact > 0) {
        impact--;
        flash = Math.max(flash, impact > 13 ? 2 : 0);
        rect(
          231,
          70,
          18 + impact * 2,
          18 + impact * 2,
          impact % 2 ? "#ffeb7c" : "#ff4c88",
        );
        text(
          caption,
          Math.max(30, 240 - caption.length * 6),
          52,
          15,
          "#fff4a0",
        );
      }
      if (flash > 0) {
        rect(0, 0, 480, 220, "#ffffff33");
        flash--;
      }
    }
    requestAnimationFrame(tick);
  }
  const observer = new MutationObserver(() => {
    const hp = $("apw28Meters")?.textContent || "";
    let vals = [...hp.matchAll(/·\s*(\d+)/g)].map((x) => Number(x[1]));
    if (vals.length >= 2) {
      if (vals[1] < lastEnemy) {
        impact = 20;
        attackSide = 0;
        caption = vals[1] === 0 ? "1... 2... 3!" : "BIG IMPACT!";
      } else if (vals[0] < lastPlayer) {
        impact = 16;
        attackSide = 1;
        caption = "BIRDMAN STRIKES!";
      }
      lastPlayer = vals[0];
      lastEnemy = vals[1];
    }
  });
  observer.observe($("apw28Meters"), {
    childList: true,
    subtree: true,
    characterData: true,
  });
  tick();
})();
