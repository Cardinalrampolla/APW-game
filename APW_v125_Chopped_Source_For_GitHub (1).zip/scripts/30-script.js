/* Singles finisher effect */
(function () {
  function init() {
    const arena = document.querySelector(".arena");
    const fighters = document.getElementById("fighters");
    if (!arena || !fighters) return;
    if (document.getElementById("apw67effect")) return;
    const layer = document.createElement("div");
    layer.id = "apw67effect";
    layer.className = "apw67-effect";
    layer.innerHTML =
      '<div class="apw67-ripcord"></div><div class="apw67-ghost"><span class="apw68-hand">✋</span><span class="apw68-hand">✋</span></div><div class="apw67-impact"></div>';
    arena.appendChild(layer);
    let last = "",
      until = 0;
    function trigger(type) {
      const now = Date.now();
      if (now < until && last === type) return;
      last = type;
      until = now + 1050;
      layer.className = "apw67-effect";
      void layer.offsetWidth;
      layer.classList.add(type);
      setTimeout(() => {
        if (Date.now() >= until) layer.className = "apw67-effect";
      }, 1100);
    }
    function check() {
      const g = document.getElementById("gideon"),
        k = document.getElementById("gatekeeper");
      if (
        g &&
        (window.APW_CAREER?.name || "Gideon Hark") === "Gideon Hark" &&
        (g.classList.contains("finishing") || g.classList.contains("slowhit"))
      )
        trigger("ripcord");
      if (
        k &&
        (window.APW_OPPONENT || "The Gatekeeper") === "The Gatekeeper" &&
        (k.classList.contains("haunt") || k.classList.contains("finishing"))
      )
        trigger("ghost");
    }
    new MutationObserver(check).observe(fighters, {
      subtree: true,
      attributes: true,
      attributeFilter: ["class"],
    });
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", init);
  else init();
})();
