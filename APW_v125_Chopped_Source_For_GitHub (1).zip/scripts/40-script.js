/* Three drawn key cels per wrestler; one elapsed-time player for match and studio. */
(() => {
  "use strict";
  const W = 384,
    H = 256,
    images = new Map();
  const profiles = Object.freeze({
    "Birdman Phil Picasso": {
      target: "Face",
      zone: 0.15,
      reach: 1,
      hold: 180,
      wind: 3,
      contact: [304, 76],
    },
    "Bruza The Serb": {
      target: "Low blow",
      zone: 0.57,
      reach: 4,
      hold: 220,
      wind: 4,
      contact: [265, 187],
    },
    "Nikki Poteet": {
      target: "Eyes",
      zone: 0.14,
      reach: 2,
      hold: 280,
      wind: 2,
      contact: [297, 60],
    },
    "Gideon Hark": {
      target: "Head",
      zone: 0.15,
      reach: 4,
      hold: 180,
      wind: 3,
      contact: [300, 80],
    },
    "Simon Temple": {
      target: "Lower body",
      zone: 0.66,
      reach: 3,
      hold: 240,
      wind: 4,
      contact: [285, 190],
    },
    "Whiskey Sixx": {
      target: "Head",
      zone: 0.15,
      reach: 4,
      hold: 190,
      wind: 3,
      contact: [294, 80],
    },
    "Mauler Y": {
      target: "Face",
      zone: 0.15,
      reach: 1,
      hold: 200,
      wind: 2,
      contact: [296, 94],
    },
    Doomslayer: {
      target: "Throat",
      zone: 0.235,
      reach: 3,
      hold: 180,
      wind: 2,
      contact: [307, 80],
    },
    "Taras Jones": {
      target: "Shin / ankle",
      zone: 0.86,
      reach: 3,
      hold: 220,
      wind: 3,
      contact: [246, 224],
    },
    "Trucker Mark Taylor": {
      target: "Upper body",
      zone: 0.36,
      reach: 4,
      hold: 200,
      wind: 4,
      contact: [244, 68],
    },
    "Harvey Falco": {
      target: "Tights / waist",
      zone: 0.49,
      reach: -3,
      hold: 300,
      wind: 2,
      contact: [318, 137],
    },
    "Al Straya": {
      target: "Body",
      zone: 0.42,
      reach: 4,
      hold: 220,
      wind: 4,
      contact: [336, 96],
    },
    TNT: {
      target: "Eyes",
      zone: 0.14,
      reach: 2,
      hold: 180,
      wind: 2,
      contact: [312, 83],
    },
    "Johnny Putrid": {
      target: "Head",
      zone: 0.15,
      reach: 5,
      hold: 180,
      wind: 4,
      contact: [253, 80],
    },
    "Nightmare Cat": {
      target: "Face",
      zone: 0.15,
      reach: 2,
      hold: 280,
      wind: 2,
      contact: [302, 60],
    },
    "Drako Savage": {
      target: "Face",
      zone: 0.15,
      reach: 1,
      hold: 180,
      wind: 3,
      contact: [321, 40],
    },
    "Trashbag Dan": {
      target: "Face",
      zone: 0.15,
      reach: 1,
      hold: 200,
      wind: 3,
      contact: [322, 85],
    },
    "Eli Driftwood": {
      target: "Neck",
      zone: 0.235,
      reach: -3,
      hold: 300,
      wind: 3,
      contact: [356, 83],
    },
    "Jay Payne": {
      target: "Knee",
      zone: 0.71,
      reach: 3,
      hold: 210,
      wind: 3,
      contact: [315, 193],
    },
    "The Outlaw": {
      target: "Head",
      zone: 0.15,
      reach: 4,
      hold: 190,
      wind: 3,
      contact: [345, 91],
    },
    "Black Diamond": {
      target: "Face",
      zone: 0.15,
      reach: 1,
      hold: 200,
      wind: 2,
      contact: [306, 72],
    },
    "Hotshot Hansel": {
      target: "Face",
      zone: 0.15,
      reach: 1,
      hold: 180,
      wind: 3,
      contact: [314, 80],
    },
    "Evangeline Strange": {
      target: "Upper body",
      zone: 0.36,
      reach: 3,
      hold: 200,
      wind: 3,
      contact: [334, 76],
    },
  });
  const style = document.createElement("style");
  style.textContent = `
  #apw117Dirty .call{top:2%!important;padding:5px 7px!important;font-size:12px!important;line-height:1.2!important}
  #apw117Dirty .call small{font-size:9px!important;margin-top:2px!important}
  #apw117Dirty[data-outcome=landed] .contact{display:none!important}
  #fighters canvas.apw118-dirty-canvas{display:none!important}
  #fighters #gideon.apw118-dirty{width:25%!important;height:82%!important;bottom:1%!important;left:19%!important;overflow:visible;animation:none!important;transform:none!important}
  #fighters #gideon.apw118-dirty > :not(canvas.apw118-dirty-canvas){display:none!important;visibility:hidden!important;opacity:0!important}
  #fighters #gideon.apw118-dirty > canvas.apw118-dirty-canvas{display:block!important;visibility:visible!important;opacity:1!important;position:absolute!important;inset:auto!important;left:-42%!important;bottom:0!important;width:220%!important;height:100%!important;object-fit:contain!important;object-position:center bottom!important;image-rendering:pixelated!important;z-index:1600!important;transform:none!important;filter:saturate(1.28) contrast(1.08) brightness(1.04) drop-shadow(2px 3px 1px #050615)!important}
  @media(max-width:620px){#fighters #gideon.apw118-dirty{width:31%!important;left:13%!important}}
  #apw118Frames canvas,#apw119Preview{filter:saturate(1.28) contrast(1.08) brightness(1.04)}
  .arena[data-apw-dirty-reduced=true],.arena[data-apw-dirty-reduced=true] #gatekeeper.hit{animation:none!important}
  .arena[data-apw-dirty-reduced=true] .apw113-single-impact,.arena[data-apw-dirty-reduced=true] .apw113-single-impact:after{animation:none!important;opacity:.55}
  @media(prefers-reduced-motion:reduce){.arena[data-apw-dirty-zone],.arena[data-apw-dirty-zone] #gatekeeper.hit{animation:none!important}}
  #apw119Preview{display:block;width:min(460px,100%);height:auto;image-rendering:pixelated;background:radial-gradient(ellipse,#292040,#11192e);margin:10px auto;border:1px solid #9c6d99;border-radius:8px}
  #apw118Studio{position:fixed;inset:0;z-index:2147483400;background:#080c1cf5;display:grid;place-items:center;padding:12px;box-sizing:border-box}#apw118Studio[hidden]{display:none!important}
  #apw118Studio .wrap{width:min(880px,100%);max-height:94dvh;overflow:auto;padding:18px;box-sizing:border-box;border:2px solid #ef65c3;border-radius:12px;background:radial-gradient(ellipse at top,#322044,#11182c);color:white}
  #apw118Studio h2{font:900 19px monospace;color:#ffe1a0}#apw118Studio select,#apw118Studio button{min-height:44px;padding:10px;border:1px solid #77e8f9;background:#201c34;color:white;border-radius:6px;max-width:100%}#apw118Frames{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}#apw118Frames figure{margin:8px 0;padding:4px;background:#10192d;border:1px solid #665078;border-radius:6px}#apw118Frames canvas{width:100%;height:auto;image-rendering:pixelated}#apw118Frames figcaption{text-align:center;font:11px monospace;color:#96e5ed}#apw118Studio p{font:13px/1.6 monospace}#apw118Launch{position:static;min-height:48px}
  `;
  document.head.append(style);
  let pending = null,
    epoch = 0,
    livePlayback = null,
    pendingPreview = null;
  const motion = window.matchMedia?.("(prefers-reduced-motion: reduce)");
  const reduced = () =>
    !!motion?.matches || !!document.getElementById("apw43motion")?.checked;
  function cancel(keepReaction = false) {
    epoch++;
    livePlayback?.();
    livePlayback = null;
    pending = null;
    const arena = document.querySelector(".arena");
    arena?.removeAttribute("data-apw-dirty-zone");
    arena?.removeAttribute("data-apw-dirty-reduced");
    window.APW_DIRTY_CONTACT?.clear(keepReaction === true);
    document.getElementById("gideon")?.classList.remove("apw118-dirty");
  }
  /* v12.5 compact pixel contact accents. The source poses remain unchanged.
     Contact effects are deterministic and purely visual, never touching combat state. */
  const effects = Object.freeze({
    "Birdman Phil Picasso": ["sand", "#ffe7a0"],
    "Bruza The Serb": ["impact", "#ff5368"],
    "Nikki Poteet": ["scratch", "#f7ce7a"],
    "Gideon Hark": ["metal", "#eddf9b"],
    "Simon Temple": ["rope", "#f9b0cf"],
    "Whiskey Sixx": ["chain", "#d1d0df"],
    "Mauler Y": ["mist", "#67fb93"],
    Doomslayer: ["impact", "#ffe77c"],
    "Taras Jones": ["trip", "#bb8de8"],
    "Trucker Mark Taylor": ["impact", "#ffa15a"],
    "Harvey Falco": ["cloth", "#ffdd8e"],
    "Al Straya": ["metal", "#f5b0a2"],
    TNT: ["impact", "#f89f60"],
    "Johnny Putrid": ["impact", "#d5f8ff"],
    "Nightmare Cat": ["scratch", "#ffb2a1"],
    "Drako Savage": ["mist", "#72ff92"],
    "Trashbag Dan": ["bag", "#ffc3e6"],
    "Eli Driftwood": ["pull", "#ffb565"],
    "Jay Payne": ["impact", "#e8caff"],
    "The Outlaw": ["metal", "#cfddfc"],
    "Black Diamond": ["powder", "#cbd3ef"],
    "Hotshot Hansel": ["powder", "#f6e69b"],
    "Evangeline Strange": ["paper", "#d5f1ff"],
  });
  function dress(ctx, name, frame, shift = 0, time = 0) {
    if (frame !== 1) return;
    const p = profiles[name],
      phase = Math.max(0, Math.min(1, (time - 260) / p.hold));
    if (phase >= 0.85) return;
    const [type, color] = effects[name],
      contact = p.contact,
      t = Math.max(0, Math.min(1, (224 - contact[1]) / 96));
    const x = Math.round(contact[0] + shift * t * t * (3 - 2 * t)),
      y = Math.round(contact[1]);
    ctx.save();
    ctx.globalAlpha = (1 - phase / 0.85) * 0.85;
    ctx.beginPath();
    ctx.rect(0, 0, W, 224);
    ctx.clip();
    const dot = (dx, dy, size = 2) =>
      ctx.fillRect(Math.round(x + dx), Math.round(y + dy), size, size);
    ctx.fillStyle = color;
    if (["sand", "mist", "powder", "bag"].includes(type)) {
      for (let k = 0; k < 12; k++) {
        const a = k * 2.4,
          r = 4 + (k % 4) * 2 + phase * 7;
        dot(Math.cos(a) * r, Math.sin(a) * r, k % 3 === 0 ? 3 : 2);
      }
    } else if (type === "scratch") {
      for (let k = -1; k <= 1; k++)
        for (let j = 0; j < 5; j++) dot(k * 5 + j - 2, j * 2 - 5);
    } else if (type === "cloth" || type === "pull") {
      for (const sign of [-1, 1]) {
        dot(sign * 10, -4, 3);
        dot(sign * 12, 1);
        dot(sign * 10, 5);
      }
    } else {
      const r = 6 + Math.round(phase * 8);
      for (const [dx, dy] of [
        [-1, 0],
        [1, 0],
        [0, -1],
        [0, 1],
        [-0.7, -0.7],
        [0.7, 0.7],
      ])
        dot(dx * r, dy * r, 3);
    }
    ctx.fillStyle = "#fff8e7";
    dot(-1, -1, 3);
    ctx.restore();
  }

  function paint(
    canvas,
    name,
    frame,
    shift = 0,
    elapsed = 0,
    allowEffects = true,
  ) {
    if (!Number.isInteger(frame) || frame < 0 || frame > 2) return false;
    const im = images.get(name);
    if (!im?.complete || !im.naturalWidth) return false;
    const ctx = canvas.getContext("2d");
    if (!ctx) return false;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, W, H);
    if (!shift) ctx.drawImage(im, frame * W, 0, W, H, 0, 0, W, H);
    else
      for (let y = 0; y < H; y += 1) {
        const h = Math.min(1, H - y),
          t = Math.max(0, Math.min(1, (224 - y) / 96)),
          weight = t * t * (3 - 2 * t);
        // Lean the upper body while the last 32 rows (including the feet) stay planted.
        ctx.drawImage(
          im,
          frame * W,
          y,
          W,
          h,
          Math.round(shift * weight),
          y,
          W,
          h,
        );
      }
    if (allowEffects && !reduced()) dress(ctx, name, frame, shift, elapsed);
    canvas.dataset.shift = String(Math.round(shift));
    canvas.dataset.wrestler = name;
    canvas.dataset.frame = String(frame);
    return true;
  }
  // Contact coincides with the singles engine's 260 ms impact. Sample elapsed
  // time rather than draining overdue timers after a dropped frame.
  const CONTACT = 260,
    DURATION = 920;
  function sample(name, outcome, elapsed) {
    const p = profiles[name],
      end = CONTACT + p.hold;
    const caught = outcome === "caught";
    const points = caught
      ? [
          [0, 0],
          [160, -Math.min(p.wind, 2)],
          [300, -2],
          [600, -1],
          [840, 0],
        ]
      : [
          [0, 0],
          [160, -p.wind],
          [CONTACT, p.reach],
          [340, p.reach * 0.65],
          [end - 20, p.reach * 0.3],
          [end, -1],
          [end + 100, -0.5],
          [840, 0],
        ];
    const time = Math.max(0, elapsed);
    let shift = points.at(-1)[1];
    for (let i = 1; i < points.length; i++) {
      if (time > points[i][0]) continue;
      const [a, x] = points[i - 1],
        [b, y] = points[i];
      const t = Math.max(0, Math.min(1, (time - a) / (b - a)));
      shift = x + (y - x) * t * t * (3 - 2 * t);
      break;
    }
    const frame = caught
      ? time < 300
        ? 0
        : 2
      : time < CONTACT
        ? 0
        : time < end
          ? 1
          : 2;
    return {
      frame,
      shift,
      phase: caught
        ? frame === 0
          ? "setup"
          : "withdrawal"
        : frame === 0
          ? "setup"
          : frame === 1
            ? "contact"
            : "recovery",
      finished: time >= DURATION,
    };
  }
  function playback(canvas, name, outcome, startedAt, done) {
    let request = 0,
      stopped = false,
      last = "";
    function tick() {
      if (stopped) return;
      const pose = sample(name, outcome, performance.now() - startedAt);
      if (reduced()) {
        pose.frame = outcome === "caught" ? 0 : 1;
        pose.shift = 0;
      }
      const signature =
        pose.frame +
        ":" +
        Math.round(pose.shift) +
        ":" +
        (pose.frame === 1 && !reduced()
          ? Math.floor((performance.now() - startedAt) / 33)
          : 0);
      if (
        signature !== last &&
        paint(
          canvas,
          name,
          pose.frame,
          pose.shift,
          performance.now() - startedAt,
        )
      ) {
        last = signature;
        canvas.dataset.phase = pose.phase;
        if (canvas.id === "apw119Preview") {
          pendingPreview = null;
          document.getElementById("apw121Phase").textContent =
            (outcome === "caught" ? "CAUGHT · " : "LANDED · ") +
            (reduced() ? "REDUCED MOTION" : pose.phase.toUpperCase());
        }
      }
      if (pose.finished) {
        done?.();
        return;
      }
      request = requestAnimationFrame(tick);
    }
    tick();
    return () => {
      stopped = true;
      cancelAnimationFrame(request);
    };
  }
  function show(detail, token) {
    if (token !== epoch || detail.wrestler !== window.APW_CAREER?.name) return;
    if (
      detail.startedAt !== undefined &&
      performance.now() - detail.startedAt > 700
    ) {
      cancel();
      return;
    }
    const actor = document.getElementById("gideon");
    if (!actor) return;
    let canvas = actor.querySelector("canvas.apw118-dirty-canvas");
    if (!canvas) {
      canvas = document.createElement("canvas");
      canvas.className = "apw118-dirty-canvas";
      canvas.width = W;
      canvas.height = H;
      canvas.setAttribute("aria-hidden", "true");
      actor.append(canvas);
    }
    const startedAt = detail.startedAt ?? performance.now(),
      elapsed = Math.max(0, performance.now() - startedAt),
      current = sample(detail.wrestler, detail.outcome, elapsed);
    if (reduced()) {
      current.frame = detail.outcome === "caught" ? 0 : 1;
      current.shift = 0;
    }
    if (
      !paint(canvas, detail.wrestler, current.frame, current.shift, elapsed)
    ) {
      pending = { detail, token };
      return;
    }
    pending = null;
    actor.classList.add("apw118-dirty");
    window.APW_DIRTY_CONTACT?.prepare(
      actor,
      canvas,
      detail,
      profiles[detail.wrestler],
    );
    const label = document.querySelector("#apw117Dirty .call");
    if (label && detail.outcome !== "caught" && label.firstChild)
      label.firstChild.textContent =
        APW_DIRTY_SHEETS[detail.wrestler].move.toUpperCase();
    livePlayback = playback(
      canvas,
      detail.wrestler,
      detail.outcome,
      startedAt,
      () => {
        if (token === epoch) cancel(true);
      },
    );
  }
  window.addEventListener("apw:dirty-trick", (event) => {
    cancel();
    if (document.hidden) return;
    if (
      APW_DIRTY_SHEETS[event.detail?.wrestler] &&
      event.detail.wrestler === window.APW_CAREER?.name
    ) {
      document.querySelector(".arena").dataset.apwDirtyReduced =
        String(reduced());
      if (event.detail.outcome === "landed")
        document.querySelector(".arena").dataset.apwDirtyZone = String(
          profiles[event.detail.wrestler].zone,
        );
      show({ ...event.detail, startedAt: performance.now() }, epoch);
    }
  });
  document.getElementById("restart")?.addEventListener("click", cancel);
  window.addEventListener("apw:career-changed", cancel);
  for (const [name, data] of Object.entries(APW_DIRTY_SHEETS)) {
    const im = new Image();
    images.set(name, im);
    im.onload = () => {
      if (pending?.detail.wrestler === name)
        show(pending.detail, pending.token);
      if (!studio.hidden && select.value === name) {
        drawPreview();
        if (pendingPreview?.name === name) playPreview(pendingPreview.outcome);
      }
    };
    im.src = data.src;
  }
  const studio = document.createElement("section");
  studio.id = "apw118Studio";
  studio.hidden = true;
  studio.setAttribute("role", "dialog");
  studio.setAttribute("aria-modal", "true");
  studio.setAttribute("aria-labelledby", "apw118Title");
  studio.innerHTML =
    '<div class="wrap"><h2 id="apw118Title">DIRTY TRICK SPRITE STUDIO</h2><p>23 wrestlers · three dedicated drawn cels each. Previewing art does not perform a move or change your career.</p><select id="apw118Select" aria-label="Wrestler"></select> <button type="button" id="apw118Close">CLOSE ✕</button><p id="apw118Move"></p><button type="button" id="apw119Play">▶ PLAY ANIMATION</button><button type="button" id="apw121Caught">PREVIEW CAUGHT</button><p id="apw121Phase"></p><canvas id="apw119Preview" width="384" height="256" aria-label="Animated dirty trick preview"></canvas><div id="apw118Frames"></div></div>';
  document.body.append(studio);
  const select = studio.querySelector("select");
  for (const name of Object.keys(APW_DIRTY_SHEETS))
    select.add(new Option(name, name));
  for (const title of ["SETUP", "ILLEGAL CONTACT", "RECOVERY"]) {
    const figure = document.createElement("figure"),
      canvas = document.createElement("canvas"),
      caption = document.createElement("figcaption");
    canvas.width = W;
    canvas.height = H;
    caption.textContent = title;
    figure.append(canvas, caption);
    studio.querySelector("#apw118Frames").append(figure);
  }
  function drawPreview() {
    document.getElementById("apw118Move").textContent =
      select.value +
      " — " +
      APW_DIRTY_SHEETS[select.value].move +
      " · " +
      profiles[select.value].target;
    studio
      .querySelectorAll("#apw118Frames canvas")
      .forEach((c, i) => paint(c, select.value, i));
  }
  let previewPlayback = null;
  function stopPreview() {
    previewPlayback?.();
    previewPlayback = null;
    pendingPreview = null;
  }
  function playPreview(outcome = "landed") {
    stopPreview();
    const name = select.value,
      canvas = document.getElementById("apw119Preview");
    canvas.getContext("2d")?.clearRect(0, 0, W, H);
    for (const key of ["wrestler", "frame", "phase", "shift"])
      delete canvas.dataset[key];
    pendingPreview = { name, outcome };
    canvas.setAttribute(
      "aria-label",
      name + " — " + APW_DIRTY_SHEETS[name].move,
    );
    previewPlayback = playback(canvas, name, outcome, performance.now());
  }
  select.onchange = () => {
    stopPreview();
    drawPreview();
    playPreview();
  };
  document.getElementById("apw119Play").onclick = () => playPreview();
  document.getElementById("apw121Caught").onclick = () => playPreview("caught");
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      cancel();
      stopPreview();
    }
  });
  document.getElementById("apw43motion")?.addEventListener("change", () => {
    if (!studio.hidden) playPreview();
  });
  motion?.addEventListener?.("change", () => {
    if (!studio.hidden) playPreview();
  });
  const launch = document.createElement("button");
  launch.id = "apw118Launch";
  launch.type = "button";
  launch.textContent = "★ DIRTY TRICK SPRITE STUDIO";
  document.getElementById("apw62utilityDock").append(launch);
  let previous = null,
    scroll = "";
  function close() {
    stopPreview();
    studio.hidden = true;
    document.body.style.overflow = scroll;
    previous?.focus?.();
  }
  launch.onclick = () => {
    previous = document.activeElement;
    scroll = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    studio.hidden = false;
    select.value = APW_DIRTY_SHEETS[window.APW_CAREER?.name]
      ? window.APW_CAREER?.name
      : select.options[0].value;
    drawPreview();
    playPreview();
    select.focus();
  };
  document.getElementById("apw118Close").onclick = close;
  studio.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      close();
    }
    if (event.key === "Tab") {
      const nodes = [...studio.querySelectorAll("select,button")],
        i = nodes.indexOf(document.activeElement);
      event.preventDefault();
      nodes[
        (i + (event.shiftKey ? -1 : 1) + nodes.length) % nodes.length
      ].focus();
    }
  });
  window.APW_DIRTY_ART = {
    names: () => Object.keys(APW_DIRTY_SHEETS),
    sample: (name, outcome, elapsed) =>
      profiles[name] ? sample(name, outcome, elapsed) : null,
    profiles: () =>
      Object.fromEntries(
        Object.entries(profiles).map(([n, p]) => [
          n,
          { ...p, contact: [...p.contact] },
        ]),
      ),
    status: () =>
      Object.fromEntries(
        [...images].map(([n, im]) => [
          n,
          im.complete && im.naturalWidth === W * 3 && im.naturalHeight === H,
        ]),
      ),
  };
})();
