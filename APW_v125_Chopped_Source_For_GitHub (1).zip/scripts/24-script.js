/* Roster pose bridge */
(() => {
  "use strict";
  const roster = window.APW_ROSTER_SPRITES;
  if (!roster) return;

  const poseClasses = [
    "finisher",
    "grapple",
    "strike",
    "hit",
    "down",
    "walk",
    "victory",
  ];
  function poseFor(el) {
    for (const p of poseClasses) {
      if (el.classList.contains(p)) return p;
    }
    return "idle";
  }
  function applyActor(actor) {
    const img = actor.querySelector("img.apw40-sprite");
    if (!img) return;
    const name = img.dataset.who;
    const frames = roster[name];
    if (!frames) return;
    const pose = poseFor(actor);
    const target = frames[pose] || frames.idle;
    if (img.src !== target) img.src = target;
    actor.dataset.apw48Pose = pose;
  }
  const tagNames = ["Gideon Hark", "Simon Temple", "Whiskey Sixx", "Mauler Y"];
  function tagName(el, i) {
    const info = (
      el.id +
      " " +
      el.className +
      " " +
      (el.getAttribute("aria-label") || "") +
      " " +
      (el.dataset.name || "")
    ).toLowerCase();
    for (const n of tagNames)
      if (
        info.includes(n.toLowerCase()) ||
        info.includes(n.split(" ")[0].toLowerCase())
      )
        return n;
    return tagNames[i % 4];
  }
  function updateTag() {
    const els = [...document.querySelectorAll("#tagarena .tagwrestler")];
    els.forEach((el, i) => {
      if (el.querySelector(".apw99-art")) {
        el.querySelector(".apw48-tag-sprite")?.remove();
        el.classList.remove("apw48-rendered");
        return;
      }
      let img = el.querySelector("img.apw48-tag-sprite");
      if (!img) {
        img = document.createElement("img");
        img.className = "apw48-tag-sprite";
        img.alt = "Wrestler pixel sprite";
        el.appendChild(img);
        el.classList.add("apw48-rendered");
      }
      const name = tagName(el, i);
      const frame = roster[name];
      if (!frame) return;
      let pose = poseFor(el);
      const arena = document.getElementById("tagarena");
      const arenaClass = arena?.className || "";
      if (pose === "idle") {
        if (arenaClass.includes("apw38-double")) pose = "grapple";
        else if (arenaClass.includes("apw38-strike")) pose = "strike";
        else if (arenaClass.includes("apw38-grapple")) pose = "grapple";
      }
      const src = frame[pose] || frame.idle;
      if (img.src !== src) img.src = src;
      img.alt = name + " " + pose;
    });
  }
  let pending = false;
  function schedule() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => {
      pending = false;
      document.querySelectorAll(".apw36-actor").forEach(applyActor);
      updateTag();
    });
  }
  const observer = new MutationObserver(schedule);
  observer.observe(document.body, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ["class", "data-who"],
  });
  document.addEventListener("click", schedule, true);
  document
    .getElementById("careerWrestler")
    ?.addEventListener("change", schedule);
  schedule();
})();
