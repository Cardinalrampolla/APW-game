/* Roster studio */
(() => {
  "use strict";
  const sprites = {
    "Gideon Hark": {
      idle: APW_MEDIA[14],
      walk: APW_MEDIA[15],
      strike: APW_MEDIA[16],
      grapple: APW_MEDIA[17],
      hit: APW_MEDIA[18],
      finisher: APW_MEDIA[19],
      down: APW_MEDIA[20],
      victory: APW_MEDIA[21],
    },
    "Simon Temple": {
      idle: APW_MEDIA[22],
      walk: APW_MEDIA[23],
      strike: APW_MEDIA[24],
      grapple: APW_MEDIA[25],
      hit: APW_MEDIA[26],
      finisher: APW_MEDIA[27],
      down: APW_MEDIA[28],
      victory: APW_MEDIA[29],
    },
    "Birdman Phil Picasso": {
      idle: APW_MEDIA[318],
      walk: APW_MEDIA[318],
      strike: APW_MEDIA[319],
      grapple: APW_MEDIA[320],
      hit: APW_MEDIA[321],
      finisher: APW_MEDIA[319],
      down: APW_MEDIA[321],
      victory: APW_MEDIA[318],
    },
    "Bruza The Serb": {
      idle: APW_MEDIA[322],
      walk: APW_MEDIA[322],
      strike: APW_MEDIA[323],
      grapple: APW_MEDIA[324],
      hit: APW_MEDIA[325],
      finisher: APW_MEDIA[323],
      down: APW_MEDIA[325],
      victory: APW_MEDIA[322],
    },
    "Nikki Poteet": {
      idle: APW_MEDIA[326],
      walk: APW_MEDIA[326],
      strike: APW_MEDIA[327],
      grapple: APW_MEDIA[328],
      hit: APW_MEDIA[329],
      finisher: APW_MEDIA[327],
      down: APW_MEDIA[329],
      victory: APW_MEDIA[326],
    },
    "Johnny Putrid": {
      idle: APW_MEDIA[54],
      walk: APW_MEDIA[55],
      strike: APW_MEDIA[56],
      grapple: APW_MEDIA[57],
      hit: APW_MEDIA[58],
      finisher: APW_MEDIA[59],
      down: APW_MEDIA[60],
      victory: APW_MEDIA[61],
    },
    "Nightmare Cat": {
      idle: APW_MEDIA[62],
      walk: APW_MEDIA[63],
      strike: APW_MEDIA[64],
      grapple: APW_MEDIA[65],
      hit: APW_MEDIA[66],
      finisher: APW_MEDIA[67],
      down: APW_MEDIA[68],
      victory: APW_MEDIA[69],
    },
    TNT: {
      idle: APW_MEDIA[70],
      walk: APW_MEDIA[71],
      strike: APW_MEDIA[72],
      grapple: APW_MEDIA[73],
      hit: APW_MEDIA[74],
      finisher: APW_MEDIA[75],
      down: APW_MEDIA[76],
      victory: APW_MEDIA[77],
    },
    "Whiskey Sixx": {
      idle: APW_MEDIA[78],
      walk: APW_MEDIA[79],
      strike: APW_MEDIA[80],
      grapple: APW_MEDIA[81],
      hit: APW_MEDIA[82],
      finisher: APW_MEDIA[83],
      down: APW_MEDIA[84],
      victory: APW_MEDIA[85],
    },
    "Mauler Y": {
      idle: APW_MEDIA[86],
      walk: APW_MEDIA[87],
      strike: APW_MEDIA[88],
      grapple: APW_MEDIA[89],
      hit: APW_MEDIA[90],
      finisher: APW_MEDIA[91],
      down: APW_MEDIA[92],
      victory: APW_MEDIA[93],
    },
    "Al Straya": {
      idle: APW_MEDIA[94],
      walk: APW_MEDIA[95],
      strike: APW_MEDIA[96],
      grapple: APW_MEDIA[97],
      hit: APW_MEDIA[98],
      finisher: APW_MEDIA[99],
      down: APW_MEDIA[100],
      victory: APW_MEDIA[101],
    },
    "Trucker Mark Taylor": {
      idle: APW_MEDIA[102],
      walk: APW_MEDIA[103],
      strike: APW_MEDIA[104],
      grapple: APW_MEDIA[105],
      hit: APW_MEDIA[106],
      finisher: APW_MEDIA[107],
      down: APW_MEDIA[108],
      victory: APW_MEDIA[109],
    },
    "Taras Jones": {
      idle: APW_MEDIA[110],
      walk: APW_MEDIA[111],
      strike: APW_MEDIA[112],
      grapple: APW_MEDIA[113],
      hit: APW_MEDIA[114],
      finisher: APW_MEDIA[115],
      down: APW_MEDIA[116],
      victory: APW_MEDIA[117],
    },
    "Harvey Falco": {
      idle: APW_MEDIA[118],
      walk: APW_MEDIA[119],
      strike: APW_MEDIA[120],
      grapple: APW_MEDIA[121],
      hit: APW_MEDIA[122],
      finisher: APW_MEDIA[123],
      down: APW_MEDIA[124],
      victory: APW_MEDIA[125],
    },
    Doomslayer: {
      idle: APW_MEDIA[330],
      walk: APW_MEDIA[330],
      strike: APW_MEDIA[331],
      grapple: APW_MEDIA[332],
      hit: APW_MEDIA[333],
      finisher: APW_MEDIA[331],
      down: APW_MEDIA[333],
      victory: APW_MEDIA[330],
    },
    "Drako Savage": {
      idle: APW_MEDIA[134],
      walk: APW_MEDIA[135],
      strike: APW_MEDIA[136],
      grapple: APW_MEDIA[137],
      hit: APW_MEDIA[138],
      finisher: APW_MEDIA[139],
      down: APW_MEDIA[140],
      victory: APW_MEDIA[141],
    },
    "Trashbag Dan": {
      idle: APW_MEDIA[142],
      walk: APW_MEDIA[143],
      strike: APW_MEDIA[144],
      grapple: APW_MEDIA[145],
      hit: APW_MEDIA[146],
      finisher: APW_MEDIA[147],
      down: APW_MEDIA[148],
      victory: APW_MEDIA[149],
    },
    "Eli Driftwood": {
      idle: APW_MEDIA[150],
      walk: APW_MEDIA[151],
      strike: APW_MEDIA[152],
      grapple: APW_MEDIA[153],
      hit: APW_MEDIA[154],
      finisher: APW_MEDIA[155],
      down: APW_MEDIA[156],
      victory: APW_MEDIA[157],
    },
    "Jay Payne": {
      idle: APW_MEDIA[158],
      walk: APW_MEDIA[159],
      strike: APW_MEDIA[160],
      grapple: APW_MEDIA[161],
      hit: APW_MEDIA[162],
      finisher: APW_MEDIA[163],
      down: APW_MEDIA[164],
      victory: APW_MEDIA[165],
    },
    "The Outlaw": {
      idle: APW_MEDIA[166],
      walk: APW_MEDIA[167],
      strike: APW_MEDIA[168],
      grapple: APW_MEDIA[169],
      hit: APW_MEDIA[170],
      finisher: APW_MEDIA[171],
      down: APW_MEDIA[172],
      victory: APW_MEDIA[173],
    },
    "Black Diamond": {
      idle: APW_MEDIA[174],
      walk: APW_MEDIA[175],
      strike: APW_MEDIA[176],
      grapple: APW_MEDIA[177],
      hit: APW_MEDIA[178],
      finisher: APW_MEDIA[179],
      down: APW_MEDIA[180],
      victory: APW_MEDIA[181],
    },
    "Hotshot Hansel": {
      idle: APW_MEDIA[182],
      walk: APW_MEDIA[183],
      strike: APW_MEDIA[184],
      grapple: APW_MEDIA[185],
      hit: APW_MEDIA[186],
      finisher: APW_MEDIA[187],
      down: APW_MEDIA[188],
      victory: APW_MEDIA[189],
    },
    "Evangeline Strange": {
      idle: APW_MEDIA[190],
      walk: APW_MEDIA[191],
      strike: APW_MEDIA[192],
      grapple: APW_MEDIA[193],
      hit: APW_MEDIA[194],
      finisher: APW_MEDIA[195],
      down: APW_MEDIA[196],
      victory: APW_MEDIA[197],
    },
    "The Gatekeeper": {
      idle: APW_MEDIA[198],
      walk: APW_MEDIA[199],
      strike: APW_MEDIA[200],
      grapple: APW_MEDIA[201],
      hit: APW_MEDIA[202],
      finisher: APW_MEDIA[203],
      down: APW_MEDIA[204],
      victory: APW_MEDIA[205],
    },
  };
  window.APW_ROSTER_SPRITES = sprites;
  const names = Object.keys(sprites);
  const selected = () =>
    document.getElementById("careerWrestler")?.value || "Gideon Hark";
  function make(name, pose = "idle") {
    const img = document.createElement("img");
    img.className = "apw40-sprite";
    img.alt = name + " " + pose + " pixel sprite";
    img.src =
      (sprites[name] || sprites["Gideon Hark"])[pose] ||
      sprites["Gideon Hark"].idle;
    return img;
  }
  function replaceActor(actor, name) {
    if (!actor || !sprites[name]) return;
    const old = actor.querySelector(".apw40-sprite");
    if (old) {
      if (old.dataset.who === name) return;
      old.remove();
    }
    const img = make(name);
    img.dataset.who = name;
    actor.replaceChildren(img);
  }
  function refresh() {
    const name = selected();
    document.querySelectorAll(".apw36-overlay").forEach((layer) => {
      const a = layer.querySelector(".apw36-actor.a"),
        b = layer.querySelector(".apw36-actor.b");
      if (a) replaceActor(a, name);
      if (b) {
        const id = layer.parentElement?.closest("[id]")?.id || "";
        const rival = id.includes("32")
          ? "Birdman Phil Picasso"
          : id.includes("33") || id.includes("30")
            ? "Bruza The Serb"
            : id.includes("34") || id.includes("35")
              ? "Al Straya"
              : "The Gatekeeper";
        replaceActor(b, rival);
      }
    });
    document.querySelectorAll(".fighter .apw-v15-sprite").forEach((img) => {
      const id = img.closest(".fighter")?.id || "";
      const who = id.toLowerCase().includes("gate") ? "The Gatekeeper" : name;
      img.src = sprites[who].idle;
      img.dataset.apw40 = who;
    });
  }
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      refresh();
    });
  });
  observer.observe(document.body, { subtree: true, childList: true });
  document
    .getElementById("careerWrestler")
    ?.addEventListener("change", refresh);
  refresh();
  const panel = document.createElement("section");
  panel.className = "apw40-gallery";
  panel.innerHTML =
    '<h2 style="color:#ffe17a;margin:0 0 6px">★ APW ROSTER SPRITE STUDIO</h2><p style="font-size:12px">24 wrestler designs. Birdman, Bruza, Nikki and Doomslayer now have detailed ready, strike, grapple and recoil artwork. Other states reuse these poses with existing motion effects.</p><label for="apw40-pose">Animation frame </label><select id="apw40-pose" style="padding:8px;background:#0c1530;color:white;border:1px solid #e4b65b"></select><div class="apw40-grid" id="apw40-grid"></div>';
  const poseSel = panel.querySelector("select");
  Object.keys(sprites[names[0]]).forEach((p) =>
    poseSel.add(new Option(p.toUpperCase(), p)),
  );
  const grid = panel.querySelector("#apw40-grid");
  function paint() {
    grid.replaceChildren();
    for (const name of names) {
      const tile = document.createElement("div");
      tile.className = "apw40-tile";
      tile.appendChild(make(name, poseSel.value));
      const label = document.createElement("span");
      label.textContent = name;
      tile.appendChild(label);
      grid.appendChild(tile);
    }
  }
  poseSel.addEventListener("change", paint);
  paint();
  document.querySelector("main")?.appendChild(panel);
  // Existing gameplay retains its original animation logic; preview and in-ring overlays use the new designs.
})();
