/* Core combat and save bootstrap */
/* v7.1: finish any interrupted restore before career modules read browser saves. */
window.APW_SAVE_KEYS = [
  "apwCareer08",
  "apwCareer09",
  "apwTower12",
  "apwChapter13",
  "apwStory27",
  "apwShowdown28",
  "apwConspiracy30",
  "apwCage32",
  "apwMainEvent33",
  "apwChampion34",
  "apw42_career_endings",
  "apw42_release_checks",
  "apw43_options",
  "apw_selected_venue",
  "apw43_slot_1",
  "apw43_slot_2",
  "apw43_slot_3",
];
try {
  const raw = localStorage.getItem("apw71_journal");
  if (raw) {
    if (raw.length > 2200000) throw Error("Recovery journal too large");
    const j = JSON.parse(raw);
    if (
      !j.before ||
      typeof j.before !== "object" ||
      Array.isArray(j.before) ||
      Object.keys(j.before).some(
        (k) =>
          !APW_SAVE_KEYS.includes(k) ||
          !(j.before[k] === null || typeof j.before[k] === "string"),
      )
    )
      throw Error("Invalid recovery journal");
    for (const [k, v] of Object.entries(j.before)) {
      if (v === null) localStorage.removeItem(k);
      else localStorage.setItem(k, v);
    }
    localStorage.removeItem("apw71_journal");
    window.APW_SAVE_RECOVERED = true;
  }
} catch (e) {
  window.APW_SAVE_RECOVERY_FAILED = true;
}

/* TEAM B stability: bootstrap required before engine reset. */
window.APW_CAREER = window.APW_CAREER || {
  name: "Gideon Hark",
  wins: 0,
  qualified: false,
};

/* TEAM B lifecycle/save compatibility layer. Existing keys and envelopes retained. */
window.APW_TEAM_B = {
  resets: [],
  register(fn) {
    this.resets.push(fn);
  },
  restore(base, value) {
    if (
      !value ||
      typeof value !== "object" ||
      Array.isArray(value) ||
      (value._career && value._career !== window.APW_CAREER.name)
    )
      return { ...base };
    const out = { ...base, ...value };
    for (const [k, v] of Object.entries(base)) {
      if (Array.isArray(v)) {
        if (!Array.isArray(out[k])) out[k] = [...v];
      } else if (typeof v === "number") {
        if (!Number.isFinite(out[k])) out[k] = v;
        else out[k] = Math.max(0, Math.floor(out[k]));
      } else if (typeof out[k] !== typeof v) out[k] = v;
    }
    if (
      "trainingStats" in out &&
      (!Array.isArray(out.trainingStats) ||
        out.trainingStats.length !== 6 ||
        out.trainingStats.some((n) => !Number.isFinite(n) || n < 0 || n > 100))
    )
      delete out.trainingStats;
    if (
      "politics" in out &&
      (!out.politics ||
        typeof out.politics !== "object" ||
        Array.isArray(out.politics))
    )
      delete out.politics;
    const ranges = {
      phase: [0, 4],
      stage: [0, 4],
      floor: [0, 7],
      chapter: base.chapter >= 20 ? [20, 24] : [0, 4],
    };
    for (const [k, [lo, hi]] of Object.entries(ranges))
      if (k in base && (out[k] < lo || out[k] > hi)) out[k] = base[k];
    return out;
  },
  story() {
    let value;
    try {
      value = JSON.parse(localStorage.getItem("apwStory27") || "null");
    } catch (e) {}
    const data = this.restore(
      { chapter: 0, respect: 0, heat: 0, allies: [], decisions: [] },
      value,
    );
    data.chapter = Math.min(4, data.chapter);
    data.allies = data.allies.filter((x) => typeof x === "string");
    data.decisions = data.decisions.filter(
      (x) => x && Number.isInteger(x.chapter) && Number.isInteger(x.choice),
    );
    return data;
  },
  store(key, value) {
    const keys = [
      "apwCareer09",
      "apwTower12",
      "apwChapter13",
      "apwStory27",
      "apwShowdown28",
      "apwConspiracy30",
      "apwCage32",
      "apwMainEvent33",
      "apwChampion34",
    ];
    if (keys.includes(key)) {
      const obj = JSON.parse(value);
      obj._career = window.APW_CAREER.name;
      value = JSON.stringify(obj);
    }
    try {
      localStorage.setItem(key, value);
    } catch (err) {
      let notice = document.getElementById("apwTeamBSaveNotice");
      if (!notice) {
        notice = document.createElement("p");
        notice.id = "apwTeamBSaveNotice";
        notice.setAttribute("role", "alert");
        (document.querySelector(".career-panel") || document.body).append(
          notice,
        );
      }
      notice.textContent =
        "Progress could not be saved. Browser storage may be unavailable or full. Keep this page open until you can save successfully.";
      throw err;
    }
  },
};
try {
  const saved = JSON.parse(localStorage.getItem("apwCareer08") || "null");
  if (
    saved &&
    Array.from(document.getElementById("careerWrestler").options).some(
      (o) => o.value === saved.name,
    )
  ) {
    window.APW_CAREER = {
      name: saved.name,
      wins: Number.isFinite(saved.wins)
        ? Math.max(0, Math.floor(saved.wins))
        : 0,
      qualified: saved.qualified === true,
    };
  }
} catch (err) {}

window.APW_GROWTH = {
  stats() {
    try {
      const p = JSON.parse(localStorage.getItem("apwCareer09") || "{}");
      if (
        p.name === APW_CAREER.name &&
        (!p._career || p._career === APW_CAREER.name)
      )
        return Array.from({ length: 6 }, (_, i) =>
          Number.isFinite(p.stats?.[i])
            ? Math.max(50, Math.min(100, p.stats[i]))
            : 50,
        );
    } catch (e) {}
    return [50, 50, 50, 50, 50, 50];
  },
  bonus(s, i) {
    return Math.max(0, Math.min(50, (s?.[i] || 50) - 50));
  },
  hit(n, s) {
    return Math.round(
      n * (1 + this.bonus(s, 0) * 0.003 + this.bonus(s, 3) * 0.001),
    );
  },
  hurt(n, s) {
    return Math.round(n * (1 - this.bonus(s, 4) * 0.004));
  },
  recovery(s) {
    return Math.floor(this.bonus(s, 1) / 10);
  },
  momentum(s) {
    return Math.floor(this.bonus(s, 5) / 10);
  },
  xp(n, s) {
    return Math.round(n * (1 + this.bonus(s, 5) * 0.002));
  },
  cost(n, s) {
    return Math.max(0, n - Math.floor(this.bonus(s, 2) / 25));
  },
  reward(won, s) {
    window.APW_TRAINING?.award(won, this.xp(won ? 100 : 40, s));
  },
};

/* Politics snapshots: derived from saved decisions, committed at each match start. */
window.APW_STAKES = {
  read() {
    const story = APW_TEAM_B.story();
    let side = {};
    try {
      side = JSON.parse(localStorage.getItem("apwChapter13") || "{}") || {};
    } catch (e) {}
    if (
      side.name !== APW_CAREER.name ||
      (side._career && side._career !== APW_CAREER.name)
    )
      side = {};
    const choice = (n) => story.decisions.find((d) => d.chapter === n)?.choice;
    const ally =
      choice(1) === 2
        ? ""
        : ["Doomslayer", "Taras Jones"].find((x) => story.allies.includes(x)) ||
          (["Doomslayer", "Taras Jones", "Trucker Mark Taylor"].includes(
            side.ally,
          )
            ? side.ally
            : "");
    return {
      opening: choice(0),
      ally,
      independent: choice(1) === 2,
      office: choice(2),
      champion: choice(3),
      heat: story.heat,
      sideHeat: side.heat || 0,
      warnings: Math.min(
        2,
        (choice(2) === 0 ? 1 : 0) +
          (ally === "Taras Jones" ? 1 : 0) +
          (choice(3) === 2 ? 1 : 0) +
          (side.evidence >= 3 ? 1 : 0),
      ),
      usedWarnings: 0,
      debtPaid: false,
      notices: [],
    };
  },
  init(s) {
    const p = this.read();
    s.politics = p;
    let momentum =
      (p.opening === 0 ? 10 : p.opening === 1 ? 5 : 0) +
      (p.independent ? 10 : 0) +
      (p.office === 2 ? 10 : 0) +
      (p.champion === 1 ? 10 : 0);
    let stamina =
      (p.opening === 2 ? 8 : 0) +
      (p.office === 1 ? 15 : 0) +
      (p.ally === "Trucker Mark Taylor" ? 10 : 0);
    if (typeof s.momentum === "number")
      s.momentum = Math.min(100, s.momentum + momentum);
    if (typeof s.stamina === "number")
      s.stamina = Math.min(100, s.stamina + stamina);
    else if (p.office === 1 && typeof s.momentum === "number")
      s.momentum = Math.min(100, s.momentum + 8);
    // Existing evidence and referee mechanics remain; new proof comes from actual choices.
    if (typeof s.proof === "number" && p.warnings) s.proof += 1;
    if (typeof s.evidence === "number" && p.ally === "Taras Jones")
      s.evidence = Math.max(s.evidence, 1);
  },
  clearNotices(s) {
    if (
      s.politics &&
      typeof s.politics === "object" &&
      !Array.isArray(s.politics)
    )
      s.politics.notices = [];
  },
  counter(s, n, delta, kind) {
    const p = s.politics;
    if (!p || typeof p !== "object" || Array.isArray(p)) return n;
    if (!Number.isInteger(p.warnings) || p.warnings < 0 || p.warnings > 2)
      p.warnings = 0;
    if (!Number.isInteger(p.usedWarnings) || p.usedWarnings < 0)
      p.usedWarnings = 0;
    p.usedWarnings = Math.min(p.usedWarnings, p.warnings);
    const turn = s.turn || 0;
    p.notices = [];
    if (turn === 0) {
      if (p.office === 1 && !p.debtPaid) {
        n += 8;
        p.debtPaid = true;
        p.notices.push(
          "Evangeline calls in her favour: the opponent gets an 8-damage cheap shot.",
        );
      }
      if (p.office === 2) {
        n += 3;
        p.notices.push(
          "Refusing the office brings a 3-damage opening retaliation.",
        );
      }
      if (p.ally === "Doomslayer") {
        n = Math.max(0, n - 4);
        p.notices.push(
          "Doomslayer coaches your defence: 4 less opening damage.",
        );
      }
      if (p.opening === 2) {
        n = Math.max(0, n - 3);
        p.notices.push("Your calm preparation prevents 3 opening damage.");
      }
      if (
        p.champion === 0 &&
        ["eliminator", "main", "defence"].includes(kind)
      ) {
        n = Math.max(0, n - 3);
        p.notices.push("Bruza respects your approach: 3 less opening damage.");
      }
    }
    if (turn % 3 === 2 && (p.opening === 0 || p.sideHeat >= 40)) {
      n += 2;
      p.notices.push("Birdman retaliates over the promo: +2 damage.");
    }
    if (delta > 0) {
      if (p.champion === 1) {
        n += 4;
        delta += 4;
        p.notices.push(
          "Your accusation provokes Nikki: +4 interference damage.",
        );
      }
      if (p.usedWarnings < p.warnings) {
        n = Math.max(0, n - delta);
        p.usedWarnings++;
        p.notices.push(
          "Your evidence alerts David Hilder. He stops the interference.",
        );
      } else if (p.ally === "Trucker Mark Taylor" && !p.truckerUsed) {
        n = Math.max(0, n - delta);
        p.truckerUsed = true;
        p.notices.push("Trucker Mark Taylor stops the interference.");
      }
    }
    return n;
  },
  note(s) {
    return s.politics?.notices?.length
      ? "\n" + s.politics.notices.join("\n")
      : "";
  },
  choiceText(chapter, index) {
    return (
      [
        [
          "+10 starting momentum; +2 damage every third counter",
          "+5 starting momentum",
          "+8 stamina; 3 less opening damage",
        ],
        [
          "Doomslayer: 4 less opening damage and ally protection",
          "Taras: evidence and referee support",
          "+10 starting momentum; no new ally",
        ],
        [
          "Evidence warning stops one interference",
          "+15 stamina (or +8 momentum); opening cheap shot +8 damage",
          "+10 momentum; opening retaliation +3 damage",
        ],
        [
          "Bruza matches: 3 less opening damage",
          "+10 momentum; Nikki interference +4 damage",
          "One extra referee warning",
        ],
      ][chapter]?.[index] || ""
    );
  },
  summary() {
    const p = this.read(),
      out = [];
    if (p.opening === 0)
      out.push(
        "Fiery promo: +10 starting momentum; +2 retaliation damage every third counter.",
      );
    if (p.sideHeat >= 40 && p.opening !== 0)
      out.push(
        "Trashbag Police heat: +2 retaliation damage every third counter.",
      );
    if (p.opening === 1) out.push("Public challenge: +5 starting momentum.");
    if (p.opening === 2)
      out.push(
        "Calm focus: +8 starting stamina where available; 3 less opening damage.",
      );
    if (p.ally === "Doomslayer")
      out.push(
        "Doomslayer: 4 less opening damage, plus existing ally protection.",
      );
    if (p.ally === "Taras Jones")
      out.push(
        "Taras: evidence support and a referee warning against interference.",
      );
    if (p.ally === "Trucker Mark Taylor")
      out.push("Trucker: +10 starting stamina and blocks one interference.");
    if (p.independent)
      out.push("Independent: +10 starting momentum; no ally support.");
    if (p.office === 0)
      out.push("Photograph: one evidence warning against interference.");
    if (p.office === 1)
      out.push(
        "Office deal: +15 starting stamina (or +8 momentum without stamina); an 8-damage opening cheap shot.",
      );
    if (p.office === 2)
      out.push(
        "Refusal: +10 starting momentum; +3 opening retaliation damage.",
      );
    if (p.champion === 0)
      out.push(
        "Respect Bruza: 3 less opening damage in his title-picture matches.",
      );
    if (p.champion === 1)
      out.push(
        "Accuse the office: +10 starting momentum; Nikki’s interference deals 4 extra damage.",
      );
    if (p.champion === 2) out.push("Bruza’s tip: another referee warning.");
    if (p.warnings)
      out.push(
        "Evidence warnings available per match: " +
          p.warnings +
          " (maximum 2).",
      );
    return out;
  },
};
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id),
    clamp = (n, a, b) => Math.max(a, Math.min(b, n)),
    rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
  let training = window.APW_GROWTH.stats(),
    enemyWait = 0;
  let p,
    e,
    over,
    busy,
    defending,
    enemyTimer = null,
    matchEpoch = 0,
    endTimer = null,
    pendingEnd = null;
  const max = { hp: 320, sp: 100, mom: 100 },
    emax = { hp: 380, sp: 100, mom: 100 };
  const matchTimers = new Set();
  function later(fn, ms) {
    const id = setTimeout(() => {
      matchTimers.delete(id);
      fn();
    }, ms);
    matchTimers.add(id);
    return id;
  }
  function clearMatchTimers() {
    matchTimers.forEach((id) => clearTimeout(id));
    matchTimers.clear();
  }
  let apw70SequenceTimers = [];
  function apw70CancelSequence() {
    apw70SequenceTimers.forEach(clearTimeout);
    apw70SequenceTimers = [];
    const a = document.querySelector(".arena");
    if (a)
      a.classList.remove(
        "ringlight",
        "finisher-shake",
        "apw69-ripcordcharge",
        "apw69-ripcordimpact",
        "apw69-ghostcharge",
        "apw69-ghostimpact",
      );
    for (const id of ["gideon", "gatekeeper"]) {
      const el = document.getElementById(id);
      if (el)
        el.classList.remove(
          "grabbing",
          "spinning",
          "slowhit",
          "flyback",
          "haunt",
          "down",
          "finishing",
        );
    }
    for (const id of [
      "cinematic",
      "cinematic-caption",
      "burst",
      "ghosthands",
    ]) {
      const el = document.getElementById(id);
      if (el) el.classList.remove("active", "show", "explode", "on");
    }
  }
  function apw70Stages(stages) {
    apw70CancelSequence();
    for (const [ms, fn] of stages) apw70SequenceTimers.push(later(fn, ms));
  }
  function write(s) {
    let q = document.createElement("p");
    q.textContent = s;
    $("log").prepend(q);
  }
  function animate(who, kind) {
    window.APW72Frames?.pose(
      who,
      {
        attack: "strike",
        finishing: "strike",
        slowhit: "strike",
        grabbing: "grab",
        spinning: "walk",
        flyback: "hurt",
        haunt: "grab",
        hit: "hurt",
        down: "fall",
      }[kind] || "walk",
      kind === "down" ? 950 : 650,
    );
    spriteForAnimation(who, kind);
    let el = $(who);
    el.classList.remove("attack", "hit", "down", "finishing", "haunt");
    void el.offsetWidth;
    el.classList.add(kind);
    later(() => el.classList.remove(kind), kind === "finishing" ? 1000 : 850);
  }
  function impact(targetName) {
    const a = document.querySelector(".arena");
    if (!a) return;
    a.classList.add("shake");
    later(() => a.classList.remove("shake"), 380);
    const target = targetName && document.getElementById(targetName);
    const ringRect = a.getBoundingClientRect();
    if (!ringRect.width || !ringRect.height) return;
    const targetRect = target?.getBoundingClientRect();
    const dirtyZone =
      targetName === "gatekeeper" ? Number(a.dataset.apwDirtyZone) : NaN;
    const impactHeight =
      Number.isFinite(dirtyZone) && dirtyZone >= 0.1 && dirtyZone <= 0.95
        ? dirtyZone
        : 0.54;
    const contact = Number.isFinite(dirtyZone)
      ? window.APW_DIRTY_CONTACT?.point()
      : null;
    const burst = document.createElement("span");
    burst.className = "apw113-single-impact";
    burst.setAttribute("aria-hidden", "true");
    burst.style.setProperty(
      "--x",
      targetRect
        ? Math.max(
            7,
            Math.min(
              93,
              (((contact?.x ?? targetRect.left + targetRect.width * 0.52) -
                ringRect.left) /
                ringRect.width) *
                100,
            ),
          ) + "%"
        : "53%",
    );
    burst.style.setProperty(
      "--y",
      targetRect
        ? Math.max(
            15,
            Math.min(
              88,
              (((contact?.y ??
                targetRect.top + targetRect.height * impactHeight) -
                ringRect.top) /
                ringRect.height) *
                100,
            ),
          ) + "%"
        : "64%",
    );
    a.append(burst);
    later(() => burst.remove(), 580);
  }
  function sequence(who, kind, target, contactDeadline = Infinity) {
    animate(who, kind);
    if (target) {
      later(
        () => {
          if (performance.now() > contactDeadline) return;
          animate(target, kind === "finishing" ? "down" : "hit");
          impact(target);
        },
        kind === "finishing" ? 460 : 260,
      );
    }
  }
  function ripcordSequence() {
    window.APW71Motion?.start("ripcord");
    window.APW72Frames?.pose("gideon", "walk", 500);
    window.APW72Frames?.pose("gatekeeper", "grab", 500);
    const a = document.querySelector(".arena"),
      g = $("gideon"),
      e = $("gatekeeper"),
      c = $("cinematic"),
      cap = $("cinematic-caption"),
      burst = $("burst");
    c.classList.add("active");
    const stages = [
      [
        0,
        () => {
          cap.textContent = "WRIST GRAB";
          c.classList.add("active");
          a.classList.add("apw69-ripcordcharge");
          cap.classList.add("show");
          animate("gideon", "grabbing");
          animate("gatekeeper", "spinning");
        },
      ],
      [
        450,
        () => {
          cap.textContent = "RIPCORD SPIN!";
          animate("gatekeeper", "spinning");
          animate("gideon", "grabbing");
        },
      ],
      [
        1000,
        () => {
          cap.textContent = "SLOW MOTION…";
          animate("gideon", "slowhit");
          animate("gatekeeper", "spinning");
        },
      ],
      [
        1650,
        () => {
          cap.textContent = "RIPCORD CLOTHESLINE!";
          a.classList.add("ringlight", "finisher-shake", "apw69-ripcordimpact");
          burst.classList.remove("explode");
          void burst.offsetWidth;
          burst.classList.add("explode");
          animate("gatekeeper", "flyback");
        },
      ],
      [
        2300,
        () => {
          cap.textContent = "DEVASTATING IMPACT!";
          animate("gatekeeper", "down");
        },
      ],
      [
        2900,
        () => {
          c.classList.remove("active");
          cap.classList.remove("show");
          burst.classList.remove("explode");
          a.classList.remove(
            "ringlight",
            "finisher-shake",
            "apw69-ripcordcharge",
            "apw69-ripcordimpact",
          );
          g.classList.remove("grabbing", "slowhit");
          e.classList.remove("spinning", "flyback");
        },
      ],
    ];
    apw70Stages(stages);
  }
  function fx(t) {
    let el = $("flash");
    el.textContent = t;
    el.classList.remove("on");
    void el.offsetWidth;
    el.classList.add("on");
  }
  function render() {
    for (let [a, o, m] of [
      ["p", p, max],
      ["e", e, emax],
    ])
      for (let k of ["hp", "sp", "mom"]) {
        $(a + k).style.width = (100 * o[k]) / m[k] + "%";
        $(a + k + "t").textContent = o[k];
      }
    document.querySelectorAll("[data-move]").forEach((b) => {
      let m = b.dataset.move,
        c = APW_GROWTH.cost(
          {
            strike: 5,
            grapple: 10,
            dirty: 9,
            finisher: 24,
            pin: 6,
            submission: 14,
            reverse: 8,
          }[m] || 0,
          training,
        );
      b.disabled =
        over ||
        busy ||
        (m === "strike" && p.sp < c) ||
        (m === "grapple" && p.sp < c) ||
        (m === "dirty" && p.sp < c) ||
        (m === "finisher" && (p.sp < c || p.mom < 70)) ||
        (m === "pin" && p.sp < c) ||
        (m === "submission" && p.sp < c) ||
        (m === "reverse" && p.sp < c);
    });
    $("status").textContent = over
      ? "MATCH OVER"
      : busy
        ? opponentName().toUpperCase() + " TURN"
        : "YOUR TURN";
    $("turnlabel").textContent = over
      ? "Match complete"
      : busy
        ? opponentName() + " responds…"
        : "Choose " + APW_CAREER.name + "’s move";
  }
  function damage(target, amount) {
    amount =
      target === p
        ? APW_GROWTH.hurt(amount, training)
        : APW_GROWTH.hit(amount, training);
    target.hp = clamp(target.hp - amount, 0, target === p ? 320 : 380);
    return amount;
  }
  function win(s) {
    if (s.includes("WINS!")) {
      if (!window.APW_OPPONENT || window.APW_OPPONENT === "The Gatekeeper")
        apwVictory();
      else
        window.apwTowerVictory && window.apwTowerVictory(window.APW_OPPONENT);
    }
    const careerAtBell = APW_CAREER,
      match = { opponent: opponentName(), stats: [...training] };
    pendingEnd = () => {
      if (APW_CAREER === careerAtBell)
        window.apwMatchEnd && window.apwMatchEnd(s, match);
    };
    endTimer = later(settleResult, 950);
    over = true;
    write("🔔 " + s);
    fx(
      s.includes("DISQUALIFIED")
        ? "DISQUALIFIED!"
        : s.includes("TAPS OUT")
          ? "TAP OUT!"
          : s.includes("knocked out")
            ? "KNOCKOUT!"
            : "1 • 2 • 3!",
    );
    render();
  }
  function gatekeeperSlamSequence() {
    window.APW71Motion?.start("ghost");
    window.APW72Frames?.pose("gatekeeper", "grab", 650);
    window.APW72Frames?.pose("gideon", "hurt", 650);
    const a = document.querySelector(".arena"),
      g = $("gideon"),
      k = $("gatekeeper"),
      hands = $("ghosthands");
    const c = $("cinematic"),
      cap = $("cinematic-caption");
    const stages = [
      [
        0,
        () => {
          a.classList.add("apw69-ghostcharge");
          c.classList.add("active");
          cap.textContent = "THE GATEKEEPER AWAKENS";
          cap.classList.add("show");
          animate("gatekeeper", "grabbing");
        },
      ],
      [
        340,
        () => {
          cap.textContent = "RED EYES • GHOSTLY HANDS";
          animate("gatekeeper", "haunt");
          hands.classList.remove("on");
          void hands.offsetWidth;
          hands.classList.add("on");
        },
      ],
      [
        840,
        () => {
          cap.textContent = "GHOSTLY HANDS SLAM!";
          a.classList.add("apw69-ghostimpact");
          animate("gideon", "flyback");
          impact();
        },
      ],
      [
        1420,
        () => {
          cap.textContent = "SUPERNATURAL IMPACT!";
          animate("gideon", "down");
        },
      ],
      [
        2060,
        () => {
          c.classList.remove("active");
          cap.classList.remove("show");
          hands.classList.remove("on");
          a.classList.remove("apw69-ghostcharge", "apw69-ghostimpact");
          g.classList.remove("flyback", "down");
          k.classList.remove("haunt", "grabbing");
        },
      ],
    ];
    apw70Stages(stages);
  }
  function enemy() {
    enemyWait = 0;
    if (over) return;
    let action =
      e.mom >= 70 && e.sp >= 28
        ? "ghost"
        : e.sp < 14
          ? "recover"
          : e.sp >= 16 && Math.random() < 0.4
            ? "grapple"
            : "strike";
    if (action === "recover") {
      e.sp = clamp(e.sp + 26, 0, 100);
      write(
        "" + (window.APW_OPPONENT || "The Gatekeeper") + " catches his breath.",
      );
    } else if (action === "ghost") {
      enemyWait = opponentName() === "The Gatekeeper" ? 3350 : 1150;
      e.sp -= 28;
      e.mom -= 70;
      let d = rnd(39, 55);
      if (defending) d = Math.ceil(d * 0.45);
      d = damage(p, d);
      write(
        "🔴 " +
          (window.APW_SPECIALS?.[window.APW_OPPONENT] || "GHOSTLY HANDS SLAM") +
          "! " +
          opponentName() +
          " strikes " +
          careerName() +
          " for " +
          d +
          " damage!",
      );
      fx("GHOSTLY HANDS!");
      if (opponentName() === "The Gatekeeper") gatekeeperSlamSequence();
      else {
        sequence("gatekeeper", "finishing", "gideon");
        fx(
          (
            window.APW_SPECIALS?.[opponentName()] || "SIGNATURE FINISHER"
          ).toUpperCase(),
        );
      }
    } else {
      let cost = action === "grapple" ? 16 : 8,
        d = rnd(action === "grapple" ? 21 : 12, action === "grapple" ? 34 : 23);
      e.sp -= cost;
      e.mom = clamp(e.mom + (action === "grapple" ? 19 : 13), 0, 100);
      if (defending) d = Math.ceil(d * 0.45);
      d = damage(p, d);
      write(
        "" +
          (window.APW_OPPONENT || "The Gatekeeper") +
          " uses " +
          (action === "grapple" ? "a crushing grapple" : "a heavy strike") +
          " for " +
          d +
          " damage.",
      );
      fx("−" + d);
      sequence("gatekeeper", "attack", "gideon");
    }
    e.sp = clamp(e.sp + 6, 0, 100);
    defending = false;
    if (p.hp <= 0)
      win(careerName() + " is knocked out. " + opponentName() + " wins.");
    render();
  }
  function careerName() {
    return window.APW_CAREER?.name || "Gideon Hark";
  }
  function opponentName() {
    return window.APW_OPPONENT || "The Gatekeeper";
  }
  function signature() {
    return (
      window.APW_SPECIALS?.[careerName()] ||
      {
        "Gideon Hark": "Ripcord Clothesline",
        "Simon Temple": "Choke Slam",
        "Birdman Phil Picasso": "Double Underhook DDT",
        "Bruza The Serb": "Russian Leg Sweep",
        "Nikki Poteet": "Running Cannonball",
        "Johnny Putrid": "The Stroke",
        "Nightmare Cat": "The Cat Splash",
        TNT: "The Unprettier",
        "Whiskey Sixx": "450 Splash",
        "Mauler Y": "Running Splash",
        "Al Straya": "44 Gallon Drum to the Head",
        "Trucker Mark Taylor": "The Final Cut",
        "Taras Jones": "Rear Naked Choke",
        "Harvey Falco": "Falcon Punch",
        Doomslayer: "Map of Tassie",
        "Drako Savage": "Finger Poke of Doom",
        "Trashbag Dan": "The Oil Check",
        "Eli Driftwood": "Five Star Frog Splash",
        "Jay Payne": "Guitar Smash",
        "Black Diamond": "Black Diamond Strike",
        "The Outlaw": "Outlaw Finisher",
        "Evangeline Strange": "Running Neckbreaker",
        "Hotshot Hansel": "Power Slam",
      }[careerName()] ||
      "Signature Finisher"
    );
  }
  function move(m) {
    if (over || busy) return;
    if (
      ![
        "strike",
        "grapple",
        "defend",
        "dirty",
        "finisher",
        "pin",
        "submission",
        "reverse",
      ].includes(m)
    )
      return;
    let cost = {
      strike: 5,
      grapple: 10,
      defend: 0,
      dirty: 9,
      finisher: 24,
      pin: 6,
      submission: 14,
      reverse: 8,
    }[m];
    cost = APW_GROWTH.cost(cost, training);
    if (p.sp < cost || (m === "finisher" && p.mom < 70)) return;
    p.sp -= cost;
    if (m === "strike") {
      let d = rnd(17, 27);
      d = damage(e, d);
      p.mom = clamp(p.mom + 17 + APW_GROWTH.momentum(training), 0, 100);
      write(careerName() + " lands a forearm smash! " + d + " damage.");
      fx("POW!");
      sequence("gideon", "attack", "gatekeeper");
    }
    if (m === "grapple") {
      let d = rnd(25, 39);
      d = damage(e, d);
      p.mom = clamp(p.mom + 23 + APW_GROWTH.momentum(training), 0, 100);
      write(careerName() + " delivers a powerful suplex! " + d + " damage.");
      fx("SLAM!");
      sequence("gideon", "attack", "gatekeeper");
    }
    if (m === "defend") {
      defending = true;
      p.sp = clamp(p.sp + 28 + APW_GROWTH.recovery(training), 0, 100);
      p.mom = clamp(p.mom + 6 + APW_GROWTH.momentum(training), 0, 100);
      write(careerName() + " braces for impact and recovers 28 stamina.");
    }
    if (m === "dirty") {
      const caught = Math.random() < 0.25;
      window.dispatchEvent(
        new CustomEvent("apw:dirty-trick", {
          detail: {
            wrestler: careerName(),
            outcome: caught ? "caught" : "landed",
          },
        }),
      );
      if (caught) {
        win(
          "David Hilder catches " + careerName() + " cheating! DISQUALIFIED.",
        );
        return;
      }
      let d = rnd(32, 50);
      d = damage(e, d);
      p.mom = clamp(p.mom + 25 + APW_GROWTH.momentum(training), 0, 100);
      write(
        careerName() +
          " sneaks in a DIRTY TRICK! " +
          d +
          " damage. David Hilder misses it!",
      );
      const hold =
        window.APW_DIRTY_ART?.profiles?.()[careerName()]?.hold ?? 200;
      sequence(
        "gideon",
        "attack",
        "gatekeeper",
        performance.now() + 260 + hold,
      );
    }
    if (m === "finisher") {
      p.mom -= 70;
      window.dispatchEvent(
        new CustomEvent("apw:finisher", { detail: { wrestler: careerName() } }),
      );
      let d = rnd(65, 87);
      d = damage(e, d);
      write(
        "★ " +
          signature().toUpperCase() +
          "! " +
          careerName() +
          " hits " +
          opponentName() +
          " for " +
          d +
          " damage!",
      );
      if (careerName() === "Gideon Hark") ripcordSequence();
      else {
        sequence("gideon", "finishing", "gatekeeper");
        fx(signature().toUpperCase());
        impact();
      }
    }
    if (m === "submission") {
      let chance = clamp(
        0.04 +
          (1 - e.hp / 380) * 0.72 +
          (p.mom / 100) * 0.14 +
          APW_GROWTH.bonus(training, 3) * 0.001,
        0.04,
        0.91,
      );
      if (Math.random() < chance) {
        win(
          "David Hilder signals for the bell! " +
            opponentName() +
            " TAPS OUT! " +
            careerName().toUpperCase() +
            " WINS!",
        );
        return;
      }
      write(opponentName() + " struggles free of the submission hold!");
      fx("ROPE BREAK!");
      p.mom = clamp(p.mom + 8 + APW_GROWTH.momentum(training), 0, 100);
    }
    if (m === "reverse") {
      defending = true;
      p.mom = clamp(p.mom + 16 + APW_GROWTH.momentum(training), 0, 100);
      p.sp = clamp(p.sp + 10, 0, 100);
      write(
        careerName() +
          " prepares a counter! Incoming damage reduced; momentum gained.",
      );
      fx("COUNTER READY!");
    }
    if (m === "pin") {
      let chance = clamp(
        0.04 + (1 - e.hp / 380) * 0.8 + (e.hp <= 0 ? 0.16 : 0),
        0.04,
        0.95,
      );
      if (Math.random() < chance) {
        win(
          "David Hilder counts ONE… TWO… THREE! " +
            APW_CAREER.name.toUpperCase() +
            " WINS!",
        );
        return;
      }
      write(
        "David Hilder counts ONE… TWO… KICK OUT! " +
          opponentName() +
          " escapes.",
      );
      fx("2 COUNT!");
      animate("gatekeeper", "down");
      p.mom = clamp(p.mom + 9 + APW_GROWTH.momentum(training), 0, 100);
    }
    p.sp = clamp(p.sp + 12 + APW_GROWTH.recovery(training), 0, 100);
    if (e.hp <= 0) {
      write(opponentName() + " is down! Attempt a PIN to win!");
    }
    busy = true;
    render();
    const epoch = matchEpoch;
    enemyTimer = later(
      () => {
        if (epoch !== matchEpoch) return;
        enemyTimer = null;
        enemy();
        if (enemyWait && !over) {
          enemyTimer = later(() => {
            if (epoch !== matchEpoch) return;
            enemyTimer = null;
            busy = false;
            render();
          }, enemyWait);
        } else busy = false;
        render();
      },
      m === "finisher" ? 3350 : 1150,
    );
  }
  function settleResult() {
    clearTimeout(endTimer);
    endTimer = null;
    const fn = pendingEnd;
    pendingEnd = null;
    if (fn) fn();
  }
  window.APW_TEAM_B.settleResult = settleResult;
  window.APW_TEAM_B.hasPendingResult = () => !!pendingEnd;
  function reset() {
    settleResult();
    window.APW85Chokeslam?.clear();
    window.APW72Frames?.clear();
    window.APW71Motion?.clear();
    apw70CancelSequence();
    clearMatchTimers();
    ["gideon", "gatekeeper"].forEach((id) =>
      $(id).classList.remove(
        "attack",
        "hit",
        "down",
        "finishing",
        "haunt",
        "grabbing",
        "slowhit",
        "spinning",
        "flyback",
      ),
    );
    document.querySelector(".arena").classList.remove("shake");
    document
      .querySelectorAll(".arena .apw113-single-impact")
      .forEach((node) => node.remove());
    $("burst").classList.remove("explode");
    $("cinematic-caption").classList.remove("show");
    $("ghosthands").classList.remove("on");
    clearTimeout(enemyTimer);
    enemyTimer = null;
    matchEpoch++;
    document
      .querySelector(".arena")
      .classList.remove("ringlight", "finisher-shake");
    $("cinematic").classList.remove("active");
    training = APW_GROWTH.stats();
    p = { hp: 320, sp: 100, mom: 30 };
    e = { hp: 380, sp: 85, mom: 10 };
    over = false;
    busy = false;
    defending = false;
    $("log").innerHTML = "";
    write(
      "🔔 The bell rings! " +
        APW_CAREER.name +
        " faces " +
        (window.APW_OPPONENT || "The Gatekeeper") +
        ". Select a move to begin.",
    );
    render();
  }
  document
    .querySelectorAll("[data-move]")
    .forEach((b) => b.addEventListener("click", () => move(b.dataset.move)));
  $("restart").addEventListener("click", reset);
  reset();
})();

const APW_SPRITES = {
  gideon: {
    idle: APW_MEDIA[0],
    walk: APW_MEDIA[1],
    strike: APW_MEDIA[2],
    grapple: APW_MEDIA[3],
    hit: APW_MEDIA[4],
    down: APW_MEDIA[5],
    finisher: APW_MEDIA[6],
  },
  gatekeeper: {
    idle: APW_MEDIA[7],
    walk: APW_MEDIA[8],
    strike: APW_MEDIA[9],
    grapple: APW_MEDIA[10],
    hit: APW_MEDIA[11],
    down: APW_MEDIA[12],
    finisher: APW_MEDIA[13],
  },
};
const spriteTimers = {};
function spritePose(who, pose, duration = 0) {
  const node = document.getElementById(who + "-sprite");
  if (!node) return;
  clearTimeout(spriteTimers[who]);
  node.src = APW_SPRITES[who][pose] || APW_SPRITES[who].idle;
  if (duration)
    spriteTimers[who] = setTimeout(() => {
      node.src = APW_SPRITES[who].idle;
    }, duration);
}
function spriteForAnimation(who, kind) {
  const pose =
    {
      attack: "strike",
      finishing: "finisher",
      slowhit: "finisher",
      grabbing: "grapple",
      spinning: "walk",
      flyback: "hit",
      haunt: "grapple",
      hit: "hit",
      down: "down",
    }[kind] || "idle";
  spritePose(
    who,
    pose,
    kind === "down" ? 1100 : kind === "finishing" ? 1200 : 850,
  );
}
