/* Visual-only contact blocking. Coordinates refer to the existing 384 x 256 cels. */
(() => {
  "use strict";
  let active = null,
    victim = null,
    victimTimer = 0;
  const style = document.createElement("style");
  style.textContent = `#fighters #gatekeeper.apw121-dirty-victim > .apw72-part{display:none!important;visibility:hidden!important}#fighters #gatekeeper.apw121-dirty-victim > img.apw61-hero{display:block!important;visibility:visible!important;opacity:1!important}`;
  document.head.append(style);
  const bounds = new WeakMap();
  // Union of the three existing cels, padded for the small upper-body lean.
  const poseBounds = {
    "Birdman Phil Picasso": [79, 38, 382, 244],
    "Bruza The Serb": [77, 22, 286, 244],
    "Nikki Poteet": [78, 22, 320, 244],
    "Gideon Hark": [47, 22, 362, 244],
    "Simon Temple": [61, 22, 353, 244],
    "Whiskey Sixx": [49, 22, 378, 244],
    "Mauler Y": [49, 34, 382, 244],
    Doomslayer: [46, 22, 336, 244],
    "Taras Jones": [2, 51, 284, 244],
    "Trucker Mark Taylor": [51, 22, 270, 244],
    "Harvey Falco": [53, 33, 382, 244],
    "Al Straya": [40, 22, 379, 244],
    TNT: [45, 22, 327, 244],
    "Johnny Putrid": [45, 22, 332, 244],
    "Nightmare Cat": [50, 18, 371, 244],
    "Drako Savage": [87, 14, 371, 244],
    "Trashbag Dan": [80, 45, 383, 244],
    "Eli Driftwood": [86, 73, 384, 244],
    "Jay Payne": [76, 21, 322, 244],
    "The Outlaw": [50, 22, 378, 244],
    "Black Diamond": [78, 22, 378, 244],
    "Hotshot Hansel": [60, 22, 382, 244],
    "Evangeline Strange": [64, 22, 379, 244],
  };
  function opaqueBox(image) {
    const previous = bounds.get(image);
    if (previous?.src === image.currentSrc) return previous.box;
    try {
      const canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      ctx.drawImage(image, 0, 0);
      const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      let left = canvas.width,
        top = canvas.height,
        right = -1,
        bottom = -1;
      for (let y = 0; y < canvas.height; y++)
        for (let x = 0; x < canvas.width; x++)
          if (pixels[(y * canvas.width + x) * 4 + 3] > 32) {
            left = Math.min(left, x);
            top = Math.min(top, y);
            right = Math.max(right, x);
            bottom = Math.max(bottom, y);
          }
      const box =
        right >= left
          ? { left, top, right: right + 1, bottom: bottom + 1 }
          : null;
      bounds.set(image, { src: image.currentSrc, box });
      return box;
    } catch {
      return null;
    }
  }
  function visible(node) {
    if (!node) return false;
    const style = getComputedStyle(node),
      r = node.getBoundingClientRect();
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      +style.opacity > 0 &&
      r.width > 0 &&
      r.height > 0
    );
  }
  function targetBox(target) {
    // Prefer the active renderer; the articulated body's image keeps the source registration.
    const art = [
      "canvas.apw114-cel",
      ".apw82-roster-sprite",
      ".apw84-simon-art",
      ".apw72-body",
      ".apw61-hero",
      ".pixel-sprite",
    ]
      .map((selector) => target.querySelector(selector))
      .find(visible);
    if (!art) return target.getBoundingClientRect();
    const rect = art.getBoundingClientRect();
    const width = art.naturalWidth || art.width,
      height = art.naturalHeight || art.height;
    if (!width || !height) return rect;
    const scale = Math.min(rect.width / width, rect.height / height);
    const source = art.tagName === "IMG" ? opaqueBox(art) : null;
    const box = source || { left: 0, top: 0, right: width, bottom: height };
    const mirrored = getComputedStyle(art).scale.split(" ")[0] === "-1";
    const left = mirrored ? width - box.right : box.left;
    // All supported active renderers use centered, bottom-aligned object-fit:contain.
    return {
      left: rect.left + (rect.width - width * scale) / 2 + left * scale,
      top: rect.bottom - height * scale + box.top * scale,
      width: (box.right - box.left) * scale,
      height: (box.bottom - box.top) * scale,
    };
  }
  function clearVictim() {
    clearTimeout(victimTimer);
    victim?.classList.remove("apw121-dirty-victim");
    victim = null;
  }
  function clear(keepReaction = false) {
    clearTimeout(victimTimer);
    if (keepReaction && victim?.classList.contains("hit"))
      victimTimer = setTimeout(clearVictim, 220);
    else clearVictim();
    if (!active) return;
    for (const [node, key, value, priority] of active.saved)
      if (value) node.style.setProperty(key, value, priority);
      else node.style.removeProperty(key);
    delete active.actor.dataset.apwContactOffset;
    active = null;
  }
  function prepare(actor, canvas, detail, profile) {
    clear();
    if (
      !actor ||
      !canvas ||
      detail?.outcome !== "landed" ||
      !Array.isArray(profile?.contact)
    )
      return null;
    const target = document.getElementById("gatekeeper"),
      arena = document.querySelector(".arena");
    if (!target || !arena) return null;
    const ring = arena.getBoundingClientRect(),
      rect = canvas.getBoundingClientRect();
    if (!ring.width || !rect.width || !rect.height) return null;
    const originalScale = Math.min(rect.width / 384, rect.height / 256);
    const originalLeft = rect.left + (rect.width - 384 * originalScale) / 2;
    const footX = originalLeft + 160 * originalScale;
    const footY = rect.bottom - 12 * originalScale;
    const point = targetBox(target);
    const targetY = point.top + point.height * profile.zone;
    const desiredScale = (footY - targetY) / (244 - profile.contact[1]);
    // Size once at setup, keeping the same mat anchor. Bounds prevent a crouched move
    // from becoming a giant wrestler merely to reach the opponent's head.
    // Meet the front half of the struck body, rather than the far edge of its transparent image box.
    const front =
      profile.zone <= 0.25
        ? 0.38
        : profile.zone > 0.82
          ? 0.3
          : profile.zone > 0.6
            ? 0.35
            : 0.46;
    const targetX = point.left + point.width * front;
    const leanWeight = Math.max(
      0,
      Math.min(1, (224 - profile.contact[1]) / 96),
    );
    const lean = Math.round(
      profile.reach * leanWeight * leanWeight * (3 - 2 * leanWeight),
    );
    const extents = poseBounds[detail.wrestler] || [0, 0, 384, 256];
    const maximumScale = Math.min(
      originalScale * 1.3,
      (ring.width - 10) / (extents[2] - extents[0]),
      (footY - ring.top - 5) / (244 - extents[1]),
      (targetX - ring.left - 5) /
        Math.max(1, profile.contact[0] + lean - extents[0]),
      (ring.right - 5 - targetX) /
        Math.max(1, extents[2] - profile.contact[0] - lean),
    );
    const scale = Math.min(
      maximumScale,
      Math.max(originalScale * 0.75, desiredScale),
    );
    if (!(scale > 0)) return null;
    const contentLeft = footX - 160 * scale;
    const contactX = contentLeft + (profile.contact[0] + lean) * scale;
    const contactY = footY - (244 - profile.contact[1]) * scale;
    const desired = targetX - contactX;
    // Keep every opaque cel pixel inside the ring; transparent margins may overhang.
    // No stretching or mid-gesture foot sliding.
    const low = ring.left + 5 - (contentLeft + extents[0] * scale);
    const high = ring.right - 5 - (contentLeft + extents[2] * scale);
    const offset = Math.round(Math.max(low, Math.min(high, desired)));
    if (!Number.isFinite(offset) || low > high) return null;
    active = {
      actor,
      point: { x: targetX, y: targetY },
      saved: [
        ...["transform", "transition"].map((key) => [
          actor,
          key,
          actor.style.getPropertyValue(key),
          actor.style.getPropertyPriority(key),
        ]),
        ...["left", "bottom", "width", "height"].map((key) => [
          canvas,
          key,
          canvas.style.getPropertyValue(key),
          canvas.style.getPropertyPriority(key),
        ]),
      ],
    };
    if (
      visible(target.querySelector(".apw72-body")) &&
      target.querySelector(".apw61-hero")?.naturalWidth
    ) {
      victim = target;
      target.classList.add("apw121-dirty-victim");
    }
    const actorRect = actor.getBoundingClientRect();
    canvas.style.setProperty(
      "left",
      `${contentLeft - actorRect.left}px`,
      "important",
    );
    canvas.style.setProperty(
      "bottom",
      `${actorRect.bottom - footY - 12 * scale}px`,
      "important",
    );
    canvas.style.setProperty("width", `${384 * scale}px`, "important");
    canvas.style.setProperty("height", `${256 * scale}px`, "important");
    actor.style.setProperty(
      "transform",
      `translateX(${offset}px)`,
      "important",
    );
    actor.style.setProperty("transition", "none", "important");
    actor.dataset.apwContactOffset = String(offset);
    return {
      offset,
      scaleRatio: scale / originalScale,
      footX: footX + offset,
      footY,
      targetX,
      targetY,
      contactX: contactX + offset,
      contactY,
      residual: targetX - contactX - offset,
      residualY: targetY - contactY,
    };
  }
  window.APW_DIRTY_CONTACT = {
    prepare,
    clear,
    point: () => (active ? { ...active.point } : null),
  };
})();
