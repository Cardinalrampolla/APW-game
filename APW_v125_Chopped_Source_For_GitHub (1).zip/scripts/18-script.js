/* Champion presentation */
(() => {
  "use strict";
  const root = document.getElementById("apw34"),
    old = document.getElementById("apw34ring");
  if (!root || !old) return;
  const wrap = document.createElement("div");
  wrap.id = "apw35visual";
  old.parentNode.insertBefore(wrap, old);
  wrap.appendChild(old);
  old.style.visibility = "hidden";
  const canvas = document.createElement("canvas");
  canvas.width = 480;
  canvas.height = 240;
  wrap.appendChild(canvas);
  const banner = document.createElement("div");
  banner.id = "apw35banner";
  wrap.appendChild(banner);
  const impact = document.createElement("div");
  impact.id = "apw35impact";
  wrap.appendChild(impact);
  const belt = document.createElement("div");
  belt.id = "apw35belt";
  belt.textContent = "🏆";
  wrap.appendChild(belt);
  const note = document.createElement("div");
  note.className = "apw35note";
  note.textContent = "v3.5 • CINEMATIC SPRITES";
  wrap.appendChild(note);
  root.querySelector("h2").textContent =
    "🏆 v3.5 — CHAMPIONSHIP ARCADE UPGRADE";
  root.querySelector("small").textContent =
    "Chapters 20–24 • Enhanced wrestler-specific sprites • Animated finishers • Championship celebrations • Browser autosave";
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  let frame = 0,
    anim = "",
    until = 0,
    lastButton = "";
  const $ = (id) => document.getElementById(id);
  function block(x, y, w, h, c) {
    ctx.fillStyle = c;
    ctx.fillRect(Math.round(x), Math.round(y), w, h);
  }
  function figure(cx, cy, name, enemy = false) {
    let n = name.toLowerCase(),
      temple = n.includes("temple"),
      bird = n.includes("birdman"),
      bruz = n.includes("bruza"),
      al = n.includes("straya"),
      whiskey = n.includes("whiskey"),
      mauler = n.includes("mauler"),
      gideon = n.includes("gideon"),
      nikki = n.includes("nikki"),
      tnt = n === "tnt",
      cat = n.includes("cat"),
      putrid = n.includes("putrid");
    let size = temple ? 1.28 : mauler ? 1.2 : bruz ? 1.16 : 1;
    let bob = Math.round(Math.sin(frame / 11 + (enemy ? 3 : 0)) * 2);
    let attack = Date.now() < until;
    let lunge = attack ? (enemy ? -13 : 13) : 0;
    let x = Math.round(cx + lunge),
      y = Math.round(cy + bob);
    let skin = cat ? "#777c85" : "#c78e71",
      gear =
        temple || gideon
          ? "#d65b94"
          : bruz
            ? "#262a39"
            : bird
              ? "#171a25"
              : al
                ? "#343b40"
                : whiskey
                  ? "#a72842"
                  : mauler
                    ? "#171c22"
                    : nikki
                      ? "#caa145"
                      : tnt
                        ? "#181820"
                        : "#a33255";
    let hair =
      bird || bruz
        ? "#b17c62"
        : whiskey
          ? "#e8ce79"
          : cat
            ? "#333743"
            : gideon
              ? "#6b3b27"
              : putrid
                ? "#201820"
                : tnt
                  ? "#211820"
                  : "#442e2d";
    ctx.save();
    ctx.translate(x, y);
    ctx.scale((enemy ? -1 : 1) * size, size);
    ctx.translate(0, -94);
    block(-17, 70, 13, 31, "#111420");
    block(4, 70, 13, 31, "#111420");
    block(-20, 93, 16, 7, "#080b15");
    block(4, 93, 16, 7, "#080b15");
    block(-22, 29, 44, 43, gear);
    block(-28, 34, 8, 35, skin);
    block(20, 34, 8, 35, skin);
    block(-29, 58, 9, 10, gear);
    block(20, 58, 9, 10, gear);
    block(-15, 1, 30, 30, skin);
    block(-17, -1, 34, 9, hair);
    if (!bird && !bruz) block(-19, 5, 5, 25, hair);
    block(-9, 15, 5, 3, "#191322");
    block(5, 15, 5, 3, "#191322");
    if (bird) {
      block(-20, 38, 40, 5, "#555767");
      block(-8, 22, 16, 5, "#4b2b25");
      block(-12, 46, 7, 13, "#45404c");
    }
    if (bruz) {
      block(-18, 35, 36, 6, "#bd303c");
      block(-7, 45, 14, 15, "#d9d9df");
    }
    if (temple) {
      block(-25, 30, 50, 8, "#e977ae");
      block(-15, 43, 30, 9, "#4d4554");
    }
    if (mauler) {
      block(-16, 1, 32, 27, "#a02d3a");
      block(-11, 17, 22, 4, "#f2e5dd");
    }
    if (whiskey) block(-18, 4, 5, 27, "#e8ce79");
    if (nikki) block(-20, 36, 40, 9, "#e9c45c");
    if (cat) {
      block(-15, -7, 9, 12, "#444850");
      block(6, -7, 9, 12, "#444850");
      block(-5, 27, 10, 6, "#d84a60");
    }
    if (al) block(-8, -8, 14, 11, "#6e3626");
    if (gideon) block(-19, 2, 6, 27, "#633b2b");
    if (attack) {
      block(20, 32, 22, 9, skin);
      block(38, 30, 9, 12, gear);
    }
    ctx.restore();
  }
  function paint() {
    frame++;
    const st = $("apw34story")?.textContent || "";
    const match = /CHAPTER 23/.test(st),
      verdict = /CHAPTER 24/.test(st),
      win = verdict && /reign survives/i.test(st);
    const name = $("careerWrestler")?.value || "Gideon Hark";
    let opp = /Birdman Phil Picasso/.test(st)
      ? "Birdman Phil Picasso"
      : /Al Straya/.test(st)
        ? "Al Straya"
        : "Bruza The Serb";
    wrap.style.display = old.hidden ? "none" : "block";
    wrap.classList.toggle("victory", win);
    banner.textContent = win
      ? "NEW CHAMPION!"
      : match
        ? "HEAVYWEIGHT TITLE DEFENCE"
        : "APW • NO TEA PARTY!";
    ctx.fillStyle = "#10152b";
    ctx.fillRect(0, 0, 480, 240);
    for (let i = 0; i < 480; i += 12) {
      block(i, 45, 10, 55, i % 36 ? "#302744" : "#54314d");
      block(i, 80 + ((i * 7) % 17), 7, 8, "#a57a84");
    }
    block(0, 112, 480, 128, "#665172");
    block(0, 145, 480, 95, "#847391");
    for (let j = 0; j < 3; j++) {
      block(8, 110 + j * 20, 464, 3, "#e8d8c6");
    }
    for (let x of [9, 465]) block(x, 92, 7, 139, "#2a2738");
    block(12, 204, 456, 6, "#382d4a");
    let movement = Date.now() < until;
    figure(143, 211, name);
    figure(334, 211, opp, true);
    if (movement) {
      block(230, 138, 19, 19, "#fff5b1");
      block(222, 147, 35, 3, "#ffbd42");
      block(238, 130, 3, 34, "#ffbd42");
    }
    ctx.fillStyle = "#ffe5a3";
    ctx.font = "bold 11px monospace";
    ctx.fillText(name.slice(0, 20).toUpperCase(), 12, 235);
    ctx.fillText(opp.slice(0, 19).toUpperCase(), 300, 235);
    requestAnimationFrame(paint);
  }
  root.addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    lastButton = b.textContent || "";
    if (/Strike|Grapple|Finisher|Guard/.test(lastButton)) {
      anim = lastButton;
      until = Date.now() + (anim.includes("Finisher") ? 950 : 480);
      impact.classList.remove("hit");
      void impact.offsetWidth;
      impact.classList.add("hit");
    }
  });
  paint();
})();
