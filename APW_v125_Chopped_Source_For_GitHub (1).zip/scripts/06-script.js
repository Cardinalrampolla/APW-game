/* Tower progression */
(() => {
  const roster = [
    "The Gatekeeper",
    "Trucker Mark Taylor",
    "Harvey Falco",
    "Al Straya",
    "Simon Temple",
    "Birdman Phil Picasso",
    "Bruza The Serb",
  ];
  const key = "apwTower12";
  let state = { floor: 0, heat: 0, respect: 0, champion: false };
  try {
    state = window.APW_TEAM_B.restore(
      state,
      JSON.parse(localStorage.getItem(key) || "{}"),
    );
  } catch (e) {}
  state.floor = Math.min(7, state.floor);
  state.heat = Math.min(100, state.heat);
  state.respect = Math.min(100, state.respect);
  window.APW_OPPONENT = "The Gatekeeper";
  const panel = document.createElement("section");
  panel.className = "apw-tower";
  panel.innerHTML =
    '<h2>🏆 APW TOWER — NO TEA PARTY!</h2><div id="towerStatus"></div><div id="towerMatches"></div><div id="towerChoices"></div>';
  document
    .querySelector(".career-panel")
    .insertAdjacentElement("afterend", panel);
  const esc = (t) =>
    String(t).replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
  function save() {
    try {
      window.APW_TEAM_B.store(key, JSON.stringify(state));
    } catch (e) {}
  }
  function scene(title, lines) {
    const note = document.getElementById("towerStatus");
    note.textContent = title + " — " + lines;
  }
  function render() {
    let qualified = !!window.APW_CAREER?.qualified;
    let available = qualified ? Math.min(6, Math.max(1, state.floor)) : 0;
    document.getElementById("towerStatus").innerHTML =
      "<small>FLOOR " +
      Math.min(state.floor, 6) +
      "/6 · BIRDMAN HEAT " +
      state.heat +
      " · LOCKER ROOM RESPECT " +
      state.respect +
      "</small>" +
      (state.champion ? "<p>🏆 APW HEAVYWEIGHT CHAMPION!</p>" : "");
    document.getElementById("towerMatches").innerHTML = roster
      .map(
        (name, i) =>
          '<div class="tower-row ' +
          (i > available ? "locked" : "") +
          '"><span>' +
          (i === 0 ? "QUALIFIER" : "FLOOR " + i) +
          " · " +
          esc(name) +
          (i < state.floor ? " ✓" : "") +
          '</span><button data-floor="' +
          i +
          '" ' +
          (i > available ? "disabled" : "") +
          ">" +
          (i >= 5 ? "CAREER STORY" : i < state.floor ? "REMATCH" : "FIGHT") +
          "</button></div>",
      )
      .join("");
    document.getElementById("towerChoices").innerHTML =
      '<p class="rival">BACKSTAGE POLITICS</p><button data-choice="respect">🤝 SHOW RESPECT</button><button data-choice="defy">🎤 CALL OUT BIRDMAN</button><button data-choice="rumour">📺 TRASHBAG POLICE</button><p><small>Win each unlocked floor to progress. Backstage decisions affect heat and respect. Save data stays on this browser.</small></p>';
  }
  panel.addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    if (b.dataset.floor !== undefined) {
      let i = Number(b.dataset.floor);
      if (
        !Number.isInteger(i) ||
        i < 0 ||
        i > 6 ||
        i > (APW_CAREER.qualified ? Math.min(6, Math.max(1, state.floor)) : 0)
      )
        return;
      if (i >= 5) {
        window.APW_PATH?.continue();
        return;
      }
      window.APW_OPPONENT = roster[i];
      document.getElementById("restart").click();
      scene(
        "NEXT MATCH: " + roster[i],
        i === 0
          ? "The Gatekeeper guards entry to the Tower."
          : "Your next challenger is " + roster[i] + ". APW IS NO TEA PARTY!",
      );
      document
        .querySelector(".arena")
        .scrollIntoView({ behavior: "smooth", block: "center" });
    } else if (b.dataset.choice) {
      let c = b.dataset.choice;
      if (c === "respect") {
        state.respect = Math.min(100, state.respect + 10);
        scene(
          "LOCKER ROOM",
          "Trucker Mark Taylor nods. Respect is earned, not given.",
        );
      }
      if (c === "defy") {
        state.heat = Math.min(100, state.heat + 15);
        scene(
          "BIRDMAN PROMO",
          "Tea Party Nintendo Wrestlers doing too many flips! APW IS NO TEA PARTY!",
        );
      }
      if (c === "rumour") {
        state.heat = Math.min(100, state.heat + 5);
        scene(
          "TRASHBAG POLICE",
          "Birdman uploads another ridiculous backstage hit piece.",
        );
      }
      save();
      render();
    }
  });
  window.APW_TOWER = {
    state: () => ({ ...state }),
    // Title possession is independent of the completed Tower floors. A defence loss
    // must not erase earned progress, but the Tower must stop displaying CHAMPION.
    setChampion(holding) {
      const next = holding === true;
      if (state.champion === next) return;
      state.champion = next;
      save();
      render();
    },
    title() {
      if (!state.champion) window.apwTowerVictory("Bruza The Serb", false);
    },
    refresh: render,
  };
  window.apwTowerVictory = function (name, countWin = true) {
    const i = roster.indexOf(name);
    if (i < 1) return;
    if (countWin) {
      window.APW_CAREER.wins++;
      window.apwSave();
      window.apwPaint();
    }
    if (
      i === state.floor ||
      (i === 1 && state.floor === 0 && window.APW_CAREER?.qualified)
    ) {
      state.floor = Math.min(7, i + 1);
      if (i === 6) state.champion = true;
      state.heat = Math.min(100, state.heat + 8);
      save();
    }
    const careerAtBell = window.APW_CAREER;
    setTimeout(() => {
      if (window.APW_CAREER !== careerAtBell) return;
      render();
      scene(
        i === 6 ? "NEW APW HEAVYWEIGHT CHAMPION!" : "TOWER FLOOR CLEARED",
        name +
          " has been defeated! " +
          (i === 6 ? "You conquered APW!" : "Your next challenge awaits."),
      );
    }, 1400);
  };

  const originalChoose = window.apwChoose;
  window.apwChoose = function (name) {
    state = { floor: 0, heat: 0, respect: 0, champion: false };
    window.APW_OPPONENT = "The Gatekeeper";
    originalChoose(name);
    save();
    render();
  };
  window.addEventListener("load", render);
  render();
})();
