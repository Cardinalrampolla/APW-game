/* Arcade finisher art */
(() => {
  "use strict";
  const stage = document.getElementById("apw49stage"),
    ring = document.getElementById("apw49ring"),
    selector = document.getElementById("apw49select");
  if (!stage || !ring) return;
  const plates = {
      idle: APW_MEDIA[247],
      approach: APW_MEDIA[247],
      grapple: APW_MEDIA[248],
      lift: APW_MEDIA[249],
      flight: APW_MEDIA[250],
      spin: APW_MEDIA[251],
      impact: APW_MEDIA[252],
      victory: APW_MEDIA[253],
    },
    portraits = {
      "Gideon Hark": APW_MEDIA[254],
      "Simon Temple": APW_MEDIA[255],
      "Whiskey Sixx": APW_MEDIA[256],
      "Mauler Y": APW_MEDIA[257],
      "The Gatekeeper": APW_MEDIA[258],
      "Birdman Phil Picasso": APW_MEDIA[259],
      "Bruza The Serb": APW_MEDIA[260],
      "Nikki Poteet": APW_MEDIA[261],
      "Evangeline Strange": APW_MEDIA[262],
      Doomslayer: APW_MEDIA[263],
      "Trucker Mark Taylor": APW_MEDIA[264],
      "Taras Jones": APW_MEDIA[265],
      "Harvey Falco": APW_MEDIA[266],
      "Al Straya": APW_MEDIA[267],
      TNT: APW_MEDIA[268],
      "Drako Savage": APW_MEDIA[269],
      "Johnny Putrid": APW_MEDIA[270],
      "Nightmare Cat": APW_MEDIA[271],
      "Trashbag Dan": APW_MEDIA[272],
      "Eli Driftwood": APW_MEDIA[273],
      "The Outlaw": APW_MEDIA[274],
      "Black Diamond": APW_MEDIA[275],
      "Jay Payne": APW_MEDIA[276],
    };
  const newArt = document.createElement("img");
  newArt.id = "apw101cinema";
  newArt.alt = "Detailed illustrated arcade wrestling finisher";
  newArt.decoding = "sync";
  newArt.loading = "eager";
  newArt.draggable = false;
  ring.appendChild(newArt);
  const text = document.createElement("div");
  text.id = "apw101caption";
  ring.appendChild(text);
  let current = "";
  let previousBeat = "";
  function refresh() {
    if (!stage.classList.contains("open")) return;
    const name =
      document.getElementById("apw49name")?.textContent?.toLowerCase().trim() ||
      "";
    const chosen =
      [...selector.options].find((x) => x.text.toLowerCase() === name)?.value ||
      selector.value;
    const beat = stage.dataset.beat || "idle";
    if (chosen === current && previousBeat === beat) return;
    current = chosen;
    previousBeat = beat;
    const simon = chosen === "Simon Temple";
    newArt.src = simon
      ? plates[beat] || plates.grapple
      : portraits[chosen] || plates.idle;
    newArt.classList.toggle("apw101-portrait", !simon);
    newArt.classList.toggle("apw101-simon", simon);
    newArt.classList.remove("apw101-hit");
    void newArt.offsetWidth;
    if (["impact", "victory"].includes(beat))
      newArt.classList.add("apw101-hit");
    text.textContent =
      beat === "impact"
        ? "💥 IMPACT!"
        : beat === "lift"
          ? "★ LIFT!"
          : beat === "victory"
            ? simon
              ? ""
              : "🏆 " + chosen.toUpperCase() + " WINS!"
            : "";
  }
  new MutationObserver(refresh).observe(stage, {
    attributes: true,
    attributeFilter: ["class", "data-beat"],
  });
  selector.addEventListener("change", () => setTimeout(refresh, 0));
  ring.addEventListener("animationstart", refresh);
  document
    .getElementById("apw49play")
    ?.addEventListener("click", () => setTimeout(refresh, 0));
  refresh();
})();

/* ---- Module 63 ---- */

/* Story theatre */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const safeRead = (key) => {
    try {
      return JSON.parse(localStorage.getItem(key) || "null");
    } catch {
      return null;
    }
  };
  const player = () =>
    window.APW_CAREER?.name || $("careerWrestler")?.value || "the challenger";
  const scenes = {
    contract: {
      title: "CHAPTER 16 — THE CONTRACT",
      faces: ["📋", "👓"],
      names: ["THE CHALLENGER", "EVANGELINE STRANGE"],
      lines: [
        [
          "Evangeline Strange",
          "Sign it. The title match is yours, provided you survive the fine print.",
        ],
        [
          "Backstage producer",
          "Hilder is officiating? Last week he counted three while looking the other way. Dodgy bloke, that one.",
        ],
        [
          "The challenger",
          "A dodgy ref, a dodgy contract, and Bruza waiting in the ring. Sounds like APW.",
        ],
      ],
    },
    corner: {
      title: "CHAPTER 17 — NO ONE FIGHTS ALONE",
      faces: ["🤼", "🦅"],
      names: ["LOCKER ROOM", "BIRDMAN"],
      lines: [
        ["Doomslayer", "Nikki gets involved, we will be watching."],
        [
          "Taras Jones",
          "Birdman has made enemies everywhere. We can use that.",
        ],
        [
          "Birdman Phil Picasso",
          "This is NOT a tea party! You Nintendo wrestlers think you can flip your way to the top!",
        ],
      ],
    },
    entrance: {
      title: "CHAPTER 18 — THE MAIN EVENT",
      faces: ["🏆", "🇷🇸"],
      names: ["APW CHAMPIONSHIP", "BRUZA THE SERB"],
      lines: [
        [
          "Ring announcer",
          "Sydney! This contest is for the APW HEAVYWEIGHT CHAMPIONSHIP!",
        ],
        [
          "Nikki Poteet",
          "Bruza did not carry this title up the Tower just to hand it over.",
        ],
        ["Bruza The Serb", "Come and take it."],
        [
          "Commentary",
          "People still talk about how tough the Hark Foundation are. Gideon and Simon take punishment that would flatten most teams.",
        ],
      ],
    },
    titleWin: {
      title: "THE TOWER FALLS — A NEW CHAMPION",
      faces: ["🏆", "🦅"],
      names: ["NEW APW CHAMPION", "BIRDMAN PHIL PICASSO"],
      lines: [
        ["Ring announcer", "AND NEW! APW HEAVYWEIGHT CHAMPION — {PLAYER}!"],
        ["David Hilder", "One! Two! Three! ... What? Yes, I counted properly!"],
        [
          "Birdman Phil Picasso",
          "YOU NINTENDO WRESTLER! You think winning the APW belt makes you a real wrestler?",
        ],
        [
          "Birdman Phil Picasso",
          "You should go work for Kebab Bruh Mr Bangladesh over at KCW! That is where your tea-party flips belong!",
        ],
        [
          "Evangeline Strange",
          "Enjoy your moment. Championship politics never end.",
        ],
        ["Locker room", "The Tower has a new champion. APW IS NO TEA PARTY!"],
      ],
    },
    titleLoss: {
      title: "THE TOWER — THE PRICE OF DEFEAT",
      faces: ["🇷🇸", "👓"],
      names: ["BRUZA THE SERB", "EVANGELINE STRANGE"],
      lines: [
        [
          "Ring announcer",
          "Bruza The Serb RETAINS the APW Heavyweight Championship!",
        ],
        ["Nikki Poteet", "I told you nobody was taking that belt tonight."],
        [
          "Backstage wrestler",
          "Hilder missed that interference again. What a surprise.",
        ],
        [
          "Doomslayer",
          "The Tower is still there. Heal up, then climb it again.",
        ],
      ],
    },
    birdman: {
      title: "TRASHBAG POLICE — UNAUTHORIZED BROADCAST",
      faces: ["🦅", "📹"],
      names: ["BIRDMAN", "TRASHBAG POLICE"],
      lines: [
        [
          "Birdman Phil Picasso",
          "Tea Party Nintendo Wrestlers doing too many flips! You people are embarrassing Sydney wrestling!",
        ],
        [
          "Backstage wrestler",
          "Funny how Birdman has a camera ready whenever somebody gets jumped.",
        ],
        ["Birdman Phil Picasso", "APW IS NO TEA PARTY!"],
      ],
    },
    hark: {
      title: "BACKSTAGE — RESPECT IS EARNED",
      faces: ["🤼", "💪"],
      names: ["GIDEON HARK", "SIMON TEMPLE"],
      lines: [
        [
          "Locker room veteran",
          "Say what you want about the Hark Foundation, those two are tough as nails.",
        ],
        [
          "Commentary",
          "Gideon keeps coming forward, and Simon is like trying to move a truck.",
        ],
        ["Gideon Hark", "We do not need shortcuts. We just keep fighting."],
        [
          "Simon Temple",
          "And when the bell rings, you find out exactly how tough.",
        ],
      ],
    },
    referee: {
      title: "BACKSTAGE — THE REFEREE QUESTION",
      faces: ["🦓", "👓"],
      names: ["DAVID HILDER", "APW OFFICE"],
      lines: [
        [
          "Wrestler in the hallway",
          "David Hilder? He always seems to miss the important bit.",
        ],
        [
          "Another wrestler",
          "Funny how the three-count changes depending on who is watching.",
        ],
        [
          "Evangeline Strange",
          "The referee’s decision is final. I suggest you remember that.",
        ],
      ],
    },
    tag: {
      title: "TAG TEAM CHAMPIONSHIP — NO EASY WAY OUT",
      faces: ["🤼", "👹"],
      names: ["THE HARK FOUNDATION", "THE OUTER REALM"],
      lines: [
        [
          "Commentary",
          "The Hark Foundation have survived punishment most teams could not walk away from.",
        ],
        [
          "Whiskey Sixx",
          "Toughness means nothing when the Outer Realm drags you into the dark.",
        ],
        ["Mauler Y", "You are not leaving this ring standing."],
        ["Simon Temple", "Then come and try to put us down."],
      ],
    },
    gatekeeper: {
      title: "PROLOGUE — THE GATEKEEPER'S WARNING",
      faces: ["⚔", "☠"],
      names: ["THE CHALLENGER", "THE GATEKEEPER"],
      lines: [
        [
          "Ring announcer",
          "One chance to enter the APW Tower. No favours, no shortcuts.",
        ],
        ["The Gatekeeper", "Every dream dies at the first locked door."],
        ["The challenger", "Then stand aside. I came to fight my way through."],
        [
          "Backstage worker",
          "David Hilder is refereeing? Watch his count closely.",
        ],
      ],
    },
    nikki: {
      title: "BACKSTAGE — NIKKI'S WARNING",
      faces: ["🏆", "⚡"],
      names: ["BRUZA THE SERB", "NIKKI POTEET"],
      lines: [
        [
          "Nikki Poteet",
          "Bruza is the champion for a reason. Don't mistake his patience for weakness.",
        ],
        [
          "The challenger",
          "And don't mistake your interference for wrestling.",
        ],
        ["Bruza The Serb", "Let them talk. I'll settle it in the ring."],
        [
          "Locker room veteran",
          "The Hark Foundation would fight through that mess. Those blokes never stay down.",
        ],
      ],
    },
    cageNight: {
      title: "STEEL CAGE — NO WAY OUT",
      faces: ["⛓", "🦅"],
      names: ["THE CHALLENGER", "BIRDMAN"],
      lines: [
        [
          "Commentary",
          "They've locked the cage. Whatever happens tonight follows both wrestlers home.",
        ],
        [
          "Birdman Phil Picasso",
          "No cameras to hide behind now? Wrong. Trashbag Police sees EVERYTHING!",
        ],
        [
          "The challenger",
          "You wanted a public humiliation. Now you get a public fight.",
        ],
        [
          "Backstage wrestler",
          "Even Hilder can't miss a cage match. ...Can he?",
        ],
      ],
    },
    tagAfter: {
      title: "AFTER THE BELL — THE HARK FOUNDATION STANDS TALL",
      faces: ["🤼", "🏆"],
      names: ["GIDEON HARK", "SIMON TEMPLE"],
      lines: [
        [
          "Commentary",
          "The Hark Foundation win it the hard way. That's why they have everyone's respect.",
        ],
        ["Gideon Hark", "There is no such thing as an easy match in APW."],
        [
          "Simon Temple",
          "And there's nobody in this locker room we're afraid to fight.",
        ],
      ],
    },
    tagLoss: {
      title: "AFTER THE BELL — THE OUTER REALM CELEBRATES",
      faces: ["🥃", "👹"],
      names: ["WHISKEY SIXX", "MAULER Y"],
      lines: [
        [
          "Whiskey Sixx",
          "You called them indestructible. We just proved otherwise.",
        ],
        ["Mauler Y", "They are tough. That's what made beating them worth it."],
        [
          "Commentary",
          "The Hark Foundation will be back. You can count on that.",
        ],
      ],
    },
    authority: {
      title: "BEHIND THE CURTAIN — STRANGE BUSINESS",
      faces: ["👓", "📋"],
      names: ["EVANGELINE STRANGE", "APW OFFICE"],
      lines: [
        [
          "Evangeline Strange",
          "A champion who cannot be controlled is a problem.",
        ],
        ["Office assistant", "The footage and the match sheets do not agree."],
        ["Evangeline Strange", "Then make sure nobody sees both."],
      ],
    },
  };
  // Portraits reused from the approved in-game artwork. Referee gets a small original silhouette.
  const portraits = {
    "Birdman Phil Picasso": APW_MEDIA[217],
    "Gideon Hark": APW_MEDIA[218],
    "Evangeline Strange": APW_MEDIA[219],
    "Bruza The Serb": APW_MEDIA[220],
    "Simon Temple": APW_MEDIA[221],
    "Whiskey Sixx": APW_MEDIA[222],
    "Mauler Y": APW_MEDIA[307],
    "The Gatekeeper": APW_MEDIA[224],
    "Nikki Poteet": APW_MEDIA[261],
    Doomslayer: APW_MEDIA[263],
    "Taras Jones": APW_MEDIA[265],
  };
  const sceneCast = {
    contract: ["{PLAYER}", "Evangeline Strange"],
    corner: ["Doomslayer", "Birdman Phil Picasso"],
    entrance: ["{PLAYER}", "Bruza The Serb"],
    titleWin: ["{PLAYER}", "Birdman Phil Picasso"],
    titleLoss: ["Bruza The Serb", "Evangeline Strange"],
    birdman: ["Birdman Phil Picasso", "Gideon Hark"],
    hark: ["Gideon Hark", "Simon Temple"],
    referee: ["David Hilder", "Evangeline Strange"],
    tag: ["Gideon Hark", "Whiskey Sixx"],
    authority: ["Evangeline Strange", "Birdman Phil Picasso"],
    gatekeeper: ["{PLAYER}", "The Gatekeeper"],
    nikki: ["Bruza The Serb", "Nikki Poteet"],
    cageNight: ["{PLAYER}", "Birdman Phil Picasso"],
    tagAfter: ["Gideon Hark", "Simon Temple"],
    tagLoss: ["Whiskey Sixx", "Mauler Y"],
  };
  const refereePortrait = APW_MEDIA[317];
  const resolveActor = (id) => (id === "{PLAYER}" ? player() : id);
  const actorPicture = (name) =>
    name === "David Hilder"
      ? refereePortrait
      : portraits[name] ||
        window.APW_ROSTER_SPRITES?.[name]?.idle ||
        APW_MEDIA[218];
  const showActors = (id, speaker) => {
    const pair = sceneCast[id] || ["Gideon Hark", "Birdman Phil Picasso"];
    const names = pair.map(resolveActor);
    for (const [i, elName] of ["apw106left", "apw106right"].entries()) {
      const el = $(elName),
        nm = names[i];
      const src = actorPicture(nm);
      let img = el.querySelector("img");
      if (!img) {
        img = document.createElement("img");
        img.decoding = "async";
        img.draggable = false;
        el.replaceChildren(img);
      }
      if (img.dataset.character !== nm) {
        img.src = src;
        img.dataset.character = nm;
        img.alt = nm + " arcade character portrait";
      }
      let cap = el.querySelector("small");
      if (!cap) {
        cap = document.createElement("small");
        el.append(cap);
      }
      cap.textContent = nm.toUpperCase();
      el.classList.toggle(
        "speaking",
        !!speaker &&
          (speaker.toLowerCase().includes(nm.toLowerCase()) ||
            (speaker.toLowerCase().includes("challenger") && nm === player())),
      );
    }
  };
  let active = null,
    index = 0,
    shown = new Set(),
    previousFocus = null,
    previousOverflow = "";
  function setup() {
    if ($("apw106overlay")) return;
    const launch = document.createElement("button");
    launch.id = "apw106launch";
    launch.type = "button";
    launch.textContent = "🎬 STORY SCENES";
    launch.onclick = () => openMenu();
    document.body.append(launch);
    const overlay = document.createElement("div");
    overlay.id = "apw106overlay";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-label", "APW story cinematic");
    overlay.innerHTML =
      '<div id="apw106panel"><div id="apw106stage"><div class="actor" id="apw106left"></div><div class="actor" id="apw106right"></div></div><h2 id="apw106title"></h2><div id="apw106speaker"></div><div id="apw106line"></div><div id="apw106progress"></div><div id="apw106controls"><button id="apw106skip" type="button">Skip / Close</button><button id="apw106back" type="button">Previous</button><button id="apw106next" type="button">Next ▶</button></div></div>';
    document.body.append(overlay);
    $("apw106skip").onclick = close;
    $("apw106back").onclick = () => {
      if (active) {
        index = Math.max(0, index - 1);
        render();
      }
    };
    $("apw106next").onclick = () => {
      if (!active) return;
      if (index >= scenes[active].lines.length - 1) close();
      else {
        index++;
        render();
      }
    };
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) close();
    });
    document.addEventListener("keydown", (e) => {
      if (!$("apw106overlay")?.classList.contains("open")) return;
      if (e.key === "Escape") {
        e.preventDefault();
        close();
      }
      if (e.key === "ArrowRight") {
        e.preventDefault();
        $("apw106next").click();
      }
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        $("apw106back").click();
      }
      if (e.key === "Tab") {
        const buttons = [
          ...$("apw106overlay").querySelectorAll("button:not(:disabled)"),
        ];
        const first = buttons[0],
          last = buttons[buttons.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    });
  }
  function openOverlay() {
    const overlay = $("apw106overlay");
    if (!overlay.classList.contains("open")) {
      previousFocus = document.activeElement;
      previousOverflow = document.body.style.overflow;
    }
    document.body.style.overflow = "hidden";
    overlay.classList.add("open");
  }
  function close() {
    $("apw106overlay")?.classList.remove("open");
    document.body.style.overflow = previousOverflow;
    active = null;
    const target =
      previousFocus?.isConnected && !previousFocus.closest("[hidden],[inert]")
        ? previousFocus
        : document.querySelector("[data-apw-screen]:not([hidden]) h1");
    target?.focus({ preventScroll: true });
  }
  function play(id) {
    if (!scenes[id]) return;
    setup();
    active = id;
    index = 0;
    openOverlay();
    render();
    $("apw106next").focus();
  }
  function render() {
    const scene = scenes[active];
    if (!scene) return;
    const line = scene.lines[index];
    $("apw106title").textContent = scene.title;
    $("apw106speaker").textContent = line[0];
    $("apw106line").textContent = line[1].replaceAll("{PLAYER}", player());
    showActors(active, line[0]);
    $("apw106progress").textContent =
      `SCENE ${index + 1} / ${scene.lines.length}`;
    $("apw106back").disabled = index === 0;
    $("apw106next").disabled = false;
    $("apw106next").textContent =
      index === scene.lines.length - 1 ? "Finish ✓" : "Next ▶";
  }
  function openMenu() {
    setup();
    const keys = Object.keys(scenes);
    openOverlay();
    active = null;
    $("apw106title").textContent = "APW STORY THEATRE";
    $("apw106speaker").textContent =
      "Replay any scene — this does not change career progress";
    $("apw106line").replaceChildren();
    const wrap = document.createElement("div");
    wrap.className = "apw108-scene-grid";
    for (const k of keys) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = scenes[k].title;
      b.style.cssText = "font-size:11px;padding:8px";
      b.onclick = () => play(k);
      wrap.append(b);
    }
    $("apw106line").append(wrap);
    $("apw106progress").textContent =
      "Replay-only scenes are available even before reaching the relevant chapter.";
    showActors("birdman", "");
    $("apw106back").disabled = true;
    $("apw106next").disabled = true;
    wrap.querySelector("button")?.focus();
  }
  function trigger(id, token) {
    if (shown.has(token)) return;
    shown.add(token);
    play(id);
  }
  // Listen only to actual player interactions. Do not mutate career saves or create fake wins.
  document.addEventListener(
    "click",
    (event) => {
      const button = event.target.closest?.("button");
      if (!button) return;
      const label = button.textContent || "";
      const parent = button.parentElement?.id || "";
      if (parent === "apw33Buttons") {
        setTimeout(() => {
          const s = safeRead("apwMainEvent33");
          if (!s || (s._career && s._career !== window.APW_CAREER?.name))
            return;
          const key = `main:${s.phase}:${s.result || ""}:${s.turn || 0}`;
          if (s.phase === 4 && s.result === "win")
            trigger("titleWin", `win:${player()}:${s.turn}:${s.hp}:${s.bruza}`);
          else if (s.phase === 4 && s.result === "loss")
            trigger("titleLoss", `loss:${player()}:${s.turn}:${s.hp}`);
          else if (s.phase === 3 && /START TITLE MATCH/i.test(label))
            trigger("entrance", key);
          else if (s.phase === 2 && /allies|corner|alone/i.test(label))
            trigger("corner", key);
          else if (s.phase === 1 && /contract|fair match/i.test(label))
            trigger("contract", key);
        }, 0);
      } else if (button.id === "tagstart") {
        setTimeout(() => trigger("tag", `tag:${player()}`), 0);
      }
    },
    true,
  );
  let pendingQualifier = null;
  function playPendingQualifier() {
    if (
      !pendingQualifier ||
      $("apwModal")?.classList.contains("show") ||
      active
    )
      return;
    const name = pendingQualifier;
    const task = window.APW_PATH?.objective?.();
    pendingQualifier = null;
    if (
      name === player() &&
      window.APW_JOURNEY?.current?.() === "match" &&
      task?.[1] === ".arena" &&
      Number(task[2]) === 0
    )
      trigger("gatekeeper", `gatekeeper:${name}`);
  }
  window.addEventListener("apw:career-start", () => {
    const task = window.APW_PATH?.objective?.();
    if (task?.[1] !== ".arena" || Number(task[2]) !== 0) return;
    pendingQualifier = player();
    setTimeout(playPendingQualifier, 0);
  });
  window.addEventListener("apw:career-changed", () => {
    pendingQualifier = null;
  });
  const intro = $("apwModal");
  if (intro)
    new MutationObserver(playPendingQualifier).observe(intro, {
      attributes: true,
      attributeFilter: ["class"],
    });
  let tagMatchNumber = 0;
  $("tagstart")?.addEventListener(
    "click",
    () => {
      tagMatchNumber++;
    },
    { capture: true },
  );
  $("tagrestart")?.addEventListener(
    "click",
    () => {
      tagMatchNumber++;
    },
    { capture: true },
  );
  const tagStatus = $("tagturn");
  if (tagStatus)
    new MutationObserver(() => {
      if (tagStatus.textContent !== "MATCH OVER") return;
      const outcome = $("taglog")?.textContent || "";
      const victory = /HARK FOUNDATION WINS/i.test(outcome);
      if (!victory && !/OUTER REALM WINS|disqualification/i.test(outcome))
        return;
      const type = victory ? "tagAfter" : "tagLoss";
      trigger(type, `tagresult:${tagMatchNumber}:${type}`);
    }).observe(tagStatus, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  // Career theatre scenes are optional and never alter progression.
  window.APW_STORY_106 = { play, scenes: Object.keys(scenes), version: "10.6" };
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", setup, { once: true });
  else setup();
})();
