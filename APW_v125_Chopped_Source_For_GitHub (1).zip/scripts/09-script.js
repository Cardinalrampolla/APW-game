/* Result and finisher banners */
(() => {
  "use strict";
  const finishers = {
    "Gideon Hark": "RIPCORD CLOTHESLINE",
    "Simon Temple": "CHOKE SLAM",
    "Birdman Phil Picasso": "DOUBLE UNDERHOOK DDT",
    "Bruza The Serb": "RUSSIAN LEG SWEEP",
    "Nikki Poteet": "RUNNING CANNONBALL",
    "Johnny Putrid": "THE STROKE",
    "Nightmare Cat": "THE CAT SPLASH",
    TNT: "THE UNPRETTIER",
    "Whiskey Sixx": "450 SPLASH",
    "Mauler Y": "RUNNING SPLASH",
    "Al Straya": "44 GALLON DRUM",
    "Trucker Mark Taylor": "THE FINAL CUT",
    "Taras Jones": "REAR NAKED CHOKE",
    "Harvey Falco": "FALCON PUNCH",
    Doomslayer: "MAP OF TASSIE",
    "Drako Savage": "FINGER POKE OF DOOM",
    "Trashbag Dan": "THE OIL CHECK",
    "Eli Driftwood": "FIVE STAR FROG SPLASH",
    "Evangeline Strange": "RUNNING NECKBREAKER",
  };
  const box = document.createElement("div");
  box.id = "apw17-cinema";
  box.setAttribute("aria-live", "polite");
  box.innerHTML =
    '<div class="panel17"><div class="eyebrow"></div><div class="starburst">✦ ★ ✦</div><div class="headline"></div><div class="subline"></div></div>';
  document.body.appendChild(box);
  let timer,
    finishing = false;
  function display(kind, eyebrow, headline, subline, duration) {
    clearTimeout(timer);
    box.className = "show " + kind;
    box.querySelector(".eyebrow").textContent = eyebrow;
    box.querySelector(".headline").textContent = headline;
    box.querySelector(".subline").textContent = subline;
    timer = setTimeout(() => (box.className = ""), duration);
  }
  function hero() {
    return (
      window.APW_CAREER?.name ||
      document.getElementById("careerWrestler")?.value ||
      "Gideon Hark"
    );
  }
  function finisher() {
    const name = hero(),
      move =
        finishers[name] || window.APW_SPECIALS?.[name] || "SIGNATURE FINISHER";
    display(
      "finish",
      "★ " + name.toUpperCase() + " ★",
      move,
      name === "Simon Temple"
        ? "THE RING SHAKES!"
        : name === "Whiskey Sixx"
          ? "FROM THE TOP ROPE!"
          : "DEVASTATING IMPACT!",
      1450,
    );
  }
  const fighter = document.getElementById("gideon");
  if (fighter) {
    new MutationObserver(() => {
      const active = fighter.classList.contains("finishing");
      if (active && !finishing) finisher();
      finishing = active;
    }).observe(fighter, { attributes: true, attributeFilter: ["class"] });
  }
  document.getElementById("restart")?.addEventListener("click", () => {
    clearTimeout(timer);
    box.className = "";
    finishing = false;
  });
  const oldEnd = window.apwMatchEnd;
  window.apwMatchEnd = function (result) {
    if (result) {
      if (result.includes("WINS!"))
        display(
          "win",
          "🏆 MATCH VICTORY 🏆",
          hero().toUpperCase() + " WINS!",
          "1 • 2 • 3 — APW IS NO TEA PARTY!",
          2700,
        );
      else
        display(
          "lose",
          "🔔 MATCH OVER",
          "DEFEAT",
          "THE ROAD TO GLORY CONTINUES",
          2200,
        );
    }
    if (typeof oldEnd === "function") return oldEnd.apply(this, arguments);
  };
})();
