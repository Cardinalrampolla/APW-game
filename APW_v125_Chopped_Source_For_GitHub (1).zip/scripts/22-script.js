/* Career endings and checks */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const tasks = [
    "Career selection and The Gatekeeper match",
    "Training, stats and APW Tower advancement",
    "Backstage decisions and alliances",
    "Tag team match and tag switching",
    "Steel Cage pinfall and escape",
    "Bruza championship match and interference",
    "Championship defence and storyline branches",
    "Submission, reversal, referee and DQ",
    "Save, close, reopen and resume",
    "Android portrait and landscape controls",
  ];
  const checkKey = "apw42_release_checks";
  const endingsKey = "apw42_career_endings";
  function read(k) {
    try {
      return JSON.parse(localStorage.getItem(k) || "null");
    } catch (e) {
      return null;
    }
  }
  function player() {
    return (
      $("careerWrestler")?.value || window.APW_CAREER?.name || "Gideon Hark"
    );
  }
  function scan() {
    const found = [];
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!/^apw/i.test(k) || k.startsWith("apw42") || k.startsWith("apw71_"))
          continue;
        const data = read(k);
        if (data && typeof data === "object") found.push({ key: k, data });
      }
    } catch (e) {}
    return found;
  }
  function championEvidence(name) {
    return scan()
      .filter(
        ({ data }) =>
          (!data.name || data.name === name) &&
          (!data._career || data._career === name),
      )
      .filter(
        ({ key, data }) =>
          key !== "apwChampion34" ||
          (read("apwMainEvent33")?.phase === 4 &&
            read("apwMainEvent33")?.result === "win"),
      )
      .some(
        ({ data }) =>
          data.champion === true ||
          data.heavyweightChampion === true ||
          data.titleWon === true ||
          data.isChampion === true ||
          data.wonTitle === true,
      );
  }
  function renderEnding() {
    const name = player();
    $("apw42identity").textContent = "Selected wrestler: " + name;

    const champ = championEvidence(name);
    const end = $("apw42ending");
    if (!champ) {
      end.textContent =
        "CHAMPIONSHIP FINALE LOCKED\n\nWin the APW Heavyweight Championship in Career Mode to unlock the champion epilogue.\n\nIf you have won but this panel remains locked, the older match module may use a different save flag. This panel will not overwrite or invent your result.";
      return;
    }
    const endings = read(endingsKey) || {};
    if (!endings[name]) {
      end.textContent =
        "THE FINAL BELL\n\nThe crowd rises as " +
        name +
        " lifts the APW Heavyweight Championship. Birdman Phil Picasso storms away, his latest Trashbag Police scheme ruined. Evangeline Strange watches from the entrance, furious that the Tower has produced a champion she cannot control.\n\nDavid Hilder raises the winner’s hand. The locker room has one message: APW IS NO TEA PARTY!\n\nCAREER COMPLETE — CHAMPION ENDING";
      endings[name] = true;
      try {
        localStorage.setItem(endingsKey, JSON.stringify(endings));
      } catch (e) {}
    } else
      end.textContent =
        "CAREER COMPLETE — CHAMPION ENDING\n\n" +
        name +
        " overcame the APW Tower, backstage politics and the Heavyweight Championship challenge.\n\nAPW IS NO TEA PARTY!";
  }
  function checked() {
    const a = read(checkKey);
    return Array.isArray(a) ? a : [];
  }
  function renderChecks() {
    const values = checked();
    const host = $("apw42checks");
    host.replaceChildren();
    tasks.forEach((t, i) => {
      const label = document.createElement("label");
      const c = document.createElement("input");
      c.type = "checkbox";
      c.checked = values.includes(i);
      c.addEventListener("change", () => {
        const next = checked().filter((v) => v !== i);
        if (c.checked) next.push(i);
        try {
          localStorage.setItem(checkKey, JSON.stringify(next));
        } catch (e) {}
        renderChecks();
      });
      label.append(c, document.createTextNode(t));
      host.append(label);
    });
    $("apw42bar").style.width = (values.length / tasks.length) * 100 + "%";
    $("apw42count").textContent =
      values.length + " / " + tasks.length + " manually verified";
  }
  $("apw42refresh").addEventListener("click", renderEnding);
  $("careerWrestler")?.addEventListener("change", renderEnding);
  $("apw42reset").addEventListener("click", () => {
    if (confirm("Clear the v4.2 manual test checklist?")) {
      localStorage.removeItem(checkKey);
      renderChecks();
    }
  });
  $("apw42export").addEventListener("click", () => {
    const payload = {
      game: "APW No Tea Party",
      version: "4.2",
      wrestler: player(),
      championEvidence: championEvidence(player()),
      checks: tasks.map((task, i) => ({
        task,
        verified: checked().includes(i),
      })),
      savedModules: scan().map(({ key }) => key),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "APW_v42_test_report.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  });
  renderEnding();
  renderChecks();
})();
