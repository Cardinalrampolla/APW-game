/* Move effects */
(() => {
  "use strict";
  const finishers = {
    "Gideon Hark": ["RIPCORD CLOTHESLINE", "clothesline"],
    "Simon Temple": ["CHOKE SLAM", "chokeslam"],
    "Birdman Phil Picasso": ["DOUBLE UNDERHOOK DDT", "ddt"],
    "Bruza The Serb": ["RUSSIAN LEG SWEEP", "leg-sweep"],
    "Nikki Poteet": ["RUNNING CANNONBALL", "running-splash"],
    "Johnny Putrid": ["THE STROKE", "stroke"],
    "Nightmare Cat": ["THE CAT SPLASH", "splash"],
    TNT: ["THE UNPRETTIER", "ddt"],
    "Whiskey Sixx": ["450 SPLASH", "450-splash"],
    "Mauler Y": ["RUNNING SPLASH", "running-splash"],
    "Al Straya": ["44 GALLON DRUM", "clothesline"],
    "Trucker Mark Taylor": ["THE FINAL CUT", "ddt"],
    "Taras Jones": ["REAR NAKED CHOKE", "chokeslam"],
    "Harvey Falco": ["FALCON PUNCH", "clothesline"],
    Doomslayer: ["MAP OF TASSIE", "splash"],
    "Drako Savage": ["FINGER POKE OF DOOM", "clothesline"],
    "Trashbag Dan": ["THE OIL CHECK", "oil-check"],
    "Eli Driftwood": ["FIVE STAR FROG SPLASH", "frog-splash"],
    "Evangeline Strange": ["RUNNING NECKBREAKER", "neckbreaker"],
    "The Gatekeeper": ["GHOSTLY HANDS SLAM", "chokeslam"],
  };
  const selected = () =>
    document.getElementById("careerWrestler")?.value || "Gideon Hark";
  const stages = [...document.querySelectorAll(".apw36-overlay")];
  const names = [
    "ORIGINAL SINGLES",
    "CONSPIRACY ELIMINATOR",
    "STEEL CAGE",
    "HEAVYWEIGHT MAIN EVENT",
    "CHAMPIONSHIP DEFENCE",
  ];
  let busy = new WeakSet();
  function play(layer, name) {
    if (!layer || busy.has(layer)) return;
    busy.add(layer);
    const [title, move] = finishers[name] || ["SIGNATURE FINISHER", "ddt"];
    let banner = layer.querySelector(".apw37-banner");
    if (!banner) {
      banner = document.createElement("div");
      banner.className = "apw37-banner";
      layer.appendChild(banner);
    }
    banner.textContent = name.toUpperCase() + " • " + title;
    layer.dataset.move = move;
    layer.classList.remove("apw37-active");
    void layer.offsetWidth;
    layer.classList.add("apw37-active");
    banner.classList.remove("show");
    void banner.offsetWidth;
    banner.classList.add("show");
    const spark = layer.querySelector(".apw36-spark");
    if (spark) spark.textContent = "K.O.!";
    setTimeout(() => {
      layer.classList.remove("apw37-active");
      banner.classList.remove("show");
      delete layer.dataset.move;
      busy.delete(layer);
    }, 1800);
  }
  // Capture action buttons without intercepting the existing turn-based mechanics.
  document.addEventListener(
    "click",
    (e) => {
      const button = e.target.closest("button");
      if (!button) return;
      const label = (button.textContent || "").toLowerCase();
      if (
        !/finisher|signature|special|choke slam|splash|ddt|ripcord|stroke|cannonball|neckbreaker/.test(
          label,
        )
      )
        return;
      if (button.disabled) return;
      const target = button.closest("#apw30,#apw32,#apw33,#apw34,#apw35");
      let index =
        target?.id === "apw30"
          ? 1
          : target?.id === "apw32"
            ? 2
            : target?.id === "apw33"
              ? 3
              : target?.id === "apw34" || target?.id === "apw35"
                ? 4
                : 0;
      const layer = stages[index] || stages[0];
      play(layer, selected());
    },
    true,
  );
  // Expose a non-combat test preview in the UI, available in every match mode.
  const panel = document.createElement("section");
  panel.id = "apw37-preview";
  panel.style.cssText =
    "margin:12px 0;padding:10px;border:2px solid #e3b955;background:#141b36;border-radius:6px";
  panel.innerHTML =
    '<strong style="color:#ffe17a">★ v3.7 SIGNATURE FINISHERS</strong><p style="font-size:12px;margin:5px 0">Preview your selected wrestler’s signature choreography. This does not spend stamina or alter match results.</p><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><select id="apw37-mode" aria-label="Preview arena" style="min-width:150px;padding:9px;background:#10162d;color:white;border:1px solid #e3b955"></select><button type="button" id="apw37-test">▶ PREVIEW FINISHER</button></div>';
  const selector = panel.querySelector("select");
  names.forEach((n, i) => {
    if (stages[i]) selector.add(new Option(n, String(i)));
  });
  panel.querySelector("button").addEventListener("click", () => {
    const layer = stages[Number(selector.value)];
    if (!layer) return;
    const stage = layer.parentElement;
    const hidden = stage.closest("[hidden]");
    if (hidden) {
      alert("Open this match mode first to see its finisher.");
      return;
    }
    play(layer, selected());
    stage.scrollIntoView({ behavior: "smooth", block: "center" });
  });
  const main = document.querySelector("main");
  if (main) main.appendChild(panel);
})();
