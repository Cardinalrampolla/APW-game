/* Save help */
(function () {
  "use strict";
  function install() {
    const page = document.getElementById("apw71Saves");
    if (!page || document.getElementById("apw88help")) return;
    const box = document.createElement("div");
    box.id = "apw88help";
    const heading = document.createElement("strong");
    heading.textContent = "v8.8 · SAVE COMPATIBILITY CHECK";
    const intro = document.createElement("p");
    intro.textContent =
      "Game updates keep the existing save-key names and backup format. Browser storage can be isolated between downloaded HTML filenames, browsers and devices. Export a JSON backup from your old version, then import it here before starting a new career.";
    const status = document.createElement("p");
    status.id = "apw88status";
    const check = document.createElement("button");
    check.textContent = "CHECK THIS BROWSER SAVE";
    check.onclick = function () {
      try {
        const keys = window.APW_SAVE_KEYS || [];
        const found = keys.filter((k) => localStorage.getItem(k) !== null);
        let name = "No career record";
        const raw = localStorage.getItem("apwCareer08");
        if (raw) {
          const v = JSON.parse(raw);
          name = typeof v.name === "string" ? v.name : "Invalid career record";
        }
        status.textContent =
          "Storage accessible · " +
          found.length +
          " of " +
          keys.length +
          " save records present · " +
          name +
          ". This checks availability, not full backup integrity.";
      } catch (e) {
        status.textContent =
          "Storage unavailable or damaged: " +
          e.message +
          ". Use a downloaded JSON backup.";
      }
    };
    const exportBtn = document.createElement("button");
    exportBtn.textContent = "DOWNLOAD PORTABLE BACKUP";
    exportBtn.onclick = function () {
      document.getElementById("apw71Export")?.click();
    };
    box.append(heading, intro, status, check, exportBtn);
    page.insertBefore(box, page.children[1]);
    if (window.APW_SAVE_RECOVERED)
      status.textContent =
        "Interrupted import was rolled back on startup. Check your progress before continuing.";
    if (window.APW_SAVE_RECOVERY_FAILED)
      status.textContent =
        "Warning: interrupted import could not be recovered. Do not overwrite your backup.";
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", install);
  else install();
})();
