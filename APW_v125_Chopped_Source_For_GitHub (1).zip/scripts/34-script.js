/* Save check lab */
(function () {
  "use strict";
  const legacy = [
    "apwCareer08",
    "apwCareer09",
    "apwTower12",
    "apwChapter13",
    "apwStory27",
    "apwShowdown28",
    "apwConspiracy30",
    "apwCage32",
    "apwMainEvent33",
    "apwChampion34",
    "apw42_career_endings",
    "apw42_release_checks",
    "apw43_options",
    "apw_selected_venue",
    "apw43_slot_1",
    "apw43_slot_2",
    "apw43_slot_3",
  ];
  function keys() {
    return Array.isArray(window.APW_SAVE_KEYS) ? window.APW_SAVE_KEYS : [];
  }
  function snapshot(storage) {
    let out = {};
    for (const k of legacy) out[k] = storage.getItem(k);
    return out;
  }
  function restore(storage, values) {
    for (const k of legacy) {
      if (values[k] === null || values[k] === undefined) storage.removeItem(k);
      else storage.setItem(k, values[k]);
    }
  }
  function fakeStorage(initial) {
    const map = new Map(Object.entries(initial || {}));
    return {
      getItem: (k) => (map.has(k) ? map.get(k) : null),
      setItem: (k, v) => map.set(k, String(v)),
      removeItem: (k) => map.delete(k),
      keys: () => [...map.keys()],
    };
  }
  function run() {
    const rows = [];
    const test = (name, fn) => {
      try {
        if (fn() !== true) throw Error("Assertion failed");
        rows.push(["PASS", name]);
      } catch (e) {
        rows.push(["FAIL", name + ": " + e.message]);
      }
    };
    test("All 17 legacy career/save-slot keys remain registered", () =>
      legacy.every((k) => keys().includes(k)));
    test("Legacy career JSON survives snapshot/restore", () => {
      const db = fakeStorage({
        apwCareer08: JSON.stringify({
          name: "Gideon Hark",
          wins: 17,
          exp: 120,
        }),
        apwTower12: '{"rank":4}',
      });
      const before = snapshot(db);
      db.setItem("apwCareer08", "corrupted");
      restore(db, before);
      return (
        db.getItem("apwCareer08") === before.apwCareer08 &&
        db.getItem("apwTower12") === before.apwTower12
      );
    });
    test("Missing records remain missing after restoration", () => {
      const db = fakeStorage({ apwCareer09: "{}" });
      const snap = snapshot(db);
      db.setItem("apw43_slot_1", "temporary");
      restore(db, snap);
      return db.getItem("apw43_slot_1") === null;
    });
    test("Three independent slots preserved byte-for-byte", () => {
      const db = fakeStorage({
        apw43_slot_1: '{"a":1}',
        apw43_slot_2: '{"b":2}',
        apw43_slot_3: '{"c":3}',
      });
      const snap = snapshot(db);
      restore(db, snap);
      return [1, 2, 3].every(
        (n) => db.getItem("apw43_slot_" + n) === snap["apw43_slot_" + n],
      );
    });
    test("Unicode wrestler names and story choices survive", () => {
      const v = JSON.stringify({
        name: "Nikki Poteet",
        story: "🔥 No Tea Party!",
        choices: ["ally", "betray"],
      });
      const db = fakeStorage({ apwStory27: v });
      restore(db, snapshot(db));
      return db.getItem("apwStory27") === v;
    });
    test("Unknown future keys are not deleted by legacy restore", () => {
      const db = fakeStorage({ future_apw_key: "keep" });
      restore(db, snapshot(db));
      return db.getItem("future_apw_key") === "keep";
    });
    test("Corrupted JSON can be detected without rewriting it", () => {
      const db = fakeStorage({ apwCareer08: "{broken" });
      let invalid = false;
      try {
        JSON.parse(db.getItem("apwCareer08"));
      } catch (e) {
        invalid = true;
      }
      return invalid && db.getItem("apwCareer08") === "{broken";
    });
    test("Recovery journal key remains distinct from career keys", () =>
      !keys().includes("apw71_journal"));
    test("Current browser save records can be read (read-only)", () => {
      for (const k of legacy) localStorage.getItem(k);
      return true;
    });
    let n = rows.filter((r) => r[0] === "PASS").length;
    return {
      rows,
      summary: n + "/" + rows.length + " checks passed",
      failed: rows.length - n,
    };
  }
  window.APW_SAVE_REGRESSION = { run, legacyKeys: legacy.slice() };
  function install() {
    const page = document.getElementById("apw71Saves");
    if (!page || document.getElementById("apw89box")) return;
    const panel = document.createElement("div");
    panel.id = "apw89box";
    const h = document.createElement("h3");
    h.textContent = "v8.9 · SAVE COMPATIBILITY TEST LAB";
    const p = document.createElement("p");
    p.textContent =
      "Run non-destructive regression checks against simulated older career saves and current browser storage. Tests never overwrite your career. This does not prove that a real imported backup will load correctly.";
    const btn = document.createElement("button");
    btn.textContent = "RUN 9 SAVE CHECKS";
    const output = document.createElement("pre");
    output.id = "apw89results";
    output.textContent =
      "Ready to test. Export a portable backup before upgrading.";
    btn.onclick = () => {
      const result = run();
      output.textContent =
        result.summary +
        "\n" +
        result.rows
          .map((r) => (r[0] === "PASS" ? "✓ " : "✗ ") + r[1])
          .join("\n");
    };
    panel.append(h, p, btn, output);
    page.append(panel);
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", install);
  else install();
})();

/* ---- Module 61 ---- */

/* Arcade art gallery */
(function () {
  "use strict";
  const assets = [
    {
      title: "Hark Foundation",
      desc: "Gideon Hark and Simon Temple",
      src: APW_MEDIA[242],
      size: 432164,
    },
    {
      title: "Outer Realm",
      desc: "Whiskey Sixx and Mauler Y",
      src: APW_MEDIA[243],
      size: 478440,
    },
    {
      title: "Tag Championship",
      desc: "Four-wrestler tag team showcase",
      src: APW_MEDIA[244],
      size: 514166,
    },
    {
      title: "Core Story Roster",
      desc: "Gatekeeper, Birdman, Bruza, Nikki, Evangeline and Doomslayer",
      src: APW_MEDIA[245],
      size: 528360,
    },
    {
      title: "Expanded Roster",
      desc: "Additional APW wrestlers and signature moves",
      src: APW_MEDIA[246],
      size: 591218,
    },
  ];
  function setup() {
    if (document.getElementById("apw100-launch")) return;
    const launch = document.createElement("button");
    launch.id = "apw100-launch";
    launch.textContent = "★ APW ART GALLERY";
    launch.type = "button";
    launch.setAttribute("aria-haspopup", "dialog");
    const overlay = document.createElement("section");
    overlay.id = "apw100-gallery";
    overlay.hidden = true;
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-label", "APW arcade artwork gallery");
    overlay.innerHTML =
      '<div class="wrap"><div class="bar"><div><h2>APW · ARCADE ART GALLERY</h2><p>Five approved character-art showcases · artwork previews, not extracted gameplay animation frames</p></div><button type="button" id="apw100-close">✕ CLOSE</button></div><div class="tabs" role="tablist" aria-label="Art collections"></div><div class="art"><img alt="" loading="eager"></div><div class="bar"><p id="apw100-caption"></p><button id="apw100-zoom" type="button" aria-pressed="false">ZOOM PIXEL ART</button></div><div class="notes">These are character concept and reference sheets. Their illustrated pose panels are not yet independent, transparent, gameplay-ready sprite frames. The existing game engine and save keys are unchanged.</div></div>';
    document.body.append(launch, overlay);
    const tabs = overlay.querySelector(".tabs"),
      art = overlay.querySelector(".art"),
      img = overlay.querySelector("img"),
      caption = overlay.querySelector("#apw100-caption"),
      zoom = overlay.querySelector("#apw100-zoom");
    let previousOverflow = "";
    let selected = 0,
      previousFocus = null;
    function show(n) {
      selected = n;
      img.src = assets[n].src;
      img.alt = assets[n].title + ": " + assets[n].desc;
      caption.textContent = assets[n].title + " — " + assets[n].desc;
      [...tabs.children].forEach((b, i) => {
        b.setAttribute("aria-selected", String(i === n));
        b.tabIndex = i === n ? 0 : -1;
      });
      art.classList.remove("zoom");
      zoom.setAttribute("aria-pressed", "false");
      zoom.textContent = "ZOOM PIXEL ART";
    }
    assets.forEach((a, i) => {
      const b = document.createElement("button");
      b.textContent = a.title;
      b.type = "button";
      b.setAttribute("role", "tab");
      b.onclick = () => show(i);
      tabs.append(b);
    });
    function close() {
      overlay.hidden = true;
      document.body.style.overflow = previousOverflow;
      (previousFocus || launch).focus();
    }
    launch.onclick = () => {
      previousFocus = document.activeElement;
      previousOverflow = document.body.style.overflow;
      overlay.hidden = false;
      document.body.style.overflow = "hidden";
      show(selected);
      overlay.querySelector("#apw100-close").focus();
    };
    overlay.querySelector("#apw100-close").onclick = close;
    zoom.onclick = () => {
      const on = art.classList.toggle("zoom");
      zoom.setAttribute("aria-pressed", String(on));
      zoom.textContent = on ? "FIT TO SCREEN" : "ZOOM PIXEL ART";
    };
    overlay.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        close();
      } else if (e.key === "Tab") {
        const f = [...overlay.querySelectorAll("button")].filter(
          (b) => b.offsetParent !== null,
        );
        if (!f.length) return;
        const at = f.indexOf(document.activeElement);
        if (e.shiftKey && at === 0) {
          e.preventDefault();
          f[f.length - 1].focus();
        } else if (!e.shiftKey && at === f.length - 1) {
          e.preventDefault();
          f[0].focus();
        }
      }
    });
    show(0);
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", setup);
  else setup();
})();
