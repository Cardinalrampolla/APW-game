/* Championship eliminator */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id),
    KEY = "apwConspiracy30";
  const fresh = () => ({
    stage: 0,
    evidence: 0,
    trust: 0,
    heat: 0,
    hp: 100,
    boss: 125,
    momentum: 0,
    guard: false,
    turn: 0,
    outcome: "",
    log: "",
    choice: "",
  });
  let state;
  try {
    state = window.APW_TEAM_B.restore(
      fresh(),
      JSON.parse(localStorage.getItem(KEY) || "{}"),
    );
  } catch (e) {
    state = fresh();
  }
  const read = (k) => {
    if (k === "apwStory27") return window.APW_TEAM_B.story();
    try {
      return JSON.parse(localStorage.getItem(k) || "null");
    } catch (e) {
      return null;
    }
  };
  const save = () => {
    try {
      window.APW_TEAM_B.store(KEY, JSON.stringify(state));
    } catch (e) {}
  };
  const player = () =>
    window.APW_CAREER?.name || $("careerWrestler")?.value || "Your wrestler";
  const btn = (label, fn, disabled = false) => {
    const b = document.createElement("button");
    b.textContent = label;
    b.disabled = disabled;
    b.addEventListener("click", () => {
      fn();
      save();
      render();
    });
    $("apw30Actions").append(b);
  };
  const set = (text) => {
    $("apw30Scene").textContent = text;
  };
  function render() {
    const a = $("apw30Actions");
    a.replaceChildren();
    const prev = read("apwShowdown28"),
      story = read("apwStory27") || {};
    const ally = (story.allies || []).find(
      (x) => x === "Doomslayer" || x === "Taras Jones",
    );
    const photo = (story.decisions || []).some(
      (x) => x.chapter === 2 && x.choice === 0,
    );
    const deal = (story.decisions || []).some(
      (x) => x.chapter === 2 && x.choice === 1,
    );
    const unlocked =
      (prev && prev.phase >= 4 && prev.wins > 0) || state.stage > 0;
    $("apw30Canvas").hidden = state.stage !== 3 || !unlocked;
    $("apw30Meters").textContent =
      state.stage === 3
        ? `YOUR HP ${state.hp} / 100   ·   BRUZA HP ${state.boss} / 125   ·   MOMENTUM ${state.momentum} / 100`
        : "";
    $("apw30Info").textContent =
      `Evidence ${state.evidence} · Trust ${state.trust} · Heat ${state.heat} · ${ally ? "Ally: " + ally : "No ally"} · Progress saved on this device`;
    if (!unlocked) {
      set(
        "LOCKED — Finish the v2.9 Birdman showdown and select “Reveal next chapter” to unlock the championship conspiracy. Your existing save remains untouched.",
      );
      btn("↻ Check unlock", () => {});
      return;
    }
    if (state.stage === 0) {
      set(
        "CHAPTER 8 — THE LEAKED FOOTAGE\n\nA grainy security recording shows Birdman receiving confidential training footage from the APW office.\n\n" +
          (photo
            ? "Your photograph matches the timestamp on the recording."
            : deal
              ? "Evangeline reminds you of the favour you owe her."
              : "Someone has wiped the original file.") +
          "\n\n" +
          (ally
            ? ally + " offers to back you up."
            : "You are alone in the corridor.") +
          "\n\nWhat will " +
          player() +
          " do?",
      );
      btn("🔎 Secure the evidence", () => {
        state.evidence += 2;
        state.stage = 1;
        state.choice = "evidence";
      });
      btn("🎤 Expose it publicly", () => {
        state.heat += 2;
        state.stage = 1;
        state.choice = "promo";
      });
      return;
    }
    if (state.stage === 1) {
      set(
        "CHAPTER 9 — EVANGELINE’S OFFICE\n\nEvangeline Strange folds her arms. “APW is no tea party. Nobody gets a title shot without proving they deserve it.”\n\n" +
          (state.evidence >= 2
            ? "You slide the timestamped recording across her desk."
            : "The locker room is buzzing after your accusation.") +
          "\n\nShe offers a choice: keep quiet and earn a sanctioned eliminator, or make the conspiracy public.",
      );
      btn("🤝 Accept the eliminator", () => {
        state.trust++;
        state.stage = 2;
      });
      btn("⚡ Challenge her authority", () => {
        state.evidence++;
        state.heat += 2;
        state.stage = 2;
      });
      return;
    }
    if (state.stage === 2) {
      set(
        "CHAPTER 10 — THE CHAMPION’S WARNING\n\nBruza The Serb steps into the arena with Nikki Poteet at his side.\n\nBRUZA: “You want the heavyweight belt? Earn your place!”\n\nNikki whispers to the referee, David Hilder. " +
          (ally
            ? ally + " watches from ringside, ready to spot any interference."
            : "No one is watching your back.") +
          "\n\nThis is a NON-TITLE championship eliminator. Win to secure your claim to a title match.",
      );
      btn("🔔 Start eliminator", () => {
        state.stage = 3;
        state.hp = 100;
        state.trainingStats = APW_GROWTH.stats();
        state.boss = 125;
        state.momentum = 0;
        state.turn = 0;
        state.guard = false;
        state.log = "David Hilder rings the bell!";
        APW_STAKES.init(state);
      });
      btn("📂 Review evidence", () => {
        state.evidence = Math.max(state.evidence, 1);
        state.log = "You review the secured evidence copy.";
      });
      return;
    }
    if (state.stage === 3) {
      set(
        "CHAMPIONSHIP ELIMINATOR — " +
          player() +
          " vs BRUZA THE SERB\n\n" +
          state.log,
      );
      btn("👊 Strike (+20 MOM)", () => attack("strike"));
      btn("🤼 Grapple (+15 MOM)", () => attack("grapple"));
      btn("🛡️ Guard / recover", () => attack("guard"));
      btn(
        "💥 Signature finisher (60 MOM)",
        () => attack("finish"),
        state.momentum < 60,
      );
      return;
    }
    if (state.stage === 4) {
      set(
        "CHAPTER 11 — THE VERDICT\n\n" +
          state.log +
          "\n\n" +
          (state.outcome === "win"
            ? "You have earned a claim to an APW Heavyweight Championship match. Nikki Poteet protests the result."
            : "Bruza retains his position at the top of the Tower. The road is not over.") +
          "\n\n" +
          (state.evidence >= 2
            ? "The security footage points directly toward Evangeline’s office."
            : "The conspiracy remains difficult to prove.") +
          "\n\nTO BE CONTINUED — THE HEAVYWEIGHT TITLE MATCH",
      );
      btn("🔁 Replay eliminator", () => {
        state.stage = 2;
        state.outcome = "";
      });
      btn("🏆 Return to APW Tower", () =>
        document
          .querySelector(".career-panel")
          ?.scrollIntoView({ behavior: "smooth" }),
      );
      btn("↩ Replay conspiracy", () => {
        state = fresh();
      });
      return;
    }
  }
  function attack(type) {
    if (state.stage !== 3 || (type === "finish" && state.momentum < 60)) return;
    APW_STAKES.clearNotices(state);
    const story = read("apwStory27") || {},
      ally = state.politics
        ? ["Doomslayer", "Taras Jones"].includes(state.politics.ally)
        : (story.allies || []).some(
            (x) => x === "Doomslayer" || x === "Taras Jones",
          );
    let dmg = 0,
      msg = "";
    state.guard = false;
    if (type === "strike") {
      dmg = 12 + (state.turn % 5);
      state.momentum = Math.min(
        100,
        state.momentum + 20 + APW_GROWTH.momentum(state.trainingStats),
      );
      msg = player() + " lands a stiff strike!";
    }
    if (type === "grapple") {
      dmg = 17 + (state.turn % 6);
      state.momentum = Math.min(
        100,
        state.momentum + 15 + APW_GROWTH.momentum(state.trainingStats),
      );
      msg = player() + " hits a powerful grapple!";
    }
    if (type === "guard") {
      state.guard = true;
      state.hp = Math.min(100, state.hp + 9);
      state.momentum = Math.min(
        100,
        state.momentum + 12 + APW_GROWTH.momentum(state.trainingStats),
      );
      msg = "You recover 9 HP and brace for the counter.";
    }
    if (type === "finish") {
      dmg = 43;
      state.momentum -= 60;
      msg = "SIGNATURE FINISHER! The crowd explodes!";
    }
    dmg = APW_GROWTH.hit(dmg, state.trainingStats);
    state.boss = Math.max(0, state.boss - dmg);
    if (state.boss === 0) {
      state.stage = 4;
      state.outcome = "win";
      APW_GROWTH.reward(true, state.trainingStats);
      state.log =
        msg +
        APW_STAKES.note(state) +
        "\nONE! TWO! THREE! David Hilder raises your hand.";
      return;
    }
    let interferenceDamage = 0;
    let counter = 11 + ((state.turn * 7) % 9) + (state.heat >= 3 ? 3 : 0);
    if (state.guard) counter = Math.max(2, Math.floor(counter * 0.3));
    if (ally && state.turn === 2) {
      counter = 0;
      msg += "\nYour ally warns David Hilder about Nikki’s interference!";
    } else if (state.turn % 4 === 3) {
      counter += 5;
      interferenceDamage = 5;
      msg += "\nNikki Poteet distracts the referee!";
    }
    counter = APW_STAKES.counter(
      state,
      counter,
      interferenceDamage,
      "eliminator",
    );
    counter = APW_GROWTH.hurt(counter, state.trainingStats);
    state.hp = Math.max(0, state.hp - counter);
    state.turn++;
    state.log =
      msg +
      APW_STAKES.note(state) +
      "\nBruza counters with " +
      (state.turn % 3 === 0
        ? "a Russian Leg Sweep!"
        : "a crushing clothesline!") +
      " You take " +
      counter +
      " damage.";
    if (state.hp === 0) {
      state.stage = 4;
      state.outcome = "loss";
      APW_GROWTH.reward(false, state.trainingStats);
      state.log += "\nBruza wins by pinfall. You can challenge him again.";
    }
  }
  const canvas = $("apw30Canvas"),
    ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  let tick = 0;
  function draw() {
    tick++;
    if (!canvas.hidden) {
      const c = ctx;
      c.clearRect(0, 0, 480, 220);
      c.fillStyle = "#17162e";
      c.fillRect(0, 0, 480, 220);
      for (let i = 0; i < 13; i++) {
        c.fillStyle = i % 2 ? "#392944" : "#2a284d";
        c.fillRect(i * 40, 30, 4, 90);
      }
      c.fillStyle = "#bd678c";
      c.fillRect(0, 118, 480, 7);
      c.fillStyle = "#57435d";
      c.fillRect(0, 125, 480, 95);
      c.fillStyle = "#e6b85d";
      c.font = "bold 16px monospace";
      c.fillText("APW • CHAMPIONSHIP ELIMINATOR", 62, 20);
      function sprite(x, champ) {
        let y = Math.round(Math.sin(tick / 14 + (champ ? 2 : 0)) * 3);
        c.save();
        c.translate(x, 185 + y);
        let body = champ ? "#c18a72" : "#cc927a";
        const r = (a, b, w, h, color) => {
          c.fillStyle = color;
          c.fillRect(a, b, w, h);
        };
        r(-20, -45, 16, 42, champ ? "#181d33" : "#332539");
        r(4, -45, 16, 42, champ ? "#181d33" : "#332539");
        r(-22, -66, 44, 24, champ ? "#151827" : "#9e3b68");
        r(-28, -110, 56, 48, body);
        r(-35, -104, 11, 42, body);
        r(24, -104, 11, 42, body);
        r(-16, -139, 32, 31, body);
        r(-12, -126, 7, 4, "#181420");
        r(5, -126, 7, 4, "#181420");
        if (champ) {
          r(-22, -102, 44, 10, "#22263e");
          r(-20, -86, 40, 7, "#b32f44");
          r(-8, -74, 16, 7, "#f3f0ec");
          r(-16, -142, 32, 6, "#1b171a");
        } else {
          r(-17, -142, 34, 8, "#30202c");
          r(-22, -135, 7, 25, "#30202c");
        }
        c.restore();
      }
      sprite(148, false);
      sprite(333, true);
      c.fillStyle = "#fff";
      c.font = "bold 11px monospace";
      c.fillText(player().slice(0, 20).toUpperCase(), 12, 210);
      c.fillText("BRUZA THE SERB", 360, 210);
    }
    requestAnimationFrame(draw);
  }
  draw();
  $("careerWrestler")?.addEventListener("change", render);
  render();

  window.APW_TEAM_B.register(() => {
    state = fresh();
    save();
    render();
  });
  window.addEventListener("apw:path-refresh", render);
})();
