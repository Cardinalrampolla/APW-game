/* Cage match */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id),
    KEY = "apwCage32";
  const fresh = () => ({
    phase: 0,
    route: "",
    hp: 110,
    enemy: 145,
    stamina: 80,
    climb: 0,
    enemyClimb: 0,
    turn: 0,
    heat: 0,
    evidence: 0,
    guard: false,
    finish: "",
    log: "",
  });
  let st;
  try {
    st = window.APW_TEAM_B.restore(
      fresh(),
      JSON.parse(localStorage.getItem(KEY) || "{}"),
    );
  } catch (e) {
    st = fresh();
  }
  const save = () => {
    try {
      window.APW_TEAM_B.store(KEY, JSON.stringify(st));
    } catch (e) {}
  };
  const player = () => window.APW_CAREER?.name || "Your wrestler";
  const prev = () => {
    try {
      return JSON.parse(localStorage.getItem("apwConspiracy30") || "null");
    } catch (e) {
      return null;
    }
  };
  const story = () => {
    try {
      return window.APW_TEAM_B.story();
    } catch (e) {
      return {};
    }
  };
  const button = (label, fn, disabled = false) => {
    const b = document.createElement("button");
    b.textContent = label;
    b.disabled = disabled;
    b.onclick = () => {
      fn();
      save();
      render();
    };
    $("apw32Buttons").append(b);
  };
  function render() {
    const a = $("apw32Buttons");
    a.replaceChildren();
    let old = prev(),
      unlocked =
        (old && old.stage === 4 && old.outcome === "win") || st.phase > 0;
    const won = old?.outcome === "win";
    $("apw32Arena").hidden = st.phase !== 3 || !unlocked;
    $("apw32Stats").textContent =
      st.phase === 3
        ? `YOU ${st.hp} HP | OPPONENT ${st.enemy} HP | STAMINA ${st.stamina}\nYOUR ESCAPE ${st.climb}% | RIVAL ESCAPE ${st.enemyClimb}%`
        : "";
    const set = (t) => ($("apw32Story").textContent = t);
    if (!unlocked) {
      set(
        "LOCKED: Complete Chapter 11 — The Verdict in v3.0 first. Your existing saves are safe.",
      );
      button("↻ Check chapter", () => {});
      return;
    }
    if (st.phase === 0) {
      st.route = won ? "championship contender" : "redemption";
      set(
        won
          ? "CHAPTER 12 — THE TITLE SHOT STOLEN\n\nYour eliminator victory earns you a title opportunity, but Evangeline Strange announces a new condition: beat Birdman Phil Picasso inside a steel cage first. Birdman boasts that no one escapes the Trashbag Police."
          : "CHAPTER 12 — ROAD BACK TO THE TOWER\n\nAfter the eliminator defeat, Evangeline offers one route back into contention: a steel cage grudge match against Birdman Phil Picasso. Win and you return to the title picture.",
      );
      button("🎤 Confront Birdman", () => {
        st.heat += 1;
        st.phase = 1;
      });
      button("🔎 Investigate the booking", () => {
        st.evidence += 2;
        st.phase = 1;
      });
      return;
    }
    if (st.phase === 1) {
      set(
        "CHAPTER 13 — EVANGELINE’S ULTIMATUM\n\nEvangeline: “APW IS NO TEA PARTY! The cage keeps everyone honest.”\n\nNikki Poteet smirks from the entrance ramp. David Hilder promises to enforce the rules.\n\nYour allies may help expose interference, but nobody can enter the locked cage.",
      );
      button("🤝 Ask allies to watch ringside", () => {
        st.phase = 2;
        st.guard = true;
      });
      button("🔥 Call out the conspiracy", () => {
        st.phase = 2;
        st.heat += 2;
      });
      return;
    }
    if (st.phase === 2) {
      set(
        "CHAPTER 14 — STEEL CAGE SHOWDOWN\n\n" +
          player() +
          " VS BIRDMAN PHIL PICASSO\n\nWIN BY PINFALL OR ESCAPING OVER THE CAGE. Strike and grapple to weaken Birdman. Climbing costs stamina and can be interrupted. Guard restores stamina. Birdman will also attempt to escape!",
      );
      button("🔔 Ring the bell", () => {
        st.phase = 3;
        st.hp = 110;
        st.trainingStats = APW_GROWTH.stats();
        st.enemy = 145;
        st.stamina = 80;
        st.climb = 0;
        st.enemyClimb = 0;
        st.turn = 0;
        st.log = "The cage door SLAMS shut!";
        APW_STAKES.init(st);
      });
      return;
    }
    if (st.phase === 3) {
      set(
        "STEEL CAGE MATCH — " +
          player() +
          " vs BIRDMAN PHIL PICASSO\n\n" +
          st.log,
      );
      button("👊 Strike", () => act("strike"));
      button("🤼 Grapple", () => act("grapple"));
      button("🛡️ Guard / Recover", () => act("guard"));
      button(
        "🧗 Climb cage",
        () => act("climb"),
        st.stamina < APW_GROWTH.cost(20, st.trainingStats),
      );
      button(
        "💥 Finisher",
        () => act("finish"),
        st.stamina < APW_GROWTH.cost(55, st.trainingStats),
      );
      button("↩ Abandon / restart", () => {
        st.phase = 2;
      });
      return;
    }
    if (st.phase === 4) {
      set(
        "CHAPTER 15 — THE CAGE VERDICT\n\n" +
          st.log +
          "\n\n" +
          (st.finish === "win"
            ? "You have survived the cage! " +
              (st.route === "championship contender"
                ? "Evangeline can no longer deny your heavyweight title opportunity."
                : "You have fought your way back into the APW Tower title picture.")
            : "Birdman steals the spotlight again. Your championship dream survives, but the road gets harder.") +
          "\n\n" +
          (st.evidence
            ? "Your investigation uncovers suspicious orders from Evangeline’s office."
            : "The identity of the mastermind remains hidden.") +
          "\n\nTO BE CONTINUED — THE HEAVYWEIGHT TITLE MATCH",
      );
      button("🔁 Rematch", () => {
        st.phase = 2;
        st.finish = "";
      });
      button("↩ Replay cage story", () => {
        st = fresh();
      });
      button("🏆 APW Tower", () =>
        document
          .querySelector(".career-panel")
          ?.scrollIntoView({ behavior: "smooth" }),
      );
      return;
    }
  }
  function act(type) {
    if (
      st.phase !== 3 ||
      (type === "finish" &&
        st.stamina < APW_GROWTH.cost(55, st.trainingStats)) ||
      (type === "climb" && st.stamina < APW_GROWTH.cost(20, st.trainingStats))
    )
      return;
    APW_STAKES.clearNotices(st);
    let msg = "",
      damage = 0;
    st.guard = false;
    const ally = st.politics
      ? ["Doomslayer", "Taras Jones"].includes(st.politics.ally)
      : (story().allies || []).some(
          (x) => x === "Doomslayer" || x === "Taras Jones",
        );
    if (type === "strike") {
      damage = 13 + (st.turn % 5);
      st.stamina = Math.min(
        100,
        st.stamina + 8 + APW_GROWTH.recovery(st.trainingStats),
      );
      msg = "A stiff strike rocks Birdman!";
    }
    if (type === "grapple") {
      damage = 20 + (st.turn % 5);
      st.stamina = Math.min(
        100,
        st.stamina + 3 + APW_GROWTH.recovery(st.trainingStats),
      );
      msg = "A thunderous grapple into the cage wall!";
    }
    if (type === "guard") {
      st.guard = true;
      st.hp = Math.min(110, st.hp + 9);
      st.stamina = Math.min(
        100,
        st.stamina + 22 + APW_GROWTH.recovery(st.trainingStats),
      );
      msg = "You brace and recover your breath.";
    }
    if (type === "finish") {
      damage = 53;
      st.stamina -= APW_GROWTH.cost(55, st.trainingStats);
      msg = "SIGNATURE FINISHER! BIRDMAN CRASHES TO THE MAT!";
    }
    if (type === "climb") {
      st.stamina -= APW_GROWTH.cost(20, st.trainingStats);
      const gain = st.enemy < 65 ? 40 : st.enemy < 110 ? 27 : 17;
      st.climb = Math.min(100, st.climb + gain);
      msg = "You scale the steel mesh! Escape " + st.climb + "%.";
      if (st.climb >= 100) {
        end(
          true,
          "You climb over the cage and land on the arena floor! ESCAPE VICTORY!",
        );
        return;
      }
    }
    damage = APW_GROWTH.hit(damage, st.trainingStats);
    if (damage) {
      st.enemy = Math.max(0, st.enemy - damage);
      st.climb = Math.max(0, st.climb - 8);
    }
    if (st.enemy === 0) {
      end(true, msg + " ONE! TWO! THREE! David Hilder counts the pin!");
      return;
    }
    let interferenceDamage = 0;
    let counter = 10 + ((st.turn * 7) % 10) + (st.heat >= 2 ? 3 : 0);
    if (st.guard) counter = Math.max(2, Math.floor(counter * 0.3));
    if (st.turn % 4 === 3) {
      st.enemyClimb += 30;
      msg += "\nBirdman starts climbing the cage!";
    }
    if (type === "climb" && st.enemy > 50) {
      st.climb = Math.max(0, st.climb - 14);
      counter += 5;
      msg += "\nBirdman drags you down from the fence!";
    }
    if (ally && st.turn === 3) {
      counter = 0;
      msg += "\nYour ally exposes Nikki’s attempted interference!";
    }
    if (st.enemyClimb >= 100) {
      end(false, msg + " Birdman escapes the cage!");
      return;
    }
    counter = APW_STAKES.counter(st, counter, interferenceDamage, "cage");
    counter = APW_GROWTH.hurt(counter, st.trainingStats);
    st.hp = Math.max(0, st.hp - counter);
    st.turn++;
    st.log =
      msg +
      APW_STAKES.note(st) +
      "\nBirdman counters for " +
      counter +
      " damage.";
    if (st.hp === 0) end(false, st.log + "\nDavid Hilder counts the three!");
  }
  function end(win, msg) {
    if (st.phase !== 3) return;
    APW_GROWTH.reward(win, st.trainingStats);
    st.phase = 4;
    st.finish = win ? "win" : "loss";
    st.log = msg;
  }
  const c = $("apw32Arena"),
    g = c.getContext("2d");
  g.imageSmoothingEnabled = false;
  let t = 0;
  function frame() {
    t++;
    if (!c.hidden) {
      g.fillStyle = "#11152d";
      g.fillRect(0, 0, 480, 250);
      for (let x = 0; x < 480; x += 24) {
        g.fillStyle = "#343b59";
        g.fillRect(x, 0, 2, 218);
      }
      for (let y = 0; y < 220; y += 24) {
        g.fillStyle = "#343b59";
        g.fillRect(0, y, 480, 2);
      }
      g.fillStyle = "#543b62";
      g.fillRect(20, 168, 440, 60);
      g.fillStyle = "#edb25b";
      g.font = "bold 17px monospace";
      g.fillText("APW STEEL CAGE", 150, 24);
      function sprite(x, bird) {
        let y = Math.round(Math.sin(t / 13 + (bird ? 3 : 0)) * 3);
        g.save();
        g.translate(x, 207 + y);
        const r = (x, y, w, h, col) => {
          g.fillStyle = col;
          g.fillRect(x, y, w, h);
        };
        r(-20, -43, 15, 43, "#1b1d30");
        r(5, -43, 15, 43, "#1b1d30");
        r(-22, -66, 44, 26, bird ? "#161922" : "#a63c69");
        r(-26, -109, 52, 45, "#c98e72");
        r(-33, -103, 10, 37, "#c98e72");
        r(23, -103, 10, 37, "#c98e72");
        r(-15, -139, 30, 30, "#d49b7c");
        r(-10, -125, 6, 4, "#14111a");
        r(5, -125, 6, 4, "#14111a");
        if (bird) {
          r(-12, -109, 24, 5, "#32242a");
          r(-12, -94, 24, 7, "#29212c");
        } else {
          r(-16, -142, 32, 9, "#31232e");
          r(-18, -132, 6, 28, "#31232e");
        }
        g.restore();
      }
      sprite(146, false);
      sprite(334, true);
      g.fillStyle = "#fff";
      g.font = "bold 11px monospace";
      g.fillText(player().slice(0, 19).toUpperCase(), 12, 242);
      g.fillText("BIRDMAN", 393, 242);
      g.fillStyle = "#a7b8d6";
      for (let x = 0; x < 480; x += 32) g.fillRect(x, 0, 2, 215);
    }
    requestAnimationFrame(frame);
  }
  frame();
  $("careerWrestler")?.addEventListener("change", render);
  render();

  window.APW_TEAM_B.register(() => {
    st = fresh();
    save();
    render();
  });
  window.addEventListener("apw:path-refresh", render);
})();
