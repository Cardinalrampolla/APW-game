/* Enemy signature effects */
(() => {
  const moves = {
    "The Gatekeeper": ["GHOSTLY HANDS SLAM", "#a55aff"],
    "Trucker Mark Taylor": ["THE FINAL CUT", "#f5a34c"],
    "Harvey Falco": ["FALCON PUNCH", "#b35cff"],
    "Al Straya": ["44 GALLON DRUM", "#f1ca47"],
    "Simon Temple": ["CHOKE SLAM", "#ff668f"],
    "Birdman Phil Picasso": ["DOUBLE UNDERHOOK DDT", "#ff3155"],
    "Bruza The Serb": ["RUSSIAN LEG SWEEP", "#63c6ff"],
  };
  const arena = document.querySelector(".arena");
  if (!arena) return;
  const banner = document.createElement("div");
  banner.className = "apw-signature-banner";
  banner.setAttribute("aria-live", "polite");
  const spark = document.createElement("div");
  spark.className = "apw-signature-spark";
  arena.append(banner, spark);
  function opponent() {
    return window.APW_OPPONENT || "The Gatekeeper";
  }
  function refresh() {
    arena.dataset.opponent = opponent();
    const label = document.getElementById("gatekeeper-sprite");
    if (label) label.alt = opponent() + " provisional in-ring sprite";
  }
  function signature() {
    refresh();
    const [name, glow] = moves[opponent()] || [
      window.APW_SPECIALS?.[opponent()] || "SPECIAL ATTACK",
      "#ffce66",
    ];
    arena.style.setProperty("--move-glow", glow);
    banner.textContent = name + "!";
    for (const el of [banner, spark]) {
      el.classList.remove("play");
      void el.offsetWidth;
      el.classList.add("play");
    }
    arena.classList.add("apw-special-active");
    setTimeout(() => arena.classList.remove("apw-special-active"), 1050);
  }
  // Observe the existing combat log rather than modifying its proven combat formulas.
  const log = document.getElementById("log");
  if (log) {
    new MutationObserver((records) => {
      for (const r of records) {
        for (const node of r.addedNodes) {
          if (
            node.nodeType === 1 &&
            node.tagName === "P" &&
            node.textContent.includes("🔴")
          ) {
            signature();
            return;
          }
        }
      }
    }).observe(log, { childList: true });
  }
  const tower = document.querySelector(".apw-tower");
  if (tower)
    tower.addEventListener("click", (e) => {
      if (e.target.closest("[data-floor]")) setTimeout(refresh, 0);
    });
  const restart = document.getElementById("restart");
  if (restart) restart.addEventListener("click", () => setTimeout(refresh, 0));
  refresh();
})();

/* ---- Module 8 ---- */

/* Fallback sprite renderer */
(() => {
  "use strict";
  const characters = {
    "Gideon Hark": ["#d8a47d", "#5d382b", "#f0669e", "#282431", "long"],
    "Simon Temple": ["#dba27f", "#57372d", "#f0669e", "#272431", "giant"],
    "Birdman Phil Picasso": [
      "#c58c68",
      "#252127",
      "#24232a",
      "#15131d",
      "bald",
    ],
    "Bruza The Serb": ["#d8a47d", "#342c2c", "#151a23", "#c92c39", "giant"],
    "Nikki Poteet": ["#edb78d", "#e6c363", "#e8bc45", "#211827", "long"],
    "Johnny Putrid": ["#d6a17c", "#241d25", "#ad2439", "#17151e", "long"],
    "Nightmare Cat": ["#6b6679", "#302b35", "#4d4557", "#e6cf68", "mask"],
    TNT: ["#d9a27f", "#1b1b22", "#15151e", "#d32a3e", "long"],
    "Whiskey Sixx": ["#e5ac84", "#d6ad64", "#a92737", "#1b1721", "long"],
    "Mauler Y": ["#b18470", "#1c1b23", "#181c23", "#4ab66b", "giantmask"],
    "Al Straya": ["#d3a17b", "#7d3d27", "#161820", "#282b31", "mohawk"],
    "Trucker Mark Taylor": [
      "#d4a17d",
      "#2b2728",
      "#393941",
      "#a33b43",
      "giant",
    ],
    "Taras Jones": ["#d5a27e", "#31282a", "#262431", "#1b1824", "long"],
    "Harvey Falco": ["#d7a17f", "#543c2c", "#f4e7da", "#326ab0", "short"],
    Doomslayer: ["#d6a27c", "#8d654c", "#1b1c24", "#e84991", "short"],
    "Drako Savage": ["#cf9d78", "#eeeeec", "#171a21", "#be2639", "hood"],
    "Trashbag Dan": ["#d4a17c", "#f06bb1", "#f478bd", "#18151f", "mask"],
    "Eli Driftwood": ["#d7a17b", "#ba292b", "#b62e3b", "#1c1d2b", "mask"],
    "Jay Payne": ["#d4a17c", "#33252b", "#26242d", "#bf3455", "long"],
    "The Outlaw": ["#c78c69", "#c92d36", "#15151b", "#25212b", "mask"],
    "Black Diamond": ["#d7a17c", "#1b1824", "#17151e", "#29232c", "long"],
    "Hotshot Hansel": ["#d9a37f", "#6c4b2d", "#f1cb38", "#f1cb38", "short"],
    "Evangeline Strange": [
      "#e0ad8c",
      "#a85c3c",
      "#252432",
      "#f2ede5",
      "braids",
    ],
    "The Gatekeeper": ["#8d8299", "#1b1827", "#2a2237", "#a53e4e", "skull"],
  };

  const cache = new Map();
  function sprite(name, pose, frame) {
    const key = [name, pose, frame].join("|");
    if (cache.has(key)) return cache.get(key);
    const [skin, hair, gear, accent, type] =
      characters[name] || characters["Gideon Hark"];
    const c = document.createElement("canvas");
    c.width = 96;
    c.height = 128;
    const g = c.getContext("2d");
    g.imageSmoothingEnabled = false;
    const r = (x, y, w, h, color) => {
      g.fillStyle = color;
      g.fillRect(Math.round(x), Math.round(y), w, h);
    };
    const giant = ["giant", "giantmask"].includes(type),
      wide = giant ? 7 : 0;
    const moving =
      pose === "attack" ||
      pose === "finishing" ||
      pose === "grabbing" ||
      pose === "slowhit";
    const hurt = ["hit", "down", "flyback"].includes(pose);
    const bob =
      pose === "idle" ? (frame % 4 === 1 ? -2 : frame % 4 === 3 ? 1 : 0) : 0;

    const arm = moving
      ? frame % 3 === 0
        ? -22
        : frame % 3 === 1
          ? -12
          : 0
      : pose === "taunt"
        ? -25
        : 0;
    const leg = pose === "walk" ? (frame % 4 < 2 ? 8 : -8) : moving ? 6 : 0;
    g.save();
    if (hurt) {
      g.translate(48, 72);
      g.rotate(
        (pose === "down" || pose === "flyback" ? 0.95 : 0.22) *
          (frame % 2 ? 1 : -1),
      );
      g.translate(-48, -72);
    }
    // shadow, boots, leg movement and layered highlights
    r(18, 120, 63, 5, "#070914");
    r(25 - wide + leg, 94, 16 + wide, 23, "#10111b");
    r(53 - leg, 94, 16 + wide, 23, "#10111b");
    r(22 - wide + leg, 114, 22 + wide, 7, "#080910");
    r(51 - leg, 114, 23 + wide, 7, "#080910");
    r(28 - wide + leg, 83, 12 + wide, 24, gear);
    r(54 - leg, 83, 12 + wide, 24, accent);
    r(29 - wide + leg, 87, 3, 15, "#ffffff28");
    // torso outline and broad shoulders
    r(22 - wide, 40 + bob, 51 + wide * 2, 49, "#080914");
    r(25 - wide, 43 + bob, 45 + wide * 2, 43, gear);
    r(28 - wide, 45 + bob, 6, 29, accent);
    r(62 + wide, 45 + bob, 5, 27, "#080914");
    // arms: left guarding, right animated strike
    r(14 - wide, 47 + bob, 13, 38, skin);
    r(13 - wide, 77 + bob, 15, 13, skin);
    r(70 + wide, 47 + bob + arm, 13, 37, skin);
    r(70 + wide, 77 + bob + arm, 15, 13, skin);
    r(15 - wide, 57 + bob, 4, 16, "#f4c6a144");
    r(76 + wide, 57 + bob + arm, 3, 16, "#f4c6a144");
    // neck, head and distinct hair/mask silhouette
    r(42, 33 + bob, 14, 13, skin);
    r(36, 15 + bob, 26, 28, skin);
    r(39, 18 + bob, 5, 17, "#f5cda144");
    if (type === "hood") {
      r(31, 8 + bob, 36, 39, "#e9e8e5");
      r(37, 17 + bob, 25, 23, "#1b1922");
      r(29, 7 + bob, 8, 33, "#ddd9d5");
    } else if (type === "skull") {
      r(29, 7 + bob, 39, 43, "#171323");
      r(36, 15 + bob, 26, 26, "#d6d0c5");
      r(42, 32 + bob, 15, 7, "#211b26");
    } else if (type === "mask" || type === "giantmask") {
      r(34, 11 + bob, 30, 31, hair);
      r(38, 21 + bob, 22, 15, accent);
    } else {
      r(34, 10 + bob, 30, 11, hair);
      if (type === "long" || type === "braids") {
        r(29, 16 + bob, 8, 39, hair);
        r(62, 16 + bob, 8, 39, hair);
      }
      if (type === "mohawk") r(45, 2 + bob, 9, 12, hair);
      if (type === "bald") r(36, 9 + bob, 26, 7, skin);
    }
    r(40, 27 + bob, 6, 4, type === "skull" ? "#ff2626" : "#13131b");
    r(53, 27 + bob, 6, 4, type === "skull" ? "#ff2626" : "#13131b");
    r(46, 37 + bob, 9, 3, "#4d2927");
    if (name === "Bruza The Serb") {
      r(39, 55 + bob, 22, 18, "#eee9e7");
      r(44, 59 + bob, 13, 8, "#c72c39");
    }
    if (name === "Simon Temple" || name === "Gideon Hark") {
      r(27 - wide, 49 + bob, 43 + wide * 2, 13, "#e9649d");
      r(30, 53 + bob, 8, 4, "#272332");
    }
    if (name === "Birdman Phil Picasso") {
      r(42, 58 + bob, 16, 8, "#9991a0");
      r(41, 40 + bob, 17, 5, "#27212a");
    }
    if (name === "Trashbag Dan") {
      r(20, 83, 57, 15, "#f076bc");
      r(33, 8 + bob, 34, 9, "#f277bf");
    }
    if (name === "Mauler Y") {
      r(42, 32 + bob, 15, 6, "#eeeeec");
    }
    if (name === "Evangeline Strange") {
      r(44, 47 + bob, 11, 27, "#f3efea");
    }
    if (name === "Whiskey Sixx") {
      r(39, 73 + bob, 21, 7, "#18151c");
    }
    if (name === "Al Straya") {
      r(32, 57 + bob, 10, 8, "#c6a19b");
    }
    if (name === "Hotshot Hansel") {
      r(24 - wide, 103, 14, 10, "#f1cb38");
      r(55, 103, 14, 10, "#f1cb38");
    }
    if (name === "The Gatekeeper" && moving) {
      r(41, 26 + bob, 7, 6, "#ff1111");
      r(54, 26 + bob, 7, 6, "#ff1111");
    }

    // v5.6 Team A: wrestler-specific 16-bit pixel detail pass.
    // This extends the existing pose/frame renderer; combat, saves and cinematic artwork stay unchanged.
    const ink = "#0b0b18";
    const px = (x, y, w, h, col) => r(x, y + bob, w, h, col);
    const eyes = () => {
      px(40, 28, 5, 2, ink);
      px(54, 28, 5, 2, ink);
    };
    if (name === "Gideon Hark") {
      px(29, 17, 8, 40, "#513021");
      px(63, 18, 7, 40, "#513021");
      px(35, 9, 30, 9, "#67402a");
      px(31, 45, 36, 7, "#eb80b4");
      px(33, 55, 31, 5, "#3a3342");
      px(43, 65, 13, 8, "#f0a0ca");
      px(45, 37, 12, 3, "#6d3c2e");
      eyes();
    }
    if (name === "Simon Temple") {
      px(34, 11, 30, 8, "#553729");
      px(38, 34, 23, 7, "#5a352d");
      px(24, 47, 51, 11, "#e87dab");
      px(30, 60, 38, 7, "#4a3e4e");
      px(16, 58, 5, 13, "#4d3545");
      px(77, 59, 5, 12, "#4d3545");
      eyes();
    }
    if (name === "Birdman Phil Picasso") {
      px(35, 10, 29, 8, skin);
      px(42, 35, 17, 6, "#4b302a");
      px(39, 47, 22, 7, "#2a2734");
      px(43, 54, 15, 6, "#8b7b83");
      px(30, 67, 6, 15, "#3a3543");
      px(63, 66, 5, 15, "#3a3543");
      px(16, 57, 7, 15, "#34313d");
      px(75, 57, 6, 14, "#34313d");
      eyes();
    }
    if (name === "Bruza The Serb") {
      px(31, 44, 11, 42, "#b91d39");
      px(57, 44, 11, 42, "#2552a5");
      px(43, 47, 13, 36, "#eee9eb");
      px(46, 54, 8, 5, "#be263b");
      px(29, 83, 39, 6, "#242332");
      px(36, 11, 27, 6, skin);
      eyes();
    }
    if (name === "Whiskey Sixx") {
      px(29, 15, 10, 53, "#e5ba68");
      px(61, 14, 10, 55, "#c69b53");
      px(36, 9, 29, 9, "#e4bb6d");
      px(38, 25, 10, 7, "#20151d");
      px(53, 25, 10, 7, "#20151d");
      px(35, 43, 28, 12, "#a53b43");
      px(40, 57, 18, 8, skin);
      px(41, 62, 17, 3, "#3a2325");
      px(30, 84, 13, 17, "#aa2c3c");
      px(54, 84, 13, 17, "#29212d");
      px(40, 37, 19, 4, "#302025");
    }
    if (name === "Evangeline Strange") {
      px(29, 16, 8, 46, "#9b4c31");
      px(64, 16, 8, 46, "#9b4c31");
      px(30, 45, 38, 39, "#252c40");
      px(43, 46, 13, 31, "#f1e7e2");
      px(45, 52, 10, 4, "#c9a4a1");
      px(39, 27, 9, 3, "#11111d");
      px(52, 27, 9, 3, "#11111d");
      px(48, 29, 5, 2, "#d5b9a7");
    }
    if (name === "The Gatekeeper") {
      px(28, 8, 42, 40, "#1b1727");
      px(34, 17, 31, 28, "#d7d3c9");
      px(40, 28, 7, 5, "#f02434");
      px(53, 28, 7, 5, "#f02434");
      px(42, 38, 16, 3, "#27232c");
      px(24, 46, 52, 42, "#252037");
    }
    if (name === "Nikki Poteet") {
      px(30, 12, 9, 43, "#e9c66e");
      px(61, 12, 9, 43, "#e9c66e");
      px(32, 47, 36, 10, "#e3b858");
      px(39, 62, 20, 6, "#17131e");
    }
    if (name === "Mauler Y") {
      px(32, 13, 35, 32, "#b91e37");
      px(39, 24, 22, 11, "#17151e");
      px(40, 32, 20, 5, "#eee6e6");
      px(33, 54, 33, 15, "#3d7b50");
    }
    if (name === "TNT") {
      px(29, 12, 9, 48, "#24202b");
      px(61, 12, 9, 48, "#24202b");
      px(41, 54, 18, 18, "#b11e3a");
      px(45, 58, 9, 10, "#15141c");
    }
    if (name === "Johnny Putrid") {
      px(28, 15, 9, 51, "#241c25");
      px(63, 15, 9, 51, "#241c25");
      px(38, 27, 25, 6, "#cba84b");
      px(35, 47, 31, 12, "#a82b42");
    }
    if (name === "Al Straya") {
      px(45, 2, 10, 14, "#6a3c27");
      px(39, 36, 20, 6, "#874b33");
      px(33, 50, 32, 13, "#22202a");
      px(38, 65, 23, 5, "#ad3238");
    }
    if (name === "Trashbag Dan") {
      px(29, 6, 39, 13, "#f18ac2");
      px(33, 44, 34, 12, "#d955a1");
      px(23, 82, 53, 14, "#ee8fc3");
      px(42, 26, 17, 7, "#16131e");
    }

    // strike motion and impact stars in selected frames
    if (moving && frame % 3 === 1) {
      r(85, 40, 7, 7, "#fff3a2");
      r(89, 35, 4, 4, "#f6b52f");
      r(88, 51, 4, 4, "#f6b52f");
    }
    g.restore();
    const result = c.toDataURL("image/png");
    cache.set(key, result);
    return result;
  }
  let tick = 0;
  function update() {
    tick++;
    const name =
      window.APW_CAREER?.name ||
      document.getElementById("careerWrestler")?.value ||
      "Gideon Hark";
    const opponent = window.APW_OPPONENT || "The Gatekeeper";
    for (const [id, who] of [
      ["gideon", name],
      ["gatekeeper", opponent],
    ]) {
      const base = document.getElementById(id + "-sprite");
      if (!base) continue;
      const holder = base.closest(".fighter");
      if (!holder) continue;
      let img = holder.querySelector(".apw-v15-sprite");
      if (!img) {
        img = document.createElement("img");
        img.className = "apw-v15-sprite";
        img.alt = who + " animated arcade wrestler";
        base.insertAdjacentElement("afterend", img);
      }
      let label = holder.querySelector(".apw-v15-name");
      if (!label) {
        label = document.createElement("span");
        label.className = "apw-v15-name";
        holder.appendChild(label);
      }
      label.textContent = who;
      const pose =
        [
          "finishing",
          "slowhit",
          "attack",
          "grabbing",
          "hit",
          "down",
          "flyback",
        ].find((a) => holder.classList.contains(a)) || "idle";
      const frame = Math.floor(tick / 2) % 4;
      const k = who + ":" + pose + ":" + frame;
      if (img.dataset.key !== k) {
        img.src = sprite(who, pose, frame);
        img.dataset.key = k;
      }
    }
  }
  window.addEventListener("load", update);
  document.addEventListener("DOMContentLoaded", update);
  setInterval(update, 110);
})();
