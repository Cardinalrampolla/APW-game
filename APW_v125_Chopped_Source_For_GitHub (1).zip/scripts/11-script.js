/* Backstage story */
(() => {
  const $ = (id) => document.getElementById(id),
    key = "apwStory27";
  let state;
  const defaults = () => ({
    chapter: 0,
    respect: 0,
    heat: 0,
    allies: [],
    decisions: [],
  });
  function read() {
    try {
      let a = JSON.parse(localStorage.getItem(key) || "null");
      return a && typeof a.chapter === "number"
        ? window.APW_TEAM_B.restore(defaults(), a)
        : defaults();
    } catch (e) {
      return defaults();
    }
  }
  function save() {
    try {
      window.APW_TEAM_B.store(key, JSON.stringify(state));
    } catch (e) {}
  }
  const chapters = [
    {
      title: "CHAPTER 1 — BIRDMAN GOES VIRAL",
      speaker: "BIRDMAN PHIL PICASSO",
      line: "OI! LOOK AT THESE TEA PARTY NINTENDO WRESTLERS DOING TOO MANY FLIPS! APW IS NO TEA PARTY!\n\nBirdman uploads an embarrassing training clip of {name} to Trashbag Police. The locker room is watching.",
      choices: [
        {
          text: "🎤 Cut a furious comeback promo",
          respect: 1,
          heat: 2,
          ally: null,
          result:
            "The crowd cheers your fiery response. Birdman promises revenge.",
        },
        {
          text: "🥊 Challenge Birdman to settle it in the ring",
          respect: 2,
          heat: 1,
          ally: null,
          result:
            "The locker room respects your confidence. Birdman refuses to name a date.",
        },
        {
          text: "😏 Laugh it off and keep training",
          respect: 1,
          heat: -1,
          ally: null,
          result:
            "Birdman cannot get the reaction he wanted. Your focus rattles him.",
        },
      ],
    },
    {
      title: "CHAPTER 2 — WHO CAN YOU TRUST?",
      speaker: "DOOMSLAYER & TARAS JONES",
      line: "Doomslayer warns that Birdman has friends backstage. Taras Jones offers to help expose his schemes. Both have reasons to hate him.",
      choices: [
        {
          text: "🤝 Team up with Doomslayer",
          respect: 1,
          heat: 1,
          ally: "Doomslayer",
          result: "Doomslayer promises to watch your back against Birdman.",
        },
        {
          text: "🎼 Trust Taras Jones",
          respect: 0,
          heat: 1,
          ally: "Taras Jones",
          result: "Taras offers evidence of Birdman’s backstage interference.",
        },
        {
          text: "🚶 Stay independent",
          respect: 2,
          heat: 0,
          ally: null,
          result:
            "You decide to climb the Tower without owing anybody favours.",
        },
      ],
    },
    {
      title: "CHAPTER 3 — THE AUTHORITY SPEAKS",
      speaker: "EVANGELINE STRANGE",
      line: "Evangeline summons {name} to her office. She claims Birdman is out of control, but demands loyalty in exchange for protection.\n\nA photograph on her desk shows Birdman entering the office after hours.",
      choices: [
        {
          text: "🕵️ Question the suspicious photograph",
          respect: 2,
          heat: 2,
          ally: null,
          result:
            "Evangeline’s smile vanishes. You have discovered the first clue that she may be pulling the strings.",
        },
        {
          text: "📜 Accept her protection, cautiously",
          respect: 0,
          heat: -1,
          ally: "Evangeline Strange",
          result:
            "Evangeline offers a favourable match assignment, but you now owe her a favour.",
        },
        {
          text: "🚫 Refuse the deal outright",
          respect: 2,
          heat: 2,
          ally: null,
          result:
            "Evangeline warns that APW is no tea party. Your next match could be very difficult.",
        },
      ],
    },
    {
      title: "CHAPTER 4 — A WARNING FROM THE CHAMPION",
      speaker: "BRUZA THE SERB",
      line: "Bruza tells {name} that the Heavyweight Championship must be earned in the ring. Nikki Poteet watches closely, ready to interfere if the situation turns ugly.",
      choices: [
        {
          text: "🏆 Promise to earn a title opportunity",
          respect: 2,
          heat: 0,
          ally: null,
          result:
            "Bruza nods. The champion may respect you, even if the office does not.",
        },
        {
          text: "🔥 Accuse the office of protecting the belt",
          respect: 1,
          heat: 2,
          ally: null,
          result: "Nikki steps forward. Bruza insists he needs no protection.",
        },
        {
          text: "🤫 Ask Bruza what he knows about Birdman",
          respect: 1,
          heat: 1,
          ally: null,
          result:
            "Bruza says: Follow the money, not the rumours. The mystery deepens.",
        },
      ],
    },
  ];
  function render() {
    const name = window.APW_CAREER?.name || "Gideon Hark",
      c = chapters[state.chapter];
    if (state.chapter === 0 && !window.APW_PATH?.storyReady()) {
      $("politicsChoices").replaceChildren();
      $("politicsScene").textContent =
        "CAREER PATH — Defeat The Gatekeeper and clear Tower floors 1–4 to confront Birdman backstage.";
      return;
    }
    $("politicsStats").innerHTML = "";
    [
      ["Locker-room respect", state.respect],
      ["Birdman heat", state.heat],
      ["Allies", state.allies.join(", ") || "None"],
      ["Chapters", state.chapter + "/" + chapters.length],
    ].forEach(([k, v]) => {
      let x = document.createElement("span");
      x.textContent = k + ": " + v;
      $("politicsStats").append(x);
    });
    $("politicsChoices").innerHTML = "";
    if (!c) {
      $("politicsScene").textContent =
        "🏆 STORY ARC COMPLETE!\n\n" +
        name +
        " has survived Birdman’s humiliation campaign, made allies or enemies, and uncovered hints of Evangeline’s manipulation.\n\nYour choices are saved on this device. Continue your APW Tower matches in the main game.";
      return;
    }
    $("politicsScene").textContent =
      c.title + "\n\n" + c.speaker + ":\n" + c.line.replaceAll("{name}", name);
    c.choices.forEach((choice, i) => {
      let b = document.createElement("button");
      b.textContent =
        choice.text + " — " + window.APW_STAKES.choiceText(state.chapter, i);
      b.onclick = () => {
        state.respect = Math.max(0, state.respect + choice.respect);
        state.heat = Math.max(0, state.heat + choice.heat);
        if (choice.ally && !state.allies.includes(choice.ally))
          state.allies.push(choice.ally);
        state.decisions.push({ chapter: state.chapter, choice: i });
        state.chapter++;
        save();
        render();
        const p = document.createElement("div");
        p.className = "politics-scene";
        p.textContent = "RESULT: " + choice.result;
        $("politicsScene").prepend(p);
      };
      $("politicsChoices").append(b);
    });
  }
  $("politicsRestart").onclick = () => {
    if (
      !confirm(
        "Restart only the backstage storyline? Career matches and stats will be kept.",
      )
    )
      return;
    state = defaults();
    save();
    render();
  };
  state = read();
  state.allies = state.allies.filter((x) => typeof x === "string");
  state.decisions = state.decisions.filter(
    (x) => x && Number.isInteger(x.chapter) && Number.isInteger(x.choice),
  );
  state.chapter = Math.min(chapters.length, state.chapter);
  render();

  window.APW_TEAM_B.register(() => {
    state = defaults();
    save();
    render();
  });
  window.addEventListener("apw:path-refresh", render);
})();
