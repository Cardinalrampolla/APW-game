/* Backstage side story */
(() => {
  const $ = (id) => document.getElementById(id),
    key = "apwChapter13";
  window.APW_SPECIALS = {
    "The Gatekeeper": "GHOSTLY HANDS SLAM",
    "Trucker Mark Taylor": "THE FINAL CUT",
    "Harvey Falco": "FALCON PUNCH",
    "Al Straya": "44 GALLON DRUM",
    "Simon Temple": "CHOKE SLAM",
    "Birdman Phil Picasso": "DOUBLE UNDERHOOK DDT",
    "Bruza The Serb": "RUSSIAN LEG SWEEP",
  };
  let d = {
    name: window.APW_CAREER?.name || "Gideon Hark",
    heat: 0,
    trust: 0,
    evidence: 0,
    ally: "",
    actions: 1,
    last: "Birdman is watching the Tower. Choose your next move.",
    matches: 0,
  };
  function save() {
    try {
      window.APW_TEAM_B.store(key, JSON.stringify(d));
    } catch (e) {}
  }
  function load() {
    try {
      const stored = JSON.parse(localStorage.getItem(key) || "{}");
      if (stored.name === window.APW_CAREER?.name)
        d = window.APW_TEAM_B.restore(d, stored);
    } catch (e) {}
    paint();
  }
  function say(t) {
    d.last = t;
    save();
    paint();
  }
  function paint() {
    if (!$("apw13status")) return;
    const mk = (n, v) =>
      "<div>" +
      n +
      " <b>" +
      v +
      '/100</b><div class="meter"><span style="width:' +
      v +
      '%"></span></div></div>';
    $("apw13status").innerHTML =
      '<div class="ticker">' +
      (d.ally ? "ALLY: " + d.ally + " · " : "NO ALLIES YET · ") +
      "BACKSTAGE ACTIONS: " +
      d.actions +
      "</div>" +
      mk("BIRDMAN HEAT", d.heat) +
      mk("LOCKER ROOM TRUST", d.trust) +
      "<div>📼 TRASHBAG POLICE EVIDENCE: " +
      d.evidence +
      "/3</div>";
    $("apw13feed").textContent = d.last;
    document
      .querySelectorAll("#apw13 button[data-event]")
      .forEach((b) => (b.disabled = d.actions < 1));
  }
  function act(which) {
    if (d.actions < 1) return;
    d.actions--;
    if (which === "promo") {
      d.heat = Math.min(100, d.heat + 20);
      d.trust = Math.min(100, d.trust + 5);
      say(
        "🎤 " +
          d.name +
          ': "I did not come here to drink tea! Birdman, stop hiding behind that camera and face me in the ring!" Birdman is furious.',
      );
    }
    if (which === "alliance") {
      d.trust = Math.min(100, d.trust + 20);
      d.ally = d.trust >= 40 ? "Trucker Mark Taylor" : "Doomslayer";
      say(
        "🤝 " +
          d.ally +
          ' agrees to watch your back. "You earn respect in this business. Do not waste it."',
      );
    }
    if (which === "investigate") {
      d.evidence = Math.min(3, d.evidence + 1);
      d.heat = Math.min(100, d.heat + 8);
      say(
        d.evidence === 3
          ? "📼 The footage reveals Evangeline Strange directing Birdman behind the scenes. The conspiracy is exposed!"
          : "📼 You recover a suspicious Trashbag Police clip. Birdman threatens to make your career miserable.",
      );
    }
    if (which === "challenge") {
      say(
        d.evidence >= 3
          ? "🏆 You confront Evangeline with the evidence. She cannot deny her connection to Birdman. Bruza still awaits at the summit."
          : d.heat >= 40
            ? '🏆 Birdman storms into the locker room: "TEA PARTY NINTENDO WRESTLERS DOING TOO MANY FLIPS! APW IS NO TEA PARTY!"'
            : '🏆 Evangeline says: "Climb the Tower and earn your shot. There are no shortcuts."',
      );
    }
  }
  $("apw13").addEventListener("click", (e) => {
    let b = e.target.closest("button[data-event]");
    if (b) act(b.dataset.event);
  });
  const oldEnd = window.apwMatchEnd;
  window.apwMatchEnd = function (result, match) {
    const opponent = match?.opponent || window.APW_OPPONENT || "The Gatekeeper",
      won = result.includes("WINS!");
    d.matches++;
    d.actions = Math.min(2, d.actions + 1);
    if (won) {
      d.trust = Math.min(100, d.trust + 5);
      d.last =
        "🔔 " +
        d.name +
        " defeated " +
        opponent +
        "! The locker room takes notice. You have a new backstage action.";
      if (opponent === "Birdman Phil Picasso")
        d.last =
          "🎬 Birdman retreats screaming about Nintendo wrestlers. His Trashbag Police camera keeps recording…";
      if (opponent === "Bruza The Serb")
        d.last =
          "🏆 NEW APW HEAVYWEIGHT CHAMPION: " +
          d.name +
          "! But Evangeline still has secrets.";
    } else {
      d.last =
        "💥 Defeat against " +
        opponent +
        ". Train, recover, and plan your next move.";
    }
    save();
    paint();
    if (typeof oldEnd === "function") oldEnd(result, match);
  };
  const oldChoose = window.apwChoose;
  window.apwChoose = function (name) {
    d = {
      name,
      heat: 0,
      trust: 0,
      evidence: 0,
      ally: "",
      actions: 1,
      last: "A new career begins. Birdman is watching.",
      matches: 0,
    };
    oldChoose(name);
    save();
    paint();
  };
  window.addEventListener("load", load);
  load();
})();
