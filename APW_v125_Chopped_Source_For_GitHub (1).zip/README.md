# APW: No Tea Party! — v12.5 Modular Handover

**Protected original:** `backup/APW_v125_Master_Stable_ORIGINAL.html`. SHA-256 in `backup/SHA256.txt`.

**Modular preview:** `index.html`, with CSS in `styles/` and JavaScript in `scripts/`, retaining exact original section order. This is a **mechanical extraction**, not a tested or refactored release. Do not tag `v1-modular` until browser regression checks pass.

**Important:** Local `file://` browser security may block external scripts/resources; serve the directory using `python -m http.server 8000` and open `http://localhost:8000/`. Preserve script order and global scope during refactoring. Do not minify or alter base64 assets until tested.

**GitHub plan:** Commit untouched original on baseline branch/tag `v0-original`; publish modular code on a separate branch; run the original-vs-modular checklist before merging or tagging `v1-modular`.

**Validation still required:** all 23 wrestlers, combat, pins, dirty tricks, tag-team, Velvet, career, cutscenes, saves, mobile/desktop, graphics and audio.
